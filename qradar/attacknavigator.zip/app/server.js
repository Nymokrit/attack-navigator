const cors = require('cors');
const express = require('express');
const app = express();
const http = require('http').Server(app);
const fs = require('fs');

// Middleware
app.use(cors());
app.use(express.json()); // for parsing application/json
app.use(express.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
app.use(express.static('/app/public'));


app.get('/debug', (req, res) => {
    res.send('Yay!');
});

app.get('/layers', (req, res) => {
    if (!fs.existsSync('/store/layers')) {
        fs.mkdirSync('/store/layers/');
    }
    files = fs.readdirSync('/store/layers/');
    res.send(files);
});

app.get('/layer/:name', (req, res) => {
    layer = req.params.name;
    if (!fs.existsSync('/store/layers/' + layer)) {
        res.send(404);
    } else {
        res.sendFile('/store/layers/' + layer);
    }
});

app.post('/layer/:name', (req, res) => {
    layer = req.params.name;
    data = new Uint8Array(Buffer.from(JSON.stringify(req.body)));
    fs.writeFile('/store/layers/' + layer, data, (err) => {
        if (err) throw err;
        console.log('The file has been saved!');
        res.send(200);
    });
});

app.delete('/layer/:name', (req, res) => {
    layer = req.params.name;
    if (!fs.existsSync('/store/layers/' + layer)) return res.send(200); // return success if file didn't exist in the first place
    fs.unlink('/store/layers/' + layer, (err) => {
        if (err) throw err;
        console.log('path/file.txt was deleted');
        res.send(200);
    });
});

http.listen(5000, () => { console.log('listening on *:5000'); });