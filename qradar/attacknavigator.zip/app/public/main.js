(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/core-js/modules/_a-function.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_a-function.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_a-number-value.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/_a-number-value.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
module.exports = function (it, msg) {
  if (typeof it != 'number' && cof(it) != 'Number') throw TypeError(msg);
  return +it;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_add-to-unscopables.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/_add-to-unscopables.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.31 Array.prototype[@@unscopables]
var UNSCOPABLES = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('unscopables');
var ArrayProto = Array.prototype;
if (ArrayProto[UNSCOPABLES] == undefined) __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js")(ArrayProto, UNSCOPABLES, {});
module.exports = function (key) {
  ArrayProto[UNSCOPABLES][key] = true;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_an-instance.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_an-instance.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (it, Constructor, name, forbiddenField) {
  if (!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)) {
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_an-object.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_an-object.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_array-copy-within.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_array-copy-within.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)

var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");

module.exports = [].copyWithin || function copyWithin(target /* = 0 */, start /* = 0, end = @length */) {
  var O = toObject(this);
  var len = toLength(O.length);
  var to = toAbsoluteIndex(target, len);
  var from = toAbsoluteIndex(start, len);
  var end = arguments.length > 2 ? arguments[2] : undefined;
  var count = Math.min((end === undefined ? len : toAbsoluteIndex(end, len)) - from, len - to);
  var inc = 1;
  if (from < to && to < from + count) {
    inc = -1;
    from += count - 1;
    to += count - 1;
  }
  while (count-- > 0) {
    if (from in O) O[to] = O[from];
    else delete O[to];
    to += inc;
    from += inc;
  } return O;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_array-fill.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_array-fill.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)

var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
module.exports = function fill(value /* , start = 0, end = @length */) {
  var O = toObject(this);
  var length = toLength(O.length);
  var aLen = arguments.length;
  var index = toAbsoluteIndex(aLen > 1 ? arguments[1] : undefined, length);
  var end = aLen > 2 ? arguments[2] : undefined;
  var endPos = end === undefined ? length : toAbsoluteIndex(end, length);
  while (endPos > index) O[index++] = value;
  return O;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_array-includes.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/_array-includes.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// false -> Array#indexOf
// true  -> Array#includes
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
module.exports = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};


/***/ }),

/***/ "./node_modules/core-js/modules/_array-methods.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_array-methods.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 0 -> Array#forEach
// 1 -> Array#map
// 2 -> Array#filter
// 3 -> Array#some
// 4 -> Array#every
// 5 -> Array#find
// 6 -> Array#findIndex
var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var IObject = __webpack_require__(/*! ./_iobject */ "./node_modules/core-js/modules/_iobject.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var asc = __webpack_require__(/*! ./_array-species-create */ "./node_modules/core-js/modules/_array-species-create.js");
module.exports = function (TYPE, $create) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  var create = $create || asc;
  return function ($this, callbackfn, that) {
    var O = toObject($this);
    var self = IObject(O);
    var f = ctx(callbackfn, that, 3);
    var length = toLength(self.length);
    var index = 0;
    var result = IS_MAP ? create($this, length) : IS_FILTER ? create($this, 0) : undefined;
    var val, res;
    for (;length > index; index++) if (NO_HOLES || index in self) {
      val = self[index];
      res = f(val, index, O);
      if (TYPE) {
        if (IS_MAP) result[index] = res;   // map
        else if (res) switch (TYPE) {
          case 3: return true;             // some
          case 5: return val;              // find
          case 6: return index;            // findIndex
          case 2: result.push(val);        // filter
        } else if (IS_EVERY) return false; // every
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : result;
  };
};


/***/ }),

/***/ "./node_modules/core-js/modules/_array-reduce.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/_array-reduce.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var IObject = __webpack_require__(/*! ./_iobject */ "./node_modules/core-js/modules/_iobject.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");

module.exports = function (that, callbackfn, aLen, memo, isRight) {
  aFunction(callbackfn);
  var O = toObject(that);
  var self = IObject(O);
  var length = toLength(O.length);
  var index = isRight ? length - 1 : 0;
  var i = isRight ? -1 : 1;
  if (aLen < 2) for (;;) {
    if (index in self) {
      memo = self[index];
      index += i;
      break;
    }
    index += i;
    if (isRight ? index < 0 : length <= index) {
      throw TypeError('Reduce of empty array with no initial value');
    }
  }
  for (;isRight ? index >= 0 : length > index; index += i) if (index in self) {
    memo = callbackfn(memo, self[index], index, O);
  }
  return memo;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_array-species-constructor.js":
/*!********************************************************************!*\
  !*** ./node_modules/core-js/modules/_array-species-constructor.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var isArray = __webpack_require__(/*! ./_is-array */ "./node_modules/core-js/modules/_is-array.js");
var SPECIES = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('species');

module.exports = function (original) {
  var C;
  if (isArray(original)) {
    C = original.constructor;
    // cross-realm fallback
    if (typeof C == 'function' && (C === Array || isArray(C.prototype))) C = undefined;
    if (isObject(C)) {
      C = C[SPECIES];
      if (C === null) C = undefined;
    }
  } return C === undefined ? Array : C;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_array-species-create.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/_array-species-create.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 9.4.2.3 ArraySpeciesCreate(originalArray, length)
var speciesConstructor = __webpack_require__(/*! ./_array-species-constructor */ "./node_modules/core-js/modules/_array-species-constructor.js");

module.exports = function (original, length) {
  return new (speciesConstructor(original))(length);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_bind.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_bind.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var invoke = __webpack_require__(/*! ./_invoke */ "./node_modules/core-js/modules/_invoke.js");
var arraySlice = [].slice;
var factories = {};

var construct = function (F, len, args) {
  if (!(len in factories)) {
    for (var n = [], i = 0; i < len; i++) n[i] = 'a[' + i + ']';
    // eslint-disable-next-line no-new-func
    factories[len] = Function('F,a', 'return new F(' + n.join(',') + ')');
  } return factories[len](F, args);
};

module.exports = Function.bind || function bind(that /* , ...args */) {
  var fn = aFunction(this);
  var partArgs = arraySlice.call(arguments, 1);
  var bound = function (/* args... */) {
    var args = partArgs.concat(arraySlice.call(arguments));
    return this instanceof bound ? construct(fn, args.length, args) : invoke(fn, args, that);
  };
  if (isObject(fn.prototype)) bound.prototype = fn.prototype;
  return bound;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_classof.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_classof.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
var TAG = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('toStringTag');
// ES3 wrong here
var ARG = cof(function () { return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (e) { /* empty */ }
};

module.exports = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_cof.js":
/*!**********************************************!*\
  !*** ./node_modules/core-js/modules/_cof.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = function (it) {
  return toString.call(it).slice(8, -1);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_collection-strong.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_collection-strong.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f;
var create = __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js");
var redefineAll = __webpack_require__(/*! ./_redefine-all */ "./node_modules/core-js/modules/_redefine-all.js");
var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var anInstance = __webpack_require__(/*! ./_an-instance */ "./node_modules/core-js/modules/_an-instance.js");
var forOf = __webpack_require__(/*! ./_for-of */ "./node_modules/core-js/modules/_for-of.js");
var $iterDefine = __webpack_require__(/*! ./_iter-define */ "./node_modules/core-js/modules/_iter-define.js");
var step = __webpack_require__(/*! ./_iter-step */ "./node_modules/core-js/modules/_iter-step.js");
var setSpecies = __webpack_require__(/*! ./_set-species */ "./node_modules/core-js/modules/_set-species.js");
var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var fastKey = __webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").fastKey;
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var SIZE = DESCRIPTORS ? '_s' : 'size';

var getEntry = function (that, key) {
  // fast case
  var index = fastKey(key);
  var entry;
  if (index !== 'F') return that._i[index];
  // frozen object case
  for (entry = that._f; entry; entry = entry.n) {
    if (entry.k == key) return entry;
  }
};

module.exports = {
  getConstructor: function (wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME;         // collection type
      that._i = create(null); // index
      that._f = undefined;    // first entry
      that._l = undefined;    // last entry
      that[SIZE] = 0;         // size
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.1.3.1 Map.prototype.clear()
      // 23.2.3.2 Set.prototype.clear()
      clear: function clear() {
        for (var that = validate(this, NAME), data = that._i, entry = that._f; entry; entry = entry.n) {
          entry.r = true;
          if (entry.p) entry.p = entry.p.n = undefined;
          delete data[entry.i];
        }
        that._f = that._l = undefined;
        that[SIZE] = 0;
      },
      // 23.1.3.3 Map.prototype.delete(key)
      // 23.2.3.4 Set.prototype.delete(value)
      'delete': function (key) {
        var that = validate(this, NAME);
        var entry = getEntry(that, key);
        if (entry) {
          var next = entry.n;
          var prev = entry.p;
          delete that._i[entry.i];
          entry.r = true;
          if (prev) prev.n = next;
          if (next) next.p = prev;
          if (that._f == entry) that._f = next;
          if (that._l == entry) that._l = prev;
          that[SIZE]--;
        } return !!entry;
      },
      // 23.2.3.6 Set.prototype.forEach(callbackfn, thisArg = undefined)
      // 23.1.3.5 Map.prototype.forEach(callbackfn, thisArg = undefined)
      forEach: function forEach(callbackfn /* , that = undefined */) {
        validate(this, NAME);
        var f = ctx(callbackfn, arguments.length > 1 ? arguments[1] : undefined, 3);
        var entry;
        while (entry = entry ? entry.n : this._f) {
          f(entry.v, entry.k, this);
          // revert to the last existing entry
          while (entry && entry.r) entry = entry.p;
        }
      },
      // 23.1.3.7 Map.prototype.has(key)
      // 23.2.3.7 Set.prototype.has(value)
      has: function has(key) {
        return !!getEntry(validate(this, NAME), key);
      }
    });
    if (DESCRIPTORS) dP(C.prototype, 'size', {
      get: function () {
        return validate(this, NAME)[SIZE];
      }
    });
    return C;
  },
  def: function (that, key, value) {
    var entry = getEntry(that, key);
    var prev, index;
    // change existing entry
    if (entry) {
      entry.v = value;
    // create new entry
    } else {
      that._l = entry = {
        i: index = fastKey(key, true), // <- index
        k: key,                        // <- key
        v: value,                      // <- value
        p: prev = that._l,             // <- previous entry
        n: undefined,                  // <- next entry
        r: false                       // <- removed
      };
      if (!that._f) that._f = entry;
      if (prev) prev.n = entry;
      that[SIZE]++;
      // add to index
      if (index !== 'F') that._i[index] = entry;
    } return that;
  },
  getEntry: getEntry,
  setStrong: function (C, NAME, IS_MAP) {
    // add .keys, .values, .entries, [@@iterator]
    // 23.1.3.4, 23.1.3.8, 23.1.3.11, 23.1.3.12, 23.2.3.5, 23.2.3.8, 23.2.3.10, 23.2.3.11
    $iterDefine(C, NAME, function (iterated, kind) {
      this._t = validate(iterated, NAME); // target
      this._k = kind;                     // kind
      this._l = undefined;                // previous
    }, function () {
      var that = this;
      var kind = that._k;
      var entry = that._l;
      // revert to the last existing entry
      while (entry && entry.r) entry = entry.p;
      // get next entry
      if (!that._t || !(that._l = entry = entry ? entry.n : that._t._f)) {
        // or finish the iteration
        that._t = undefined;
        return step(1);
      }
      // return step by kind
      if (kind == 'keys') return step(0, entry.k);
      if (kind == 'values') return step(0, entry.v);
      return step(0, [entry.k, entry.v]);
    }, IS_MAP ? 'entries' : 'values', !IS_MAP, true);

    // add [@@species], 23.1.2.2, 23.2.2.2
    setSpecies(NAME);
  }
};


/***/ }),

/***/ "./node_modules/core-js/modules/_collection-weak.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/_collection-weak.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var redefineAll = __webpack_require__(/*! ./_redefine-all */ "./node_modules/core-js/modules/_redefine-all.js");
var getWeak = __webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").getWeak;
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var anInstance = __webpack_require__(/*! ./_an-instance */ "./node_modules/core-js/modules/_an-instance.js");
var forOf = __webpack_require__(/*! ./_for-of */ "./node_modules/core-js/modules/_for-of.js");
var createArrayMethod = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js");
var $has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var arrayFind = createArrayMethod(5);
var arrayFindIndex = createArrayMethod(6);
var id = 0;

// fallback for uncaught frozen keys
var uncaughtFrozenStore = function (that) {
  return that._l || (that._l = new UncaughtFrozenStore());
};
var UncaughtFrozenStore = function () {
  this.a = [];
};
var findUncaughtFrozen = function (store, key) {
  return arrayFind(store.a, function (it) {
    return it[0] === key;
  });
};
UncaughtFrozenStore.prototype = {
  get: function (key) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) return entry[1];
  },
  has: function (key) {
    return !!findUncaughtFrozen(this, key);
  },
  set: function (key, value) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) entry[1] = value;
    else this.a.push([key, value]);
  },
  'delete': function (key) {
    var index = arrayFindIndex(this.a, function (it) {
      return it[0] === key;
    });
    if (~index) this.a.splice(index, 1);
    return !!~index;
  }
};

module.exports = {
  getConstructor: function (wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME;      // collection type
      that._i = id++;      // collection id
      that._l = undefined; // leak store for uncaught frozen objects
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.3.3.2 WeakMap.prototype.delete(key)
      // 23.4.3.3 WeakSet.prototype.delete(value)
      'delete': function (key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME))['delete'](key);
        return data && $has(data, this._i) && delete data[this._i];
      },
      // 23.3.3.4 WeakMap.prototype.has(key)
      // 23.4.3.4 WeakSet.prototype.has(value)
      has: function has(key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME)).has(key);
        return data && $has(data, this._i);
      }
    });
    return C;
  },
  def: function (that, key, value) {
    var data = getWeak(anObject(key), true);
    if (data === true) uncaughtFrozenStore(that).set(key, value);
    else data[that._i] = value;
    return that;
  },
  ufstore: uncaughtFrozenStore
};


/***/ }),

/***/ "./node_modules/core-js/modules/_collection.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_collection.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var redefineAll = __webpack_require__(/*! ./_redefine-all */ "./node_modules/core-js/modules/_redefine-all.js");
var meta = __webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js");
var forOf = __webpack_require__(/*! ./_for-of */ "./node_modules/core-js/modules/_for-of.js");
var anInstance = __webpack_require__(/*! ./_an-instance */ "./node_modules/core-js/modules/_an-instance.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var $iterDetect = __webpack_require__(/*! ./_iter-detect */ "./node_modules/core-js/modules/_iter-detect.js");
var setToStringTag = __webpack_require__(/*! ./_set-to-string-tag */ "./node_modules/core-js/modules/_set-to-string-tag.js");
var inheritIfRequired = __webpack_require__(/*! ./_inherit-if-required */ "./node_modules/core-js/modules/_inherit-if-required.js");

module.exports = function (NAME, wrapper, methods, common, IS_MAP, IS_WEAK) {
  var Base = global[NAME];
  var C = Base;
  var ADDER = IS_MAP ? 'set' : 'add';
  var proto = C && C.prototype;
  var O = {};
  var fixMethod = function (KEY) {
    var fn = proto[KEY];
    redefine(proto, KEY,
      KEY == 'delete' ? function (a) {
        return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'has' ? function has(a) {
        return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'get' ? function get(a) {
        return IS_WEAK && !isObject(a) ? undefined : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'add' ? function add(a) { fn.call(this, a === 0 ? 0 : a); return this; }
        : function set(a, b) { fn.call(this, a === 0 ? 0 : a, b); return this; }
    );
  };
  if (typeof C != 'function' || !(IS_WEAK || proto.forEach && !fails(function () {
    new C().entries().next();
  }))) {
    // create collection constructor
    C = common.getConstructor(wrapper, NAME, IS_MAP, ADDER);
    redefineAll(C.prototype, methods);
    meta.NEED = true;
  } else {
    var instance = new C();
    // early implementations not supports chaining
    var HASNT_CHAINING = instance[ADDER](IS_WEAK ? {} : -0, 1) != instance;
    // V8 ~  Chromium 40- weak-collections throws on primitives, but should return false
    var THROWS_ON_PRIMITIVES = fails(function () { instance.has(1); });
    // most early implementations doesn't supports iterables, most modern - not close it correctly
    var ACCEPT_ITERABLES = $iterDetect(function (iter) { new C(iter); }); // eslint-disable-line no-new
    // for early implementations -0 and +0 not the same
    var BUGGY_ZERO = !IS_WEAK && fails(function () {
      // V8 ~ Chromium 42- fails only with 5+ elements
      var $instance = new C();
      var index = 5;
      while (index--) $instance[ADDER](index, index);
      return !$instance.has(-0);
    });
    if (!ACCEPT_ITERABLES) {
      C = wrapper(function (target, iterable) {
        anInstance(target, C, NAME);
        var that = inheritIfRequired(new Base(), target, C);
        if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
        return that;
      });
      C.prototype = proto;
      proto.constructor = C;
    }
    if (THROWS_ON_PRIMITIVES || BUGGY_ZERO) {
      fixMethod('delete');
      fixMethod('has');
      IS_MAP && fixMethod('get');
    }
    if (BUGGY_ZERO || HASNT_CHAINING) fixMethod(ADDER);
    // weak collections should not contains .clear method
    if (IS_WEAK && proto.clear) delete proto.clear;
  }

  setToStringTag(C, NAME);

  O[NAME] = C;
  $export($export.G + $export.W + $export.F * (C != Base), O);

  if (!IS_WEAK) common.setStrong(C, NAME, IS_MAP);

  return C;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_core.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_core.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.5.7' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),

/***/ "./node_modules/core-js/modules/_create-property.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/_create-property.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $defineProperty = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var createDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");

module.exports = function (object, index, value) {
  if (index in object) $defineProperty.f(object, index, createDesc(0, value));
  else object[index] = value;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_ctx.js":
/*!**********************************************!*\
  !*** ./node_modules/core-js/modules/_ctx.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// optional / simple context binding
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};


/***/ }),

/***/ "./node_modules/core-js/modules/_date-to-iso-string.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/_date-to-iso-string.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var getTime = Date.prototype.getTime;
var $toISOString = Date.prototype.toISOString;

var lz = function (num) {
  return num > 9 ? num : '0' + num;
};

// PhantomJS / old WebKit has a broken implementations
module.exports = (fails(function () {
  return $toISOString.call(new Date(-5e13 - 1)) != '0385-07-25T07:06:39.999Z';
}) || !fails(function () {
  $toISOString.call(new Date(NaN));
})) ? function toISOString() {
  if (!isFinite(getTime.call(this))) throw RangeError('Invalid time value');
  var d = this;
  var y = d.getUTCFullYear();
  var m = d.getUTCMilliseconds();
  var s = y < 0 ? '-' : y > 9999 ? '+' : '';
  return s + ('00000' + Math.abs(y)).slice(s ? -6 : -4) +
    '-' + lz(d.getUTCMonth() + 1) + '-' + lz(d.getUTCDate()) +
    'T' + lz(d.getUTCHours()) + ':' + lz(d.getUTCMinutes()) +
    ':' + lz(d.getUTCSeconds()) + '.' + (m > 99 ? m : '0' + lz(m)) + 'Z';
} : $toISOString;


/***/ }),

/***/ "./node_modules/core-js/modules/_date-to-primitive.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_date-to-primitive.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var NUMBER = 'number';

module.exports = function (hint) {
  if (hint !== 'string' && hint !== NUMBER && hint !== 'default') throw TypeError('Incorrect hint');
  return toPrimitive(anObject(this), hint != NUMBER);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_defined.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_defined.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// 7.2.1 RequireObjectCoercible(argument)
module.exports = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_descriptors.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_descriptors.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Thank's IE8 for his funny defineProperty
module.exports = !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),

/***/ "./node_modules/core-js/modules/_dom-create.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_dom-create.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var document = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").document;
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};


/***/ }),

/***/ "./node_modules/core-js/modules/_enum-bug-keys.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_enum-bug-keys.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// IE 8- don't enum bug keys
module.exports = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');


/***/ }),

/***/ "./node_modules/core-js/modules/_enum-keys.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_enum-keys.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// all enumerable object keys, includes symbols
var getKeys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
var gOPS = __webpack_require__(/*! ./_object-gops */ "./node_modules/core-js/modules/_object-gops.js");
var pIE = __webpack_require__(/*! ./_object-pie */ "./node_modules/core-js/modules/_object-pie.js");
module.exports = function (it) {
  var result = getKeys(it);
  var getSymbols = gOPS.f;
  if (getSymbols) {
    var symbols = getSymbols(it);
    var isEnum = pIE.f;
    var i = 0;
    var key;
    while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
  } return result;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_export.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/_export.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var core = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] || (global[name] = {}) : (global[name] || {})[PROTOTYPE];
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE] || (exports[PROTOTYPE] = {});
  var key, own, out, exp;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    // export native or passed
    out = (own ? target : source)[key];
    // bind timers to global for call from export context
    exp = IS_BIND && own ? ctx(out, global) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // extend global
    if (target) redefine(target, key, out, type & $export.U);
    // export
    if (exports[key] != out) hide(exports, key, exp);
    if (IS_PROTO && expProto[key] != out) expProto[key] = out;
  }
};
global.core = core;
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
module.exports = $export;


/***/ }),

/***/ "./node_modules/core-js/modules/_fails-is-regexp.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/_fails-is-regexp.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var MATCH = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('match');
module.exports = function (KEY) {
  var re = /./;
  try {
    '/./'[KEY](re);
  } catch (e) {
    try {
      re[MATCH] = false;
      return !'/./'[KEY](re);
    } catch (f) { /* empty */ }
  } return true;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_fails.js":
/*!************************************************!*\
  !*** ./node_modules/core-js/modules/_fails.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};


/***/ }),

/***/ "./node_modules/core-js/modules/_fix-re-wks.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_fix-re-wks.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
var wks = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js");

module.exports = function (KEY, length, exec) {
  var SYMBOL = wks(KEY);
  var fns = exec(defined, SYMBOL, ''[KEY]);
  var strfn = fns[0];
  var rxfn = fns[1];
  if (fails(function () {
    var O = {};
    O[SYMBOL] = function () { return 7; };
    return ''[KEY](O) != 7;
  })) {
    redefine(String.prototype, KEY, strfn);
    hide(RegExp.prototype, SYMBOL, length == 2
      // 21.2.5.8 RegExp.prototype[@@replace](string, replaceValue)
      // 21.2.5.11 RegExp.prototype[@@split](string, limit)
      ? function (string, arg) { return rxfn.call(string, this, arg); }
      // 21.2.5.6 RegExp.prototype[@@match](string)
      // 21.2.5.9 RegExp.prototype[@@search](string)
      : function (string) { return rxfn.call(string, this); }
    );
  }
};


/***/ }),

/***/ "./node_modules/core-js/modules/_flags.js":
/*!************************************************!*\
  !*** ./node_modules/core-js/modules/_flags.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 21.2.5.3 get RegExp.prototype.flags
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
module.exports = function () {
  var that = anObject(this);
  var result = '';
  if (that.global) result += 'g';
  if (that.ignoreCase) result += 'i';
  if (that.multiline) result += 'm';
  if (that.unicode) result += 'u';
  if (that.sticky) result += 'y';
  return result;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_for-of.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/_for-of.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var call = __webpack_require__(/*! ./_iter-call */ "./node_modules/core-js/modules/_iter-call.js");
var isArrayIter = __webpack_require__(/*! ./_is-array-iter */ "./node_modules/core-js/modules/_is-array-iter.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var getIterFn = __webpack_require__(/*! ./core.get-iterator-method */ "./node_modules/core-js/modules/core.get-iterator-method.js");
var BREAK = {};
var RETURN = {};
var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
  var iterFn = ITERATOR ? function () { return iterable; } : getIterFn(iterable);
  var f = ctx(fn, that, entries ? 2 : 1);
  var index = 0;
  var length, step, iterator, result;
  if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if (result === BREAK || result === RETURN) return result;
  } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
    result = call(iterator, f, step.value, entries);
    if (result === BREAK || result === RETURN) return result;
  }
};
exports.BREAK = BREAK;
exports.RETURN = RETURN;


/***/ }),

/***/ "./node_modules/core-js/modules/_global.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/_global.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


/***/ }),

/***/ "./node_modules/core-js/modules/_has.js":
/*!**********************************************!*\
  !*** ./node_modules/core-js/modules/_has.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_hide.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_hide.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var createDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
module.exports = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_html.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_html.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var document = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").document;
module.exports = document && document.documentElement;


/***/ }),

/***/ "./node_modules/core-js/modules/_ie8-dom-define.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/_ie8-dom-define.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = !__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return Object.defineProperty(__webpack_require__(/*! ./_dom-create */ "./node_modules/core-js/modules/_dom-create.js")('div'), 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),

/***/ "./node_modules/core-js/modules/_inherit-if-required.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/_inherit-if-required.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var setPrototypeOf = __webpack_require__(/*! ./_set-proto */ "./node_modules/core-js/modules/_set-proto.js").set;
module.exports = function (that, target, C) {
  var S = target.constructor;
  var P;
  if (S !== C && typeof S == 'function' && (P = S.prototype) !== C.prototype && isObject(P) && setPrototypeOf) {
    setPrototypeOf(that, P);
  } return that;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_invoke.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/_invoke.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function (fn, args, that) {
  var un = that === undefined;
  switch (args.length) {
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return fn.apply(that, args);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_iobject.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_iobject.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
// eslint-disable-next-line no-prototype-builtins
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return cof(it) == 'String' ? it.split('') : Object(it);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_is-array-iter.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_is-array-iter.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// check on default Array iterator
var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
var ITERATOR = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('iterator');
var ArrayProto = Array.prototype;

module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_is-array.js":
/*!***************************************************!*\
  !*** ./node_modules/core-js/modules/_is-array.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.2 IsArray(argument)
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
module.exports = Array.isArray || function isArray(arg) {
  return cof(arg) == 'Array';
};


/***/ }),

/***/ "./node_modules/core-js/modules/_is-integer.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_is-integer.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.3 Number.isInteger(number)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var floor = Math.floor;
module.exports = function isInteger(it) {
  return !isObject(it) && isFinite(it) && floor(it) === it;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_is-object.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_is-object.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};


/***/ }),

/***/ "./node_modules/core-js/modules/_is-regexp.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_is-regexp.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.8 IsRegExp(argument)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
var MATCH = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('match');
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : cof(it) == 'RegExp');
};


/***/ }),

/***/ "./node_modules/core-js/modules/_iter-call.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_iter-call.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// call something on iterator step with safe closing on error
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
module.exports = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) anObject(ret.call(iterator));
    throw e;
  }
};


/***/ }),

/***/ "./node_modules/core-js/modules/_iter-create.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_iter-create.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var create = __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js");
var descriptor = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
var setToStringTag = __webpack_require__(/*! ./_set-to-string-tag */ "./node_modules/core-js/modules/_set-to-string-tag.js");
var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
__webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js")(IteratorPrototype, __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('iterator'), function () { return this; });

module.exports = function (Constructor, NAME, next) {
  Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
  setToStringTag(Constructor, NAME + ' Iterator');
};


/***/ }),

/***/ "./node_modules/core-js/modules/_iter-define.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_iter-define.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
var $iterCreate = __webpack_require__(/*! ./_iter-create */ "./node_modules/core-js/modules/_iter-create.js");
var setToStringTag = __webpack_require__(/*! ./_set-to-string-tag */ "./node_modules/core-js/modules/_set-to-string-tag.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var ITERATOR = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';

var returnThis = function () { return this; };

module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  $iterCreate(Constructor, NAME, next);
  var getMethod = function (kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS: return function keys() { return new Constructor(this, kind); };
      case VALUES: return function values() { return new Constructor(this, kind); };
    } return function entries() { return new Constructor(this, kind); };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = $native || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if (!LIBRARY && typeof IteratorPrototype[ITERATOR] != 'function') hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() { return $native.call(this); };
  }
  // Define iterator
  if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_iter-detect.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_iter-detect.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var ITERATOR = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('iterator');
var SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR]();
  riter['return'] = function () { SAFE_CLOSING = true; };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () { throw 2; });
} catch (e) { /* empty */ }

module.exports = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR]();
    iter.next = function () { return { done: safe = true }; };
    arr[ITERATOR] = function () { return iter; };
    exec(arr);
  } catch (e) { /* empty */ }
  return safe;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_iter-step.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_iter-step.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (done, value) {
  return { value: value, done: !!done };
};


/***/ }),

/***/ "./node_modules/core-js/modules/_iterators.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_iterators.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {};


/***/ }),

/***/ "./node_modules/core-js/modules/_library.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_library.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = false;


/***/ }),

/***/ "./node_modules/core-js/modules/_math-expm1.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_math-expm1.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// 20.2.2.14 Math.expm1(x)
var $expm1 = Math.expm1;
module.exports = (!$expm1
  // Old FF bug
  || $expm1(10) > 22025.465794806719 || $expm1(10) < 22025.4657948067165168
  // Tor Browser bug
  || $expm1(-2e-17) != -2e-17
) ? function expm1(x) {
  return (x = +x) == 0 ? x : x > -1e-6 && x < 1e-6 ? x + x * x / 2 : Math.exp(x) - 1;
} : $expm1;


/***/ }),

/***/ "./node_modules/core-js/modules/_math-fround.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_math-fround.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.16 Math.fround(x)
var sign = __webpack_require__(/*! ./_math-sign */ "./node_modules/core-js/modules/_math-sign.js");
var pow = Math.pow;
var EPSILON = pow(2, -52);
var EPSILON32 = pow(2, -23);
var MAX32 = pow(2, 127) * (2 - EPSILON32);
var MIN32 = pow(2, -126);

var roundTiesToEven = function (n) {
  return n + 1 / EPSILON - 1 / EPSILON;
};

module.exports = Math.fround || function fround(x) {
  var $abs = Math.abs(x);
  var $sign = sign(x);
  var a, result;
  if ($abs < MIN32) return $sign * roundTiesToEven($abs / MIN32 / EPSILON32) * MIN32 * EPSILON32;
  a = (1 + EPSILON32 / EPSILON) * $abs;
  result = a - (a - $abs);
  // eslint-disable-next-line no-self-compare
  if (result > MAX32 || result != result) return $sign * Infinity;
  return $sign * result;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_math-log1p.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_math-log1p.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// 20.2.2.20 Math.log1p(x)
module.exports = Math.log1p || function log1p(x) {
  return (x = +x) > -1e-8 && x < 1e-8 ? x - x * x / 2 : Math.log(1 + x);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_math-sign.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_math-sign.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// 20.2.2.28 Math.sign(x)
module.exports = Math.sign || function sign(x) {
  // eslint-disable-next-line no-self-compare
  return (x = +x) == 0 || x != x ? x : x < 0 ? -1 : 1;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_meta.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_meta.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var META = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js")('meta');
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var setDesc = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f;
var id = 0;
var isExtensible = Object.isExtensible || function () {
  return true;
};
var FREEZE = !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return isExtensible(Object.preventExtensions({}));
});
var setMeta = function (it) {
  setDesc(it, META, { value: {
    i: 'O' + ++id, // object ID
    w: {}          // weak collections IDs
  } });
};
var fastKey = function (it, create) {
  // return primitive with prefix
  if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return 'F';
    // not necessary to add metadata
    if (!create) return 'E';
    // add missing metadata
    setMeta(it);
  // return object ID
  } return it[META].i;
};
var getWeak = function (it, create) {
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return true;
    // not necessary to add metadata
    if (!create) return false;
    // add missing metadata
    setMeta(it);
  // return hash weak collections IDs
  } return it[META].w;
};
// add metadata on freeze-family methods calling
var onFreeze = function (it) {
  if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
  return it;
};
var meta = module.exports = {
  KEY: META,
  NEED: false,
  fastKey: fastKey,
  getWeak: getWeak,
  onFreeze: onFreeze
};


/***/ }),

/***/ "./node_modules/core-js/modules/_object-assign.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_object-assign.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 19.1.2.1 Object.assign(target, source, ...)
var getKeys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
var gOPS = __webpack_require__(/*! ./_object-gops */ "./node_modules/core-js/modules/_object-gops.js");
var pIE = __webpack_require__(/*! ./_object-pie */ "./node_modules/core-js/modules/_object-pie.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var IObject = __webpack_require__(/*! ./_iobject */ "./node_modules/core-js/modules/_iobject.js");
var $assign = Object.assign;

// should work with symbols and should have deterministic property order (V8 bug)
module.exports = !$assign || __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  var A = {};
  var B = {};
  // eslint-disable-next-line no-undef
  var S = Symbol();
  var K = 'abcdefghijklmnopqrst';
  A[S] = 7;
  K.split('').forEach(function (k) { B[k] = k; });
  return $assign({}, A)[S] != 7 || Object.keys($assign({}, B)).join('') != K;
}) ? function assign(target, source) { // eslint-disable-line no-unused-vars
  var T = toObject(target);
  var aLen = arguments.length;
  var index = 1;
  var getSymbols = gOPS.f;
  var isEnum = pIE.f;
  while (aLen > index) {
    var S = IObject(arguments[index++]);
    var keys = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S);
    var length = keys.length;
    var j = 0;
    var key;
    while (length > j) if (isEnum.call(S, key = keys[j++])) T[key] = S[key];
  } return T;
} : $assign;


/***/ }),

/***/ "./node_modules/core-js/modules/_object-create.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_object-create.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var dPs = __webpack_require__(/*! ./_object-dps */ "./node_modules/core-js/modules/_object-dps.js");
var enumBugKeys = __webpack_require__(/*! ./_enum-bug-keys */ "./node_modules/core-js/modules/_enum-bug-keys.js");
var IE_PROTO = __webpack_require__(/*! ./_shared-key */ "./node_modules/core-js/modules/_shared-key.js")('IE_PROTO');
var Empty = function () { /* empty */ };
var PROTOTYPE = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = __webpack_require__(/*! ./_dom-create */ "./node_modules/core-js/modules/_dom-create.js")('iframe');
  var i = enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  __webpack_require__(/*! ./_html */ "./node_modules/core-js/modules/_html.js").appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
  return createDict();
};

module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty();
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_object-dp.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_object-dp.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var IE8_DOM_DEFINE = __webpack_require__(/*! ./_ie8-dom-define */ "./node_modules/core-js/modules/_ie8-dom-define.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var dP = Object.defineProperty;

exports.f = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_object-dps.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_object-dps.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var getKeys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");

module.exports = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = getKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) dP.f(O, P = keys[i++], Properties[P]);
  return O;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_object-gopd.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_object-gopd.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var pIE = __webpack_require__(/*! ./_object-pie */ "./node_modules/core-js/modules/_object-pie.js");
var createDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var IE8_DOM_DEFINE = __webpack_require__(/*! ./_ie8-dom-define */ "./node_modules/core-js/modules/_ie8-dom-define.js");
var gOPD = Object.getOwnPropertyDescriptor;

exports.f = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") ? gOPD : function getOwnPropertyDescriptor(O, P) {
  O = toIObject(O);
  P = toPrimitive(P, true);
  if (IE8_DOM_DEFINE) try {
    return gOPD(O, P);
  } catch (e) { /* empty */ }
  if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_object-gopn-ext.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/_object-gopn-ext.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var gOPN = __webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js").f;
var toString = {}.toString;

var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
  ? Object.getOwnPropertyNames(window) : [];

var getWindowNames = function (it) {
  try {
    return gOPN(it);
  } catch (e) {
    return windowNames.slice();
  }
};

module.exports.f = function getOwnPropertyNames(it) {
  return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
};


/***/ }),

/***/ "./node_modules/core-js/modules/_object-gopn.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_object-gopn.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
var $keys = __webpack_require__(/*! ./_object-keys-internal */ "./node_modules/core-js/modules/_object-keys-internal.js");
var hiddenKeys = __webpack_require__(/*! ./_enum-bug-keys */ "./node_modules/core-js/modules/_enum-bug-keys.js").concat('length', 'prototype');

exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return $keys(O, hiddenKeys);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_object-gops.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_object-gops.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

exports.f = Object.getOwnPropertySymbols;


/***/ }),

/***/ "./node_modules/core-js/modules/_object-gpo.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_object-gpo.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var IE_PROTO = __webpack_require__(/*! ./_shared-key */ "./node_modules/core-js/modules/_shared-key.js")('IE_PROTO');
var ObjectProto = Object.prototype;

module.exports = Object.getPrototypeOf || function (O) {
  O = toObject(O);
  if (has(O, IE_PROTO)) return O[IE_PROTO];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_object-keys-internal.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/_object-keys-internal.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var arrayIndexOf = __webpack_require__(/*! ./_array-includes */ "./node_modules/core-js/modules/_array-includes.js")(false);
var IE_PROTO = __webpack_require__(/*! ./_shared-key */ "./node_modules/core-js/modules/_shared-key.js")('IE_PROTO');

module.exports = function (object, names) {
  var O = toIObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_object-keys.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_object-keys.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys = __webpack_require__(/*! ./_object-keys-internal */ "./node_modules/core-js/modules/_object-keys-internal.js");
var enumBugKeys = __webpack_require__(/*! ./_enum-bug-keys */ "./node_modules/core-js/modules/_enum-bug-keys.js");

module.exports = Object.keys || function keys(O) {
  return $keys(O, enumBugKeys);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_object-pie.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_object-pie.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

exports.f = {}.propertyIsEnumerable;


/***/ }),

/***/ "./node_modules/core-js/modules/_object-sap.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_object-sap.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// most Object methods by ES6 should accept primitives
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var core = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
module.exports = function (KEY, exec) {
  var fn = (core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  $export($export.S + $export.F * fails(function () { fn(1); }), 'Object', exp);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_own-keys.js":
/*!***************************************************!*\
  !*** ./node_modules/core-js/modules/_own-keys.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// all object keys, includes non-enumerable and symbols
var gOPN = __webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js");
var gOPS = __webpack_require__(/*! ./_object-gops */ "./node_modules/core-js/modules/_object-gops.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var Reflect = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").Reflect;
module.exports = Reflect && Reflect.ownKeys || function ownKeys(it) {
  var keys = gOPN.f(anObject(it));
  var getSymbols = gOPS.f;
  return getSymbols ? keys.concat(getSymbols(it)) : keys;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_parse-float.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_parse-float.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $parseFloat = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").parseFloat;
var $trim = __webpack_require__(/*! ./_string-trim */ "./node_modules/core-js/modules/_string-trim.js").trim;

module.exports = 1 / $parseFloat(__webpack_require__(/*! ./_string-ws */ "./node_modules/core-js/modules/_string-ws.js") + '-0') !== -Infinity ? function parseFloat(str) {
  var string = $trim(String(str), 3);
  var result = $parseFloat(string);
  return result === 0 && string.charAt(0) == '-' ? -0 : result;
} : $parseFloat;


/***/ }),

/***/ "./node_modules/core-js/modules/_parse-int.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_parse-int.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $parseInt = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").parseInt;
var $trim = __webpack_require__(/*! ./_string-trim */ "./node_modules/core-js/modules/_string-trim.js").trim;
var ws = __webpack_require__(/*! ./_string-ws */ "./node_modules/core-js/modules/_string-ws.js");
var hex = /^[-+]?0[xX]/;

module.exports = $parseInt(ws + '08') !== 8 || $parseInt(ws + '0x16') !== 22 ? function parseInt(str, radix) {
  var string = $trim(String(str), 3);
  return $parseInt(string, (radix >>> 0) || (hex.test(string) ? 16 : 10));
} : $parseInt;


/***/ }),

/***/ "./node_modules/core-js/modules/_property-desc.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_property-desc.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),

/***/ "./node_modules/core-js/modules/_redefine-all.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/_redefine-all.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
module.exports = function (target, src, safe) {
  for (var key in src) redefine(target, key, src[key], safe);
  return target;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_redefine.js":
/*!***************************************************!*\
  !*** ./node_modules/core-js/modules/_redefine.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var SRC = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js")('src');
var TO_STRING = 'toString';
var $toString = Function[TO_STRING];
var TPL = ('' + $toString).split(TO_STRING);

__webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js").inspectSource = function (it) {
  return $toString.call(it);
};

(module.exports = function (O, key, val, safe) {
  var isFunction = typeof val == 'function';
  if (isFunction) has(val, 'name') || hide(val, 'name', key);
  if (O[key] === val) return;
  if (isFunction) has(val, SRC) || hide(val, SRC, O[key] ? '' + O[key] : TPL.join(String(key)));
  if (O === global) {
    O[key] = val;
  } else if (!safe) {
    delete O[key];
    hide(O, key, val);
  } else if (O[key]) {
    O[key] = val;
  } else {
    hide(O, key, val);
  }
// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
})(Function.prototype, TO_STRING, function toString() {
  return typeof this == 'function' && this[SRC] || $toString.call(this);
});


/***/ }),

/***/ "./node_modules/core-js/modules/_same-value.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_same-value.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// 7.2.9 SameValue(x, y)
module.exports = Object.is || function is(x, y) {
  // eslint-disable-next-line no-self-compare
  return x === y ? x !== 0 || 1 / x === 1 / y : x != x && y != y;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_set-proto.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_set-proto.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Works with __proto__ only. Old v8 can't work with null proto objects.
/* eslint-disable no-proto */
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var check = function (O, proto) {
  anObject(O);
  if (!isObject(proto) && proto !== null) throw TypeError(proto + ": can't set as prototype!");
};
module.exports = {
  set: Object.setPrototypeOf || ('__proto__' in {} ? // eslint-disable-line
    function (test, buggy, set) {
      try {
        set = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js")(Function.call, __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js").f(Object.prototype, '__proto__').set, 2);
        set(test, []);
        buggy = !(test instanceof Array);
      } catch (e) { buggy = true; }
      return function setPrototypeOf(O, proto) {
        check(O, proto);
        if (buggy) O.__proto__ = proto;
        else set(O, proto);
        return O;
      };
    }({}, false) : undefined),
  check: check
};


/***/ }),

/***/ "./node_modules/core-js/modules/_set-species.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_set-species.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var SPECIES = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('species');

module.exports = function (KEY) {
  var C = global[KEY];
  if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
    configurable: true,
    get: function () { return this; }
  });
};


/***/ }),

/***/ "./node_modules/core-js/modules/_set-to-string-tag.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_set-to-string-tag.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var def = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f;
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var TAG = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('toStringTag');

module.exports = function (it, tag, stat) {
  if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
};


/***/ }),

/***/ "./node_modules/core-js/modules/_shared-key.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_shared-key.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var shared = __webpack_require__(/*! ./_shared */ "./node_modules/core-js/modules/_shared.js")('keys');
var uid = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js");
module.exports = function (key) {
  return shared[key] || (shared[key] = uid(key));
};


/***/ }),

/***/ "./node_modules/core-js/modules/_shared.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/_shared.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js");
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var SHARED = '__core-js_shared__';
var store = global[SHARED] || (global[SHARED] = {});

(module.exports = function (key, value) {
  return store[key] || (store[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: core.version,
  mode: __webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js") ? 'pure' : 'global',
  copyright: '© 2018 Denis Pushkarev (zloirock.ru)'
});


/***/ }),

/***/ "./node_modules/core-js/modules/_strict-method.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_strict-method.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");

module.exports = function (method, arg) {
  return !!method && fails(function () {
    // eslint-disable-next-line no-useless-call
    arg ? method.call(null, function () { /* empty */ }, 1) : method.call(null);
  });
};


/***/ }),

/***/ "./node_modules/core-js/modules/_string-at.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_string-at.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
// true  -> String#at
// false -> String#codePointAt
module.exports = function (TO_STRING) {
  return function (that, pos) {
    var s = String(defined(that));
    var i = toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};


/***/ }),

/***/ "./node_modules/core-js/modules/_string-context.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/_string-context.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// helper for String#{startsWith, endsWith, includes}
var isRegExp = __webpack_require__(/*! ./_is-regexp */ "./node_modules/core-js/modules/_is-regexp.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");

module.exports = function (that, searchString, NAME) {
  if (isRegExp(searchString)) throw TypeError('String#' + NAME + " doesn't accept regex!");
  return String(defined(that));
};


/***/ }),

/***/ "./node_modules/core-js/modules/_string-html.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_string-html.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
var quot = /"/g;
// B.2.3.2.1 CreateHTML(string, tag, attribute, value)
var createHTML = function (string, tag, attribute, value) {
  var S = String(defined(string));
  var p1 = '<' + tag;
  if (attribute !== '') p1 += ' ' + attribute + '="' + String(value).replace(quot, '&quot;') + '"';
  return p1 + '>' + S + '</' + tag + '>';
};
module.exports = function (NAME, exec) {
  var O = {};
  O[NAME] = exec(createHTML);
  $export($export.P + $export.F * fails(function () {
    var test = ''[NAME]('"');
    return test !== test.toLowerCase() || test.split('"').length > 3;
  }), 'String', O);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_string-repeat.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_string-repeat.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");

module.exports = function repeat(count) {
  var str = String(defined(this));
  var res = '';
  var n = toInteger(count);
  if (n < 0 || n == Infinity) throw RangeError("Count can't be negative");
  for (;n > 0; (n >>>= 1) && (str += str)) if (n & 1) res += str;
  return res;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_string-trim.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_string-trim.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var spaces = __webpack_require__(/*! ./_string-ws */ "./node_modules/core-js/modules/_string-ws.js");
var space = '[' + spaces + ']';
var non = '\u200b\u0085';
var ltrim = RegExp('^' + space + space + '*');
var rtrim = RegExp(space + space + '*$');

var exporter = function (KEY, exec, ALIAS) {
  var exp = {};
  var FORCE = fails(function () {
    return !!spaces[KEY]() || non[KEY]() != non;
  });
  var fn = exp[KEY] = FORCE ? exec(trim) : spaces[KEY];
  if (ALIAS) exp[ALIAS] = fn;
  $export($export.P + $export.F * FORCE, 'String', exp);
};

// 1 -> String#trimLeft
// 2 -> String#trimRight
// 3 -> String#trim
var trim = exporter.trim = function (string, TYPE) {
  string = String(defined(string));
  if (TYPE & 1) string = string.replace(ltrim, '');
  if (TYPE & 2) string = string.replace(rtrim, '');
  return string;
};

module.exports = exporter;


/***/ }),

/***/ "./node_modules/core-js/modules/_string-ws.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_string-ws.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = '\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003' +
  '\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';


/***/ }),

/***/ "./node_modules/core-js/modules/_to-absolute-index.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_to-absolute-index.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var max = Math.max;
var min = Math.min;
module.exports = function (index, length) {
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_to-integer.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_to-integer.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};


/***/ }),

/***/ "./node_modules/core-js/modules/_to-iobject.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_to-iobject.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = __webpack_require__(/*! ./_iobject */ "./node_modules/core-js/modules/_iobject.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
module.exports = function (it) {
  return IObject(defined(it));
};


/***/ }),

/***/ "./node_modules/core-js/modules/_to-length.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_to-length.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.15 ToLength
var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var min = Math.min;
module.exports = function (it) {
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};


/***/ }),

/***/ "./node_modules/core-js/modules/_to-object.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_to-object.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.13 ToObject(argument)
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
module.exports = function (it) {
  return Object(defined(it));
};


/***/ }),

/***/ "./node_modules/core-js/modules/_to-primitive.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/_to-primitive.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};


/***/ }),

/***/ "./node_modules/core-js/modules/_uid.js":
/*!**********************************************!*\
  !*** ./node_modules/core-js/modules/_uid.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var id = 0;
var px = Math.random();
module.exports = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};


/***/ }),

/***/ "./node_modules/core-js/modules/_validate-collection.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/_validate-collection.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
module.exports = function (it, TYPE) {
  if (!isObject(it) || it._t !== TYPE) throw TypeError('Incompatible receiver, ' + TYPE + ' required!');
  return it;
};


/***/ }),

/***/ "./node_modules/core-js/modules/_wks-define.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_wks-define.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var core = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js");
var LIBRARY = __webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js");
var wksExt = __webpack_require__(/*! ./_wks-ext */ "./node_modules/core-js/modules/_wks-ext.js");
var defineProperty = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f;
module.exports = function (name) {
  var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
  if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
};


/***/ }),

/***/ "./node_modules/core-js/modules/_wks-ext.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_wks-ext.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports.f = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js");


/***/ }),

/***/ "./node_modules/core-js/modules/_wks.js":
/*!**********************************************!*\
  !*** ./node_modules/core-js/modules/_wks.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var store = __webpack_require__(/*! ./_shared */ "./node_modules/core-js/modules/_shared.js")('wks');
var uid = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js");
var Symbol = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
};

$exports.store = store;


/***/ }),

/***/ "./node_modules/core-js/modules/core.get-iterator-method.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/core.get-iterator-method.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var classof = __webpack_require__(/*! ./_classof */ "./node_modules/core-js/modules/_classof.js");
var ITERATOR = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('iterator');
var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
module.exports = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js").getIteratorMethod = function (it) {
  if (it != undefined) return it[ITERATOR]
    || it['@@iterator']
    || Iterators[classof(it)];
};


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.copy-within.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.copy-within.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.P, 'Array', { copyWithin: __webpack_require__(/*! ./_array-copy-within */ "./node_modules/core-js/modules/_array-copy-within.js") });

__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")('copyWithin');


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.every.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.every.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $every = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(4);

$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].every, true), 'Array', {
  // 22.1.3.5 / 15.4.4.16 Array.prototype.every(callbackfn [, thisArg])
  every: function every(callbackfn /* , thisArg */) {
    return $every(this, callbackfn, arguments[1]);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.fill.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.fill.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.P, 'Array', { fill: __webpack_require__(/*! ./_array-fill */ "./node_modules/core-js/modules/_array-fill.js") });

__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")('fill');


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.filter.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.filter.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $filter = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(2);

$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].filter, true), 'Array', {
  // 22.1.3.7 / 15.4.4.20 Array.prototype.filter(callbackfn [, thisArg])
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments[1]);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.find-index.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.find-index.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.9 Array.prototype.findIndex(predicate, thisArg = undefined)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $find = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(6);
var KEY = 'findIndex';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () { forced = false; });
$export($export.P + $export.F * forced, 'Array', {
  findIndex: function findIndex(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")(KEY);


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.find.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.find.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.8 Array.prototype.find(predicate, thisArg = undefined)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $find = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(5);
var KEY = 'find';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () { forced = false; });
$export($export.P + $export.F * forced, 'Array', {
  find: function find(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")(KEY);


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.for-each.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.for-each.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $forEach = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(0);
var STRICT = __webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].forEach, true);

$export($export.P + $export.F * !STRICT, 'Array', {
  // 22.1.3.10 / 15.4.4.18 Array.prototype.forEach(callbackfn [, thisArg])
  forEach: function forEach(callbackfn /* , thisArg */) {
    return $forEach(this, callbackfn, arguments[1]);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.from.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.from.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var call = __webpack_require__(/*! ./_iter-call */ "./node_modules/core-js/modules/_iter-call.js");
var isArrayIter = __webpack_require__(/*! ./_is-array-iter */ "./node_modules/core-js/modules/_is-array-iter.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var createProperty = __webpack_require__(/*! ./_create-property */ "./node_modules/core-js/modules/_create-property.js");
var getIterFn = __webpack_require__(/*! ./core.get-iterator-method */ "./node_modules/core-js/modules/core.get-iterator-method.js");

$export($export.S + $export.F * !__webpack_require__(/*! ./_iter-detect */ "./node_modules/core-js/modules/_iter-detect.js")(function (iter) { Array.from(iter); }), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
    var O = toObject(arrayLike);
    var C = typeof this == 'function' ? this : Array;
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var index = 0;
    var iterFn = getIterFn(O);
    var length, result, step, iterator;
    if (mapping) mapfn = ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if (iterFn != undefined && !(C == Array && isArrayIter(iterFn))) {
      for (iterator = iterFn.call(O), result = new C(); !(step = iterator.next()).done; index++) {
        createProperty(result, index, mapping ? call(iterator, mapfn, [step.value, index], true) : step.value);
      }
    } else {
      length = toLength(O.length);
      for (result = new C(length); length > index; index++) {
        createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
      }
    }
    result.length = index;
    return result;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.index-of.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.index-of.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $indexOf = __webpack_require__(/*! ./_array-includes */ "./node_modules/core-js/modules/_array-includes.js")(false);
var $native = [].indexOf;
var NEGATIVE_ZERO = !!$native && 1 / [1].indexOf(1, -0) < 0;

$export($export.P + $export.F * (NEGATIVE_ZERO || !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")($native)), 'Array', {
  // 22.1.3.11 / 15.4.4.14 Array.prototype.indexOf(searchElement [, fromIndex])
  indexOf: function indexOf(searchElement /* , fromIndex = 0 */) {
    return NEGATIVE_ZERO
      // convert -0 to +0
      ? $native.apply(this, arguments) || 0
      : $indexOf(this, searchElement, arguments[1]);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.is-array.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.is-array.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.2.2 / 15.4.3.2 Array.isArray(arg)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Array', { isArray: __webpack_require__(/*! ./_is-array */ "./node_modules/core-js/modules/_is-array.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.iterator.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.iterator.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var addToUnscopables = __webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js");
var step = __webpack_require__(/*! ./_iter-step */ "./node_modules/core-js/modules/_iter-step.js");
var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = __webpack_require__(/*! ./_iter-define */ "./node_modules/core-js/modules/_iter-define.js")(Array, 'Array', function (iterated, kind) {
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return step(1);
  }
  if (kind == 'keys') return step(0, index);
  if (kind == 'values') return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.join.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.join.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.13 Array.prototype.join(separator)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var arrayJoin = [].join;

// fallback for not array-like strings
$export($export.P + $export.F * (__webpack_require__(/*! ./_iobject */ "./node_modules/core-js/modules/_iobject.js") != Object || !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")(arrayJoin)), 'Array', {
  join: function join(separator) {
    return arrayJoin.call(toIObject(this), separator === undefined ? ',' : separator);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.last-index-of.js":
/*!*****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.last-index-of.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var $native = [].lastIndexOf;
var NEGATIVE_ZERO = !!$native && 1 / [1].lastIndexOf(1, -0) < 0;

$export($export.P + $export.F * (NEGATIVE_ZERO || !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")($native)), 'Array', {
  // 22.1.3.14 / 15.4.4.15 Array.prototype.lastIndexOf(searchElement [, fromIndex])
  lastIndexOf: function lastIndexOf(searchElement /* , fromIndex = @[*-1] */) {
    // convert -0 to +0
    if (NEGATIVE_ZERO) return $native.apply(this, arguments) || 0;
    var O = toIObject(this);
    var length = toLength(O.length);
    var index = length - 1;
    if (arguments.length > 1) index = Math.min(index, toInteger(arguments[1]));
    if (index < 0) index = length + index;
    for (;index >= 0; index--) if (index in O) if (O[index] === searchElement) return index || 0;
    return -1;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.map.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.map.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $map = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(1);

$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].map, true), 'Array', {
  // 22.1.3.15 / 15.4.4.19 Array.prototype.map(callbackfn [, thisArg])
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments[1]);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.of.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.of.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var createProperty = __webpack_require__(/*! ./_create-property */ "./node_modules/core-js/modules/_create-property.js");

// WebKit Array.of isn't generic
$export($export.S + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  function F() { /* empty */ }
  return !(Array.of.call(F) instanceof F);
}), 'Array', {
  // 22.1.2.3 Array.of( ...items)
  of: function of(/* ...args */) {
    var index = 0;
    var aLen = arguments.length;
    var result = new (typeof this == 'function' ? this : Array)(aLen);
    while (aLen > index) createProperty(result, index, arguments[index++]);
    result.length = aLen;
    return result;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.reduce-right.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.reduce-right.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $reduce = __webpack_require__(/*! ./_array-reduce */ "./node_modules/core-js/modules/_array-reduce.js");

$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].reduceRight, true), 'Array', {
  // 22.1.3.19 / 15.4.4.22 Array.prototype.reduceRight(callbackfn [, initialValue])
  reduceRight: function reduceRight(callbackfn /* , initialValue */) {
    return $reduce(this, callbackfn, arguments.length, arguments[1], true);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.reduce.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.reduce.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $reduce = __webpack_require__(/*! ./_array-reduce */ "./node_modules/core-js/modules/_array-reduce.js");

$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].reduce, true), 'Array', {
  // 22.1.3.18 / 15.4.4.21 Array.prototype.reduce(callbackfn [, initialValue])
  reduce: function reduce(callbackfn /* , initialValue */) {
    return $reduce(this, callbackfn, arguments.length, arguments[1], false);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.slice.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.slice.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var html = __webpack_require__(/*! ./_html */ "./node_modules/core-js/modules/_html.js");
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var arraySlice = [].slice;

// fallback for not array-like ES3 strings and DOM objects
$export($export.P + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  if (html) arraySlice.call(html);
}), 'Array', {
  slice: function slice(begin, end) {
    var len = toLength(this.length);
    var klass = cof(this);
    end = end === undefined ? len : end;
    if (klass == 'Array') return arraySlice.call(this, begin, end);
    var start = toAbsoluteIndex(begin, len);
    var upTo = toAbsoluteIndex(end, len);
    var size = toLength(upTo - start);
    var cloned = new Array(size);
    var i = 0;
    for (; i < size; i++) cloned[i] = klass == 'String'
      ? this.charAt(start + i)
      : this[start + i];
    return cloned;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.some.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.some.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $some = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(3);

$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].some, true), 'Array', {
  // 22.1.3.23 / 15.4.4.17 Array.prototype.some(callbackfn [, thisArg])
  some: function some(callbackfn /* , thisArg */) {
    return $some(this, callbackfn, arguments[1]);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.sort.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.sort.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var $sort = [].sort;
var test = [1, 2, 3];

$export($export.P + $export.F * (fails(function () {
  // IE8-
  test.sort(undefined);
}) || !fails(function () {
  // V8 bug
  test.sort(null);
  // Old WebKit
}) || !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")($sort)), 'Array', {
  // 22.1.3.25 Array.prototype.sort(comparefn)
  sort: function sort(comparefn) {
    return comparefn === undefined
      ? $sort.call(toObject(this))
      : $sort.call(toObject(this), aFunction(comparefn));
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.species.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.species.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! ./_set-species */ "./node_modules/core-js/modules/_set-species.js")('Array');


/***/ }),

/***/ "./node_modules/core-js/modules/es6.date.now.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.date.now.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.3.3.1 / 15.9.4.4 Date.now()
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Date', { now: function () { return new Date().getTime(); } });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.date.to-iso-string.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.date.to-iso-string.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toISOString = __webpack_require__(/*! ./_date-to-iso-string */ "./node_modules/core-js/modules/_date-to-iso-string.js");

// PhantomJS / old WebKit has a broken implementations
$export($export.P + $export.F * (Date.prototype.toISOString !== toISOString), 'Date', {
  toISOString: toISOString
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.date.to-json.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.date.to-json.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");

$export($export.P + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return new Date(NaN).toJSON() !== null
    || Date.prototype.toJSON.call({ toISOString: function () { return 1; } }) !== 1;
}), 'Date', {
  // eslint-disable-next-line no-unused-vars
  toJSON: function toJSON(key) {
    var O = toObject(this);
    var pv = toPrimitive(O);
    return typeof pv == 'number' && !isFinite(pv) ? null : O.toISOString();
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.date.to-primitive.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.date.to-primitive.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var TO_PRIMITIVE = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('toPrimitive');
var proto = Date.prototype;

if (!(TO_PRIMITIVE in proto)) __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js")(proto, TO_PRIMITIVE, __webpack_require__(/*! ./_date-to-primitive */ "./node_modules/core-js/modules/_date-to-primitive.js"));


/***/ }),

/***/ "./node_modules/core-js/modules/es6.date.to-string.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.date.to-string.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var DateProto = Date.prototype;
var INVALID_DATE = 'Invalid Date';
var TO_STRING = 'toString';
var $toString = DateProto[TO_STRING];
var getTime = DateProto.getTime;
if (new Date(NaN) + '' != INVALID_DATE) {
  __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js")(DateProto, TO_STRING, function toString() {
    var value = getTime.call(this);
    // eslint-disable-next-line no-self-compare
    return value === value ? $toString.call(this) : INVALID_DATE;
  });
}


/***/ }),

/***/ "./node_modules/core-js/modules/es6.function.bind.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.function.bind.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.2.3.2 / 15.3.4.5 Function.prototype.bind(thisArg, args...)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.P, 'Function', { bind: __webpack_require__(/*! ./_bind */ "./node_modules/core-js/modules/_bind.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.function.has-instance.js":
/*!*******************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.function.has-instance.js ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var HAS_INSTANCE = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('hasInstance');
var FunctionProto = Function.prototype;
// 19.2.3.6 Function.prototype[@@hasInstance](V)
if (!(HAS_INSTANCE in FunctionProto)) __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f(FunctionProto, HAS_INSTANCE, { value: function (O) {
  if (typeof this != 'function' || !isObject(O)) return false;
  if (!isObject(this.prototype)) return O instanceof this;
  // for environment w/o native `@@hasInstance` logic enough `instanceof`, but add this:
  while (O = getPrototypeOf(O)) if (this.prototype === O) return true;
  return false;
} });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.function.name.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.function.name.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f;
var FProto = Function.prototype;
var nameRE = /^\s*function ([^ (]*)/;
var NAME = 'name';

// 19.2.4.2 name
NAME in FProto || __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && dP(FProto, NAME, {
  configurable: true,
  get: function () {
    try {
      return ('' + this).match(nameRE)[1];
    } catch (e) {
      return '';
    }
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.map.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/es6.map.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var strong = __webpack_require__(/*! ./_collection-strong */ "./node_modules/core-js/modules/_collection-strong.js");
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var MAP = 'Map';

// 23.1 Map Objects
module.exports = __webpack_require__(/*! ./_collection */ "./node_modules/core-js/modules/_collection.js")(MAP, function (get) {
  return function Map() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.1.3.6 Map.prototype.get(key)
  get: function get(key) {
    var entry = strong.getEntry(validate(this, MAP), key);
    return entry && entry.v;
  },
  // 23.1.3.9 Map.prototype.set(key, value)
  set: function set(key, value) {
    return strong.def(validate(this, MAP), key === 0 ? 0 : key, value);
  }
}, strong, true);


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.acosh.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.acosh.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.3 Math.acosh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var log1p = __webpack_require__(/*! ./_math-log1p */ "./node_modules/core-js/modules/_math-log1p.js");
var sqrt = Math.sqrt;
var $acosh = Math.acosh;

$export($export.S + $export.F * !($acosh
  // V8 bug: https://code.google.com/p/v8/issues/detail?id=3509
  && Math.floor($acosh(Number.MAX_VALUE)) == 710
  // Tor Browser bug: Math.acosh(Infinity) -> NaN
  && $acosh(Infinity) == Infinity
), 'Math', {
  acosh: function acosh(x) {
    return (x = +x) < 1 ? NaN : x > 94906265.62425156
      ? Math.log(x) + Math.LN2
      : log1p(x - 1 + sqrt(x - 1) * sqrt(x + 1));
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.asinh.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.asinh.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.5 Math.asinh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $asinh = Math.asinh;

function asinh(x) {
  return !isFinite(x = +x) || x == 0 ? x : x < 0 ? -asinh(-x) : Math.log(x + Math.sqrt(x * x + 1));
}

// Tor Browser bug: Math.asinh(0) -> -0
$export($export.S + $export.F * !($asinh && 1 / $asinh(0) > 0), 'Math', { asinh: asinh });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.atanh.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.atanh.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.7 Math.atanh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $atanh = Math.atanh;

// Tor Browser bug: Math.atanh(-0) -> 0
$export($export.S + $export.F * !($atanh && 1 / $atanh(-0) < 0), 'Math', {
  atanh: function atanh(x) {
    return (x = +x) == 0 ? x : Math.log((1 + x) / (1 - x)) / 2;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.cbrt.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.cbrt.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.9 Math.cbrt(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var sign = __webpack_require__(/*! ./_math-sign */ "./node_modules/core-js/modules/_math-sign.js");

$export($export.S, 'Math', {
  cbrt: function cbrt(x) {
    return sign(x = +x) * Math.pow(Math.abs(x), 1 / 3);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.clz32.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.clz32.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.11 Math.clz32(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Math', {
  clz32: function clz32(x) {
    return (x >>>= 0) ? 31 - Math.floor(Math.log(x + 0.5) * Math.LOG2E) : 32;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.cosh.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.cosh.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.12 Math.cosh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var exp = Math.exp;

$export($export.S, 'Math', {
  cosh: function cosh(x) {
    return (exp(x = +x) + exp(-x)) / 2;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.expm1.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.expm1.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.14 Math.expm1(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $expm1 = __webpack_require__(/*! ./_math-expm1 */ "./node_modules/core-js/modules/_math-expm1.js");

$export($export.S + $export.F * ($expm1 != Math.expm1), 'Math', { expm1: $expm1 });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.fround.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.fround.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.16 Math.fround(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Math', { fround: __webpack_require__(/*! ./_math-fround */ "./node_modules/core-js/modules/_math-fround.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.hypot.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.hypot.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.17 Math.hypot([value1[, value2[, … ]]])
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var abs = Math.abs;

$export($export.S, 'Math', {
  hypot: function hypot(value1, value2) { // eslint-disable-line no-unused-vars
    var sum = 0;
    var i = 0;
    var aLen = arguments.length;
    var larg = 0;
    var arg, div;
    while (i < aLen) {
      arg = abs(arguments[i++]);
      if (larg < arg) {
        div = larg / arg;
        sum = sum * div * div + 1;
        larg = arg;
      } else if (arg > 0) {
        div = arg / larg;
        sum += div * div;
      } else sum += arg;
    }
    return larg === Infinity ? Infinity : larg * Math.sqrt(sum);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.imul.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.imul.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.18 Math.imul(x, y)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $imul = Math.imul;

// some WebKit versions fails with big numbers, some has wrong arity
$export($export.S + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return $imul(0xffffffff, 5) != -5 || $imul.length != 2;
}), 'Math', {
  imul: function imul(x, y) {
    var UINT16 = 0xffff;
    var xn = +x;
    var yn = +y;
    var xl = UINT16 & xn;
    var yl = UINT16 & yn;
    return 0 | xl * yl + ((UINT16 & xn >>> 16) * yl + xl * (UINT16 & yn >>> 16) << 16 >>> 0);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.log10.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.log10.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.21 Math.log10(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Math', {
  log10: function log10(x) {
    return Math.log(x) * Math.LOG10E;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.log1p.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.log1p.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.20 Math.log1p(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Math', { log1p: __webpack_require__(/*! ./_math-log1p */ "./node_modules/core-js/modules/_math-log1p.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.log2.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.log2.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.22 Math.log2(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Math', {
  log2: function log2(x) {
    return Math.log(x) / Math.LN2;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.sign.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.sign.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.28 Math.sign(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Math', { sign: __webpack_require__(/*! ./_math-sign */ "./node_modules/core-js/modules/_math-sign.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.sinh.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.sinh.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.30 Math.sinh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var expm1 = __webpack_require__(/*! ./_math-expm1 */ "./node_modules/core-js/modules/_math-expm1.js");
var exp = Math.exp;

// V8 near Chromium 38 has a problem with very small numbers
$export($export.S + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return !Math.sinh(-2e-17) != -2e-17;
}), 'Math', {
  sinh: function sinh(x) {
    return Math.abs(x = +x) < 1
      ? (expm1(x) - expm1(-x)) / 2
      : (exp(x - 1) - exp(-x - 1)) * (Math.E / 2);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.tanh.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.tanh.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.33 Math.tanh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var expm1 = __webpack_require__(/*! ./_math-expm1 */ "./node_modules/core-js/modules/_math-expm1.js");
var exp = Math.exp;

$export($export.S, 'Math', {
  tanh: function tanh(x) {
    var a = expm1(x = +x);
    var b = expm1(-x);
    return a == Infinity ? 1 : b == Infinity ? -1 : (a - b) / (exp(x) + exp(-x));
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.trunc.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.trunc.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.34 Math.trunc(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Math', {
  trunc: function trunc(it) {
    return (it > 0 ? Math.floor : Math.ceil)(it);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.constructor.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.constructor.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
var inheritIfRequired = __webpack_require__(/*! ./_inherit-if-required */ "./node_modules/core-js/modules/_inherit-if-required.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var gOPN = __webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js").f;
var gOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js").f;
var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f;
var $trim = __webpack_require__(/*! ./_string-trim */ "./node_modules/core-js/modules/_string-trim.js").trim;
var NUMBER = 'Number';
var $Number = global[NUMBER];
var Base = $Number;
var proto = $Number.prototype;
// Opera ~12 has broken Object#toString
var BROKEN_COF = cof(__webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js")(proto)) == NUMBER;
var TRIM = 'trim' in String.prototype;

// 7.1.3 ToNumber(argument)
var toNumber = function (argument) {
  var it = toPrimitive(argument, false);
  if (typeof it == 'string' && it.length > 2) {
    it = TRIM ? it.trim() : $trim(it, 3);
    var first = it.charCodeAt(0);
    var third, radix, maxCode;
    if (first === 43 || first === 45) {
      third = it.charCodeAt(2);
      if (third === 88 || third === 120) return NaN; // Number('+0x1') should be NaN, old V8 fix
    } else if (first === 48) {
      switch (it.charCodeAt(1)) {
        case 66: case 98: radix = 2; maxCode = 49; break; // fast equal /^0b[01]+$/i
        case 79: case 111: radix = 8; maxCode = 55; break; // fast equal /^0o[0-7]+$/i
        default: return +it;
      }
      for (var digits = it.slice(2), i = 0, l = digits.length, code; i < l; i++) {
        code = digits.charCodeAt(i);
        // parseInt parses a string to a first unavailable symbol
        // but ToNumber should return NaN if a string contains unavailable symbols
        if (code < 48 || code > maxCode) return NaN;
      } return parseInt(digits, radix);
    }
  } return +it;
};

if (!$Number(' 0o1') || !$Number('0b1') || $Number('+0x1')) {
  $Number = function Number(value) {
    var it = arguments.length < 1 ? 0 : value;
    var that = this;
    return that instanceof $Number
      // check on 1..constructor(foo) case
      && (BROKEN_COF ? fails(function () { proto.valueOf.call(that); }) : cof(that) != NUMBER)
        ? inheritIfRequired(new Base(toNumber(it)), that, $Number) : toNumber(it);
  };
  for (var keys = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") ? gOPN(Base) : (
    // ES3:
    'MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,' +
    // ES6 (in case, if modules with ES6 Number statics required before):
    'EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,' +
    'MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger'
  ).split(','), j = 0, key; keys.length > j; j++) {
    if (has(Base, key = keys[j]) && !has($Number, key)) {
      dP($Number, key, gOPD(Base, key));
    }
  }
  $Number.prototype = proto;
  proto.constructor = $Number;
  __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js")(global, NUMBER, $Number);
}


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.epsilon.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.epsilon.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.1 Number.EPSILON
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Number', { EPSILON: Math.pow(2, -52) });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.is-finite.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.is-finite.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.2 Number.isFinite(number)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var _isFinite = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").isFinite;

$export($export.S, 'Number', {
  isFinite: function isFinite(it) {
    return typeof it == 'number' && _isFinite(it);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.is-integer.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.is-integer.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.3 Number.isInteger(number)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Number', { isInteger: __webpack_require__(/*! ./_is-integer */ "./node_modules/core-js/modules/_is-integer.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.is-nan.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.is-nan.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.4 Number.isNaN(number)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Number', {
  isNaN: function isNaN(number) {
    // eslint-disable-next-line no-self-compare
    return number != number;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.is-safe-integer.js":
/*!********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.is-safe-integer.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.5 Number.isSafeInteger(number)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var isInteger = __webpack_require__(/*! ./_is-integer */ "./node_modules/core-js/modules/_is-integer.js");
var abs = Math.abs;

$export($export.S, 'Number', {
  isSafeInteger: function isSafeInteger(number) {
    return isInteger(number) && abs(number) <= 0x1fffffffffffff;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.max-safe-integer.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.max-safe-integer.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.6 Number.MAX_SAFE_INTEGER
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Number', { MAX_SAFE_INTEGER: 0x1fffffffffffff });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.min-safe-integer.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.min-safe-integer.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.10 Number.MIN_SAFE_INTEGER
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Number', { MIN_SAFE_INTEGER: -0x1fffffffffffff });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.parse-float.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.parse-float.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $parseFloat = __webpack_require__(/*! ./_parse-float */ "./node_modules/core-js/modules/_parse-float.js");
// 20.1.2.12 Number.parseFloat(string)
$export($export.S + $export.F * (Number.parseFloat != $parseFloat), 'Number', { parseFloat: $parseFloat });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.parse-int.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.parse-int.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $parseInt = __webpack_require__(/*! ./_parse-int */ "./node_modules/core-js/modules/_parse-int.js");
// 20.1.2.13 Number.parseInt(string, radix)
$export($export.S + $export.F * (Number.parseInt != $parseInt), 'Number', { parseInt: $parseInt });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.to-fixed.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.to-fixed.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var aNumberValue = __webpack_require__(/*! ./_a-number-value */ "./node_modules/core-js/modules/_a-number-value.js");
var repeat = __webpack_require__(/*! ./_string-repeat */ "./node_modules/core-js/modules/_string-repeat.js");
var $toFixed = 1.0.toFixed;
var floor = Math.floor;
var data = [0, 0, 0, 0, 0, 0];
var ERROR = 'Number.toFixed: incorrect invocation!';
var ZERO = '0';

var multiply = function (n, c) {
  var i = -1;
  var c2 = c;
  while (++i < 6) {
    c2 += n * data[i];
    data[i] = c2 % 1e7;
    c2 = floor(c2 / 1e7);
  }
};
var divide = function (n) {
  var i = 6;
  var c = 0;
  while (--i >= 0) {
    c += data[i];
    data[i] = floor(c / n);
    c = (c % n) * 1e7;
  }
};
var numToString = function () {
  var i = 6;
  var s = '';
  while (--i >= 0) {
    if (s !== '' || i === 0 || data[i] !== 0) {
      var t = String(data[i]);
      s = s === '' ? t : s + repeat.call(ZERO, 7 - t.length) + t;
    }
  } return s;
};
var pow = function (x, n, acc) {
  return n === 0 ? acc : n % 2 === 1 ? pow(x, n - 1, acc * x) : pow(x * x, n / 2, acc);
};
var log = function (x) {
  var n = 0;
  var x2 = x;
  while (x2 >= 4096) {
    n += 12;
    x2 /= 4096;
  }
  while (x2 >= 2) {
    n += 1;
    x2 /= 2;
  } return n;
};

$export($export.P + $export.F * (!!$toFixed && (
  0.00008.toFixed(3) !== '0.000' ||
  0.9.toFixed(0) !== '1' ||
  1.255.toFixed(2) !== '1.25' ||
  1000000000000000128.0.toFixed(0) !== '1000000000000000128'
) || !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  // V8 ~ Android 4.3-
  $toFixed.call({});
})), 'Number', {
  toFixed: function toFixed(fractionDigits) {
    var x = aNumberValue(this, ERROR);
    var f = toInteger(fractionDigits);
    var s = '';
    var m = ZERO;
    var e, z, j, k;
    if (f < 0 || f > 20) throw RangeError(ERROR);
    // eslint-disable-next-line no-self-compare
    if (x != x) return 'NaN';
    if (x <= -1e21 || x >= 1e21) return String(x);
    if (x < 0) {
      s = '-';
      x = -x;
    }
    if (x > 1e-21) {
      e = log(x * pow(2, 69, 1)) - 69;
      z = e < 0 ? x * pow(2, -e, 1) : x / pow(2, e, 1);
      z *= 0x10000000000000;
      e = 52 - e;
      if (e > 0) {
        multiply(0, z);
        j = f;
        while (j >= 7) {
          multiply(1e7, 0);
          j -= 7;
        }
        multiply(pow(10, j, 1), 0);
        j = e - 1;
        while (j >= 23) {
          divide(1 << 23);
          j -= 23;
        }
        divide(1 << j);
        multiply(1, 1);
        divide(2);
        m = numToString();
      } else {
        multiply(0, z);
        multiply(1 << -e, 0);
        m = numToString() + repeat.call(ZERO, f);
      }
    }
    if (f > 0) {
      k = m.length;
      m = s + (k <= f ? '0.' + repeat.call(ZERO, f - k) + m : m.slice(0, k - f) + '.' + m.slice(k - f));
    } else {
      m = s + m;
    } return m;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.to-precision.js":
/*!*****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.to-precision.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var aNumberValue = __webpack_require__(/*! ./_a-number-value */ "./node_modules/core-js/modules/_a-number-value.js");
var $toPrecision = 1.0.toPrecision;

$export($export.P + $export.F * ($fails(function () {
  // IE7-
  return $toPrecision.call(1, undefined) !== '1';
}) || !$fails(function () {
  // V8 ~ Android 4.3-
  $toPrecision.call({});
})), 'Number', {
  toPrecision: function toPrecision(precision) {
    var that = aNumberValue(this, 'Number#toPrecision: incorrect invocation!');
    return precision === undefined ? $toPrecision.call(that) : $toPrecision.call(that, precision);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.assign.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.assign.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.1 Object.assign(target, source)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S + $export.F, 'Object', { assign: __webpack_require__(/*! ./_object-assign */ "./node_modules/core-js/modules/_object-assign.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.create.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.create.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
$export($export.S, 'Object', { create: __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.define-properties.js":
/*!**********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.define-properties.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
// 19.1.2.3 / 15.2.3.7 Object.defineProperties(O, Properties)
$export($export.S + $export.F * !__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js"), 'Object', { defineProperties: __webpack_require__(/*! ./_object-dps */ "./node_modules/core-js/modules/_object-dps.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.define-property.js":
/*!********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.define-property.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js"), 'Object', { defineProperty: __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.freeze.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.freeze.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.5 Object.freeze(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var meta = __webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").onFreeze;

__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('freeze', function ($freeze) {
  return function freeze(it) {
    return $freeze && isObject(it) ? $freeze(meta(it)) : it;
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.get-own-property-descriptor.js":
/*!********************************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.get-own-property-descriptor.js ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var $getOwnPropertyDescriptor = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js").f;

__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('getOwnPropertyDescriptor', function () {
  return function getOwnPropertyDescriptor(it, key) {
    return $getOwnPropertyDescriptor(toIObject(it), key);
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.get-own-property-names.js":
/*!***************************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.get-own-property-names.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 Object.getOwnPropertyNames(O)
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('getOwnPropertyNames', function () {
  return __webpack_require__(/*! ./_object-gopn-ext */ "./node_modules/core-js/modules/_object-gopn-ext.js").f;
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.get-prototype-of.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.get-prototype-of.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 Object.getPrototypeOf(O)
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var $getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");

__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('getPrototypeOf', function () {
  return function getPrototypeOf(it) {
    return $getPrototypeOf(toObject(it));
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.is-extensible.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.is-extensible.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.11 Object.isExtensible(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");

__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('isExtensible', function ($isExtensible) {
  return function isExtensible(it) {
    return isObject(it) ? $isExtensible ? $isExtensible(it) : true : false;
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.is-frozen.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.is-frozen.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.12 Object.isFrozen(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");

__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('isFrozen', function ($isFrozen) {
  return function isFrozen(it) {
    return isObject(it) ? $isFrozen ? $isFrozen(it) : false : true;
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.is-sealed.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.is-sealed.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.13 Object.isSealed(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");

__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('isSealed', function ($isSealed) {
  return function isSealed(it) {
    return isObject(it) ? $isSealed ? $isSealed(it) : false : true;
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.is.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.is.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.10 Object.is(value1, value2)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Object', { is: __webpack_require__(/*! ./_same-value */ "./node_modules/core-js/modules/_same-value.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.keys.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.keys.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 Object.keys(O)
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var $keys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");

__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('keys', function () {
  return function keys(it) {
    return $keys(toObject(it));
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.prevent-extensions.js":
/*!***********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.prevent-extensions.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.15 Object.preventExtensions(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var meta = __webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").onFreeze;

__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('preventExtensions', function ($preventExtensions) {
  return function preventExtensions(it) {
    return $preventExtensions && isObject(it) ? $preventExtensions(meta(it)) : it;
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.seal.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.seal.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.17 Object.seal(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var meta = __webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").onFreeze;

__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('seal', function ($seal) {
  return function seal(it) {
    return $seal && isObject(it) ? $seal(meta(it)) : it;
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.set-prototype-of.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.set-prototype-of.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.19 Object.setPrototypeOf(O, proto)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Object', { setPrototypeOf: __webpack_require__(/*! ./_set-proto */ "./node_modules/core-js/modules/_set-proto.js").set });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.to-string.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.to-string.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 19.1.3.6 Object.prototype.toString()
var classof = __webpack_require__(/*! ./_classof */ "./node_modules/core-js/modules/_classof.js");
var test = {};
test[__webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('toStringTag')] = 'z';
if (test + '' != '[object z]') {
  __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js")(Object.prototype, 'toString', function toString() {
    return '[object ' + classof(this) + ']';
  }, true);
}


/***/ }),

/***/ "./node_modules/core-js/modules/es6.parse-float.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.parse-float.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $parseFloat = __webpack_require__(/*! ./_parse-float */ "./node_modules/core-js/modules/_parse-float.js");
// 18.2.4 parseFloat(string)
$export($export.G + $export.F * (parseFloat != $parseFloat), { parseFloat: $parseFloat });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.parse-int.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.parse-int.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $parseInt = __webpack_require__(/*! ./_parse-int */ "./node_modules/core-js/modules/_parse-int.js");
// 18.2.5 parseInt(string, radix)
$export($export.G + $export.F * (parseInt != $parseInt), { parseInt: $parseInt });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.apply.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.apply.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.1 Reflect.apply(target, thisArgument, argumentsList)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var rApply = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").Reflect || {}).apply;
var fApply = Function.apply;
// MS Edge argumentsList argument is optional
$export($export.S + $export.F * !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  rApply(function () { /* empty */ });
}), 'Reflect', {
  apply: function apply(target, thisArgument, argumentsList) {
    var T = aFunction(target);
    var L = anObject(argumentsList);
    return rApply ? rApply(T, thisArgument, L) : fApply.call(T, thisArgument, L);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.construct.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.construct.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.2 Reflect.construct(target, argumentsList [, newTarget])
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var create = __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var bind = __webpack_require__(/*! ./_bind */ "./node_modules/core-js/modules/_bind.js");
var rConstruct = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").Reflect || {}).construct;

// MS Edge supports only 2 arguments and argumentsList argument is optional
// FF Nightly sets third argument as `new.target`, but does not create `this` from it
var NEW_TARGET_BUG = fails(function () {
  function F() { /* empty */ }
  return !(rConstruct(function () { /* empty */ }, [], F) instanceof F);
});
var ARGS_BUG = !fails(function () {
  rConstruct(function () { /* empty */ });
});

$export($export.S + $export.F * (NEW_TARGET_BUG || ARGS_BUG), 'Reflect', {
  construct: function construct(Target, args /* , newTarget */) {
    aFunction(Target);
    anObject(args);
    var newTarget = arguments.length < 3 ? Target : aFunction(arguments[2]);
    if (ARGS_BUG && !NEW_TARGET_BUG) return rConstruct(Target, args, newTarget);
    if (Target == newTarget) {
      // w/o altered newTarget, optimization for 0-4 arguments
      switch (args.length) {
        case 0: return new Target();
        case 1: return new Target(args[0]);
        case 2: return new Target(args[0], args[1]);
        case 3: return new Target(args[0], args[1], args[2]);
        case 4: return new Target(args[0], args[1], args[2], args[3]);
      }
      // w/o altered newTarget, lot of arguments case
      var $args = [null];
      $args.push.apply($args, args);
      return new (bind.apply(Target, $args))();
    }
    // with altered newTarget, not support built-in constructors
    var proto = newTarget.prototype;
    var instance = create(isObject(proto) ? proto : Object.prototype);
    var result = Function.apply.call(Target, instance, args);
    return isObject(result) ? result : instance;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.define-property.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.define-property.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.3 Reflect.defineProperty(target, propertyKey, attributes)
var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");

// MS Edge has broken Reflect.defineProperty - throwing instead of returning false
$export($export.S + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  // eslint-disable-next-line no-undef
  Reflect.defineProperty(dP.f({}, 1, { value: 1 }), 1, { value: 2 });
}), 'Reflect', {
  defineProperty: function defineProperty(target, propertyKey, attributes) {
    anObject(target);
    propertyKey = toPrimitive(propertyKey, true);
    anObject(attributes);
    try {
      dP.f(target, propertyKey, attributes);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.delete-property.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.delete-property.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.4 Reflect.deleteProperty(target, propertyKey)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var gOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js").f;
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");

$export($export.S, 'Reflect', {
  deleteProperty: function deleteProperty(target, propertyKey) {
    var desc = gOPD(anObject(target), propertyKey);
    return desc && !desc.configurable ? false : delete target[propertyKey];
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.enumerate.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.enumerate.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 26.1.5 Reflect.enumerate(target)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var Enumerate = function (iterated) {
  this._t = anObject(iterated); // target
  this._i = 0;                  // next index
  var keys = this._k = [];      // keys
  var key;
  for (key in iterated) keys.push(key);
};
__webpack_require__(/*! ./_iter-create */ "./node_modules/core-js/modules/_iter-create.js")(Enumerate, 'Object', function () {
  var that = this;
  var keys = that._k;
  var key;
  do {
    if (that._i >= keys.length) return { value: undefined, done: true };
  } while (!((key = keys[that._i++]) in that._t));
  return { value: key, done: false };
});

$export($export.S, 'Reflect', {
  enumerate: function enumerate(target) {
    return new Enumerate(target);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.get-own-property-descriptor.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.get-own-property-descriptor.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.7 Reflect.getOwnPropertyDescriptor(target, propertyKey)
var gOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");

$export($export.S, 'Reflect', {
  getOwnPropertyDescriptor: function getOwnPropertyDescriptor(target, propertyKey) {
    return gOPD.f(anObject(target), propertyKey);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.get-prototype-of.js":
/*!**********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.get-prototype-of.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.8 Reflect.getPrototypeOf(target)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var getProto = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");

$export($export.S, 'Reflect', {
  getPrototypeOf: function getPrototypeOf(target) {
    return getProto(anObject(target));
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.get.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.get.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.6 Reflect.get(target, propertyKey [, receiver])
var gOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");

function get(target, propertyKey /* , receiver */) {
  var receiver = arguments.length < 3 ? target : arguments[2];
  var desc, proto;
  if (anObject(target) === receiver) return target[propertyKey];
  if (desc = gOPD.f(target, propertyKey)) return has(desc, 'value')
    ? desc.value
    : desc.get !== undefined
      ? desc.get.call(receiver)
      : undefined;
  if (isObject(proto = getPrototypeOf(target))) return get(proto, propertyKey, receiver);
}

$export($export.S, 'Reflect', { get: get });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.has.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.has.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.9 Reflect.has(target, propertyKey)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Reflect', {
  has: function has(target, propertyKey) {
    return propertyKey in target;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.is-extensible.js":
/*!*******************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.is-extensible.js ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.10 Reflect.isExtensible(target)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var $isExtensible = Object.isExtensible;

$export($export.S, 'Reflect', {
  isExtensible: function isExtensible(target) {
    anObject(target);
    return $isExtensible ? $isExtensible(target) : true;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.own-keys.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.own-keys.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.11 Reflect.ownKeys(target)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.S, 'Reflect', { ownKeys: __webpack_require__(/*! ./_own-keys */ "./node_modules/core-js/modules/_own-keys.js") });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.prevent-extensions.js":
/*!************************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.prevent-extensions.js ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.12 Reflect.preventExtensions(target)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var $preventExtensions = Object.preventExtensions;

$export($export.S, 'Reflect', {
  preventExtensions: function preventExtensions(target) {
    anObject(target);
    try {
      if ($preventExtensions) $preventExtensions(target);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.set-prototype-of.js":
/*!**********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.set-prototype-of.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.14 Reflect.setPrototypeOf(target, proto)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var setProto = __webpack_require__(/*! ./_set-proto */ "./node_modules/core-js/modules/_set-proto.js");

if (setProto) $export($export.S, 'Reflect', {
  setPrototypeOf: function setPrototypeOf(target, proto) {
    setProto.check(target, proto);
    try {
      setProto.set(target, proto);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.set.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.set.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.13 Reflect.set(target, propertyKey, V [, receiver])
var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var gOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var createDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");

function set(target, propertyKey, V /* , receiver */) {
  var receiver = arguments.length < 4 ? target : arguments[3];
  var ownDesc = gOPD.f(anObject(target), propertyKey);
  var existingDescriptor, proto;
  if (!ownDesc) {
    if (isObject(proto = getPrototypeOf(target))) {
      return set(proto, propertyKey, V, receiver);
    }
    ownDesc = createDesc(0);
  }
  if (has(ownDesc, 'value')) {
    if (ownDesc.writable === false || !isObject(receiver)) return false;
    if (existingDescriptor = gOPD.f(receiver, propertyKey)) {
      if (existingDescriptor.get || existingDescriptor.set || existingDescriptor.writable === false) return false;
      existingDescriptor.value = V;
      dP.f(receiver, propertyKey, existingDescriptor);
    } else dP.f(receiver, propertyKey, createDesc(0, V));
    return true;
  }
  return ownDesc.set === undefined ? false : (ownDesc.set.call(receiver, V), true);
}

$export($export.S, 'Reflect', { set: set });


/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.constructor.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.constructor.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var inheritIfRequired = __webpack_require__(/*! ./_inherit-if-required */ "./node_modules/core-js/modules/_inherit-if-required.js");
var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f;
var gOPN = __webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js").f;
var isRegExp = __webpack_require__(/*! ./_is-regexp */ "./node_modules/core-js/modules/_is-regexp.js");
var $flags = __webpack_require__(/*! ./_flags */ "./node_modules/core-js/modules/_flags.js");
var $RegExp = global.RegExp;
var Base = $RegExp;
var proto = $RegExp.prototype;
var re1 = /a/g;
var re2 = /a/g;
// "new" creates a new object, old webkit buggy here
var CORRECT_NEW = new $RegExp(re1) !== re1;

if (__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && (!CORRECT_NEW || __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  re2[__webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('match')] = false;
  // RegExp constructor can alter flags and IsRegExp works correct with @@match
  return $RegExp(re1) != re1 || $RegExp(re2) == re2 || $RegExp(re1, 'i') != '/a/i';
}))) {
  $RegExp = function RegExp(p, f) {
    var tiRE = this instanceof $RegExp;
    var piRE = isRegExp(p);
    var fiU = f === undefined;
    return !tiRE && piRE && p.constructor === $RegExp && fiU ? p
      : inheritIfRequired(CORRECT_NEW
        ? new Base(piRE && !fiU ? p.source : p, f)
        : Base((piRE = p instanceof $RegExp) ? p.source : p, piRE && fiU ? $flags.call(p) : f)
      , tiRE ? this : proto, $RegExp);
  };
  var proxy = function (key) {
    key in $RegExp || dP($RegExp, key, {
      configurable: true,
      get: function () { return Base[key]; },
      set: function (it) { Base[key] = it; }
    });
  };
  for (var keys = gOPN(Base), i = 0; keys.length > i;) proxy(keys[i++]);
  proto.constructor = $RegExp;
  $RegExp.prototype = proto;
  __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js")(global, 'RegExp', $RegExp);
}

__webpack_require__(/*! ./_set-species */ "./node_modules/core-js/modules/_set-species.js")('RegExp');


/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.flags.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.flags.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// 21.2.5.3 get RegExp.prototype.flags()
if (__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && /./g.flags != 'g') __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f(RegExp.prototype, 'flags', {
  configurable: true,
  get: __webpack_require__(/*! ./_flags */ "./node_modules/core-js/modules/_flags.js")
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.match.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.match.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// @@match logic
__webpack_require__(/*! ./_fix-re-wks */ "./node_modules/core-js/modules/_fix-re-wks.js")('match', 1, function (defined, MATCH, $match) {
  // 21.1.3.11 String.prototype.match(regexp)
  return [function match(regexp) {
    'use strict';
    var O = defined(this);
    var fn = regexp == undefined ? undefined : regexp[MATCH];
    return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[MATCH](String(O));
  }, $match];
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.replace.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.replace.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// @@replace logic
__webpack_require__(/*! ./_fix-re-wks */ "./node_modules/core-js/modules/_fix-re-wks.js")('replace', 2, function (defined, REPLACE, $replace) {
  // 21.1.3.14 String.prototype.replace(searchValue, replaceValue)
  return [function replace(searchValue, replaceValue) {
    'use strict';
    var O = defined(this);
    var fn = searchValue == undefined ? undefined : searchValue[REPLACE];
    return fn !== undefined
      ? fn.call(searchValue, O, replaceValue)
      : $replace.call(String(O), searchValue, replaceValue);
  }, $replace];
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.search.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.search.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// @@search logic
__webpack_require__(/*! ./_fix-re-wks */ "./node_modules/core-js/modules/_fix-re-wks.js")('search', 1, function (defined, SEARCH, $search) {
  // 21.1.3.15 String.prototype.search(regexp)
  return [function search(regexp) {
    'use strict';
    var O = defined(this);
    var fn = regexp == undefined ? undefined : regexp[SEARCH];
    return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[SEARCH](String(O));
  }, $search];
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.split.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.split.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// @@split logic
__webpack_require__(/*! ./_fix-re-wks */ "./node_modules/core-js/modules/_fix-re-wks.js")('split', 2, function (defined, SPLIT, $split) {
  'use strict';
  var isRegExp = __webpack_require__(/*! ./_is-regexp */ "./node_modules/core-js/modules/_is-regexp.js");
  var _split = $split;
  var $push = [].push;
  var $SPLIT = 'split';
  var LENGTH = 'length';
  var LAST_INDEX = 'lastIndex';
  if (
    'abbc'[$SPLIT](/(b)*/)[1] == 'c' ||
    'test'[$SPLIT](/(?:)/, -1)[LENGTH] != 4 ||
    'ab'[$SPLIT](/(?:ab)*/)[LENGTH] != 2 ||
    '.'[$SPLIT](/(.?)(.?)/)[LENGTH] != 4 ||
    '.'[$SPLIT](/()()/)[LENGTH] > 1 ||
    ''[$SPLIT](/.?/)[LENGTH]
  ) {
    var NPCG = /()??/.exec('')[1] === undefined; // nonparticipating capturing group
    // based on es5-shim implementation, need to rework it
    $split = function (separator, limit) {
      var string = String(this);
      if (separator === undefined && limit === 0) return [];
      // If `separator` is not a regex, use native split
      if (!isRegExp(separator)) return _split.call(string, separator, limit);
      var output = [];
      var flags = (separator.ignoreCase ? 'i' : '') +
                  (separator.multiline ? 'm' : '') +
                  (separator.unicode ? 'u' : '') +
                  (separator.sticky ? 'y' : '');
      var lastLastIndex = 0;
      var splitLimit = limit === undefined ? 4294967295 : limit >>> 0;
      // Make `global` and avoid `lastIndex` issues by working with a copy
      var separatorCopy = new RegExp(separator.source, flags + 'g');
      var separator2, match, lastIndex, lastLength, i;
      // Doesn't need flags gy, but they don't hurt
      if (!NPCG) separator2 = new RegExp('^' + separatorCopy.source + '$(?!\\s)', flags);
      while (match = separatorCopy.exec(string)) {
        // `separatorCopy.lastIndex` is not reliable cross-browser
        lastIndex = match.index + match[0][LENGTH];
        if (lastIndex > lastLastIndex) {
          output.push(string.slice(lastLastIndex, match.index));
          // Fix browsers whose `exec` methods don't consistently return `undefined` for NPCG
          // eslint-disable-next-line no-loop-func
          if (!NPCG && match[LENGTH] > 1) match[0].replace(separator2, function () {
            for (i = 1; i < arguments[LENGTH] - 2; i++) if (arguments[i] === undefined) match[i] = undefined;
          });
          if (match[LENGTH] > 1 && match.index < string[LENGTH]) $push.apply(output, match.slice(1));
          lastLength = match[0][LENGTH];
          lastLastIndex = lastIndex;
          if (output[LENGTH] >= splitLimit) break;
        }
        if (separatorCopy[LAST_INDEX] === match.index) separatorCopy[LAST_INDEX]++; // Avoid an infinite loop
      }
      if (lastLastIndex === string[LENGTH]) {
        if (lastLength || !separatorCopy.test('')) output.push('');
      } else output.push(string.slice(lastLastIndex));
      return output[LENGTH] > splitLimit ? output.slice(0, splitLimit) : output;
    };
  // Chakra, V8
  } else if ('0'[$SPLIT](undefined, 0)[LENGTH]) {
    $split = function (separator, limit) {
      return separator === undefined && limit === 0 ? [] : _split.call(this, separator, limit);
    };
  }
  // 21.1.3.17 String.prototype.split(separator, limit)
  return [function split(separator, limit) {
    var O = defined(this);
    var fn = separator == undefined ? undefined : separator[SPLIT];
    return fn !== undefined ? fn.call(separator, O, limit) : $split.call(String(O), separator, limit);
  }, $split];
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.to-string.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.to-string.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

__webpack_require__(/*! ./es6.regexp.flags */ "./node_modules/core-js/modules/es6.regexp.flags.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var $flags = __webpack_require__(/*! ./_flags */ "./node_modules/core-js/modules/_flags.js");
var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var TO_STRING = 'toString';
var $toString = /./[TO_STRING];

var define = function (fn) {
  __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js")(RegExp.prototype, TO_STRING, fn, true);
};

// 21.2.5.14 RegExp.prototype.toString()
if (__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () { return $toString.call({ source: 'a', flags: 'b' }) != '/a/b'; })) {
  define(function toString() {
    var R = anObject(this);
    return '/'.concat(R.source, '/',
      'flags' in R ? R.flags : !DESCRIPTORS && R instanceof RegExp ? $flags.call(R) : undefined);
  });
// FF44- RegExp#toString has a wrong name
} else if ($toString.name != TO_STRING) {
  define(function toString() {
    return $toString.call(this);
  });
}


/***/ }),

/***/ "./node_modules/core-js/modules/es6.set.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/es6.set.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var strong = __webpack_require__(/*! ./_collection-strong */ "./node_modules/core-js/modules/_collection-strong.js");
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var SET = 'Set';

// 23.2 Set Objects
module.exports = __webpack_require__(/*! ./_collection */ "./node_modules/core-js/modules/_collection.js")(SET, function (get) {
  return function Set() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.2.3.1 Set.prototype.add(value)
  add: function add(value) {
    return strong.def(validate(this, SET), value = value === 0 ? 0 : value, value);
  }
}, strong);


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.anchor.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.anchor.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.2 String.prototype.anchor(name)
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('anchor', function (createHTML) {
  return function anchor(name) {
    return createHTML(this, 'a', 'name', name);
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.big.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.big.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.3 String.prototype.big()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('big', function (createHTML) {
  return function big() {
    return createHTML(this, 'big', '', '');
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.blink.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.blink.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.4 String.prototype.blink()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('blink', function (createHTML) {
  return function blink() {
    return createHTML(this, 'blink', '', '');
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.bold.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.bold.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.5 String.prototype.bold()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('bold', function (createHTML) {
  return function bold() {
    return createHTML(this, 'b', '', '');
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.code-point-at.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.code-point-at.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $at = __webpack_require__(/*! ./_string-at */ "./node_modules/core-js/modules/_string-at.js")(false);
$export($export.P, 'String', {
  // 21.1.3.3 String.prototype.codePointAt(pos)
  codePointAt: function codePointAt(pos) {
    return $at(this, pos);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.ends-with.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.ends-with.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.6 String.prototype.endsWith(searchString [, endPosition])

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var context = __webpack_require__(/*! ./_string-context */ "./node_modules/core-js/modules/_string-context.js");
var ENDS_WITH = 'endsWith';
var $endsWith = ''[ENDS_WITH];

$export($export.P + $export.F * __webpack_require__(/*! ./_fails-is-regexp */ "./node_modules/core-js/modules/_fails-is-regexp.js")(ENDS_WITH), 'String', {
  endsWith: function endsWith(searchString /* , endPosition = @length */) {
    var that = context(this, searchString, ENDS_WITH);
    var endPosition = arguments.length > 1 ? arguments[1] : undefined;
    var len = toLength(that.length);
    var end = endPosition === undefined ? len : Math.min(toLength(endPosition), len);
    var search = String(searchString);
    return $endsWith
      ? $endsWith.call(that, search, end)
      : that.slice(end - search.length, end) === search;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.fixed.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.fixed.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.6 String.prototype.fixed()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('fixed', function (createHTML) {
  return function fixed() {
    return createHTML(this, 'tt', '', '');
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.fontcolor.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.fontcolor.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.7 String.prototype.fontcolor(color)
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('fontcolor', function (createHTML) {
  return function fontcolor(color) {
    return createHTML(this, 'font', 'color', color);
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.fontsize.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.fontsize.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.8 String.prototype.fontsize(size)
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('fontsize', function (createHTML) {
  return function fontsize(size) {
    return createHTML(this, 'font', 'size', size);
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.from-code-point.js":
/*!********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.from-code-point.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
var fromCharCode = String.fromCharCode;
var $fromCodePoint = String.fromCodePoint;

// length should be 1, old FF problem
$export($export.S + $export.F * (!!$fromCodePoint && $fromCodePoint.length != 1), 'String', {
  // 21.1.2.2 String.fromCodePoint(...codePoints)
  fromCodePoint: function fromCodePoint(x) { // eslint-disable-line no-unused-vars
    var res = [];
    var aLen = arguments.length;
    var i = 0;
    var code;
    while (aLen > i) {
      code = +arguments[i++];
      if (toAbsoluteIndex(code, 0x10ffff) !== code) throw RangeError(code + ' is not a valid code point');
      res.push(code < 0x10000
        ? fromCharCode(code)
        : fromCharCode(((code -= 0x10000) >> 10) + 0xd800, code % 0x400 + 0xdc00)
      );
    } return res.join('');
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.includes.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.includes.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.7 String.prototype.includes(searchString, position = 0)

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var context = __webpack_require__(/*! ./_string-context */ "./node_modules/core-js/modules/_string-context.js");
var INCLUDES = 'includes';

$export($export.P + $export.F * __webpack_require__(/*! ./_fails-is-regexp */ "./node_modules/core-js/modules/_fails-is-regexp.js")(INCLUDES), 'String', {
  includes: function includes(searchString /* , position = 0 */) {
    return !!~context(this, searchString, INCLUDES)
      .indexOf(searchString, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.italics.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.italics.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.9 String.prototype.italics()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('italics', function (createHTML) {
  return function italics() {
    return createHTML(this, 'i', '', '');
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.iterator.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.iterator.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $at = __webpack_require__(/*! ./_string-at */ "./node_modules/core-js/modules/_string-at.js")(true);

// 21.1.3.27 String.prototype[@@iterator]()
__webpack_require__(/*! ./_iter-define */ "./node_modules/core-js/modules/_iter-define.js")(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return { value: undefined, done: true };
  point = $at(O, index);
  this._i += point.length;
  return { value: point, done: false };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.link.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.link.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.10 String.prototype.link(url)
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('link', function (createHTML) {
  return function link(url) {
    return createHTML(this, 'a', 'href', url);
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.raw.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.raw.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");

$export($export.S, 'String', {
  // 21.1.2.4 String.raw(callSite, ...substitutions)
  raw: function raw(callSite) {
    var tpl = toIObject(callSite.raw);
    var len = toLength(tpl.length);
    var aLen = arguments.length;
    var res = [];
    var i = 0;
    while (len > i) {
      res.push(String(tpl[i++]));
      if (i < aLen) res.push(String(arguments[i]));
    } return res.join('');
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.repeat.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.repeat.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");

$export($export.P, 'String', {
  // 21.1.3.13 String.prototype.repeat(count)
  repeat: __webpack_require__(/*! ./_string-repeat */ "./node_modules/core-js/modules/_string-repeat.js")
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.small.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.small.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.11 String.prototype.small()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('small', function (createHTML) {
  return function small() {
    return createHTML(this, 'small', '', '');
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.starts-with.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.starts-with.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.18 String.prototype.startsWith(searchString [, position ])

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var context = __webpack_require__(/*! ./_string-context */ "./node_modules/core-js/modules/_string-context.js");
var STARTS_WITH = 'startsWith';
var $startsWith = ''[STARTS_WITH];

$export($export.P + $export.F * __webpack_require__(/*! ./_fails-is-regexp */ "./node_modules/core-js/modules/_fails-is-regexp.js")(STARTS_WITH), 'String', {
  startsWith: function startsWith(searchString /* , position = 0 */) {
    var that = context(this, searchString, STARTS_WITH);
    var index = toLength(Math.min(arguments.length > 1 ? arguments[1] : undefined, that.length));
    var search = String(searchString);
    return $startsWith
      ? $startsWith.call(that, search, index)
      : that.slice(index, index + search.length) === search;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.strike.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.strike.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.12 String.prototype.strike()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('strike', function (createHTML) {
  return function strike() {
    return createHTML(this, 'strike', '', '');
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.sub.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.sub.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.13 String.prototype.sub()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('sub', function (createHTML) {
  return function sub() {
    return createHTML(this, 'sub', '', '');
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.sup.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.sup.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.14 String.prototype.sup()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('sup', function (createHTML) {
  return function sup() {
    return createHTML(this, 'sup', '', '');
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.trim.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.trim.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 21.1.3.25 String.prototype.trim()
__webpack_require__(/*! ./_string-trim */ "./node_modules/core-js/modules/_string-trim.js")('trim', function ($trim) {
  return function trim() {
    return $trim(this, 3);
  };
});


/***/ }),

/***/ "./node_modules/core-js/modules/es6.symbol.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/es6.symbol.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// ECMAScript 6 symbols shim
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var META = __webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").KEY;
var $fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var shared = __webpack_require__(/*! ./_shared */ "./node_modules/core-js/modules/_shared.js");
var setToStringTag = __webpack_require__(/*! ./_set-to-string-tag */ "./node_modules/core-js/modules/_set-to-string-tag.js");
var uid = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js");
var wks = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js");
var wksExt = __webpack_require__(/*! ./_wks-ext */ "./node_modules/core-js/modules/_wks-ext.js");
var wksDefine = __webpack_require__(/*! ./_wks-define */ "./node_modules/core-js/modules/_wks-define.js");
var enumKeys = __webpack_require__(/*! ./_enum-keys */ "./node_modules/core-js/modules/_enum-keys.js");
var isArray = __webpack_require__(/*! ./_is-array */ "./node_modules/core-js/modules/_is-array.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var createDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
var _create = __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js");
var gOPNExt = __webpack_require__(/*! ./_object-gopn-ext */ "./node_modules/core-js/modules/_object-gopn-ext.js");
var $GOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js");
var $DP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var $keys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
var gOPD = $GOPD.f;
var dP = $DP.f;
var gOPN = gOPNExt.f;
var $Symbol = global.Symbol;
var $JSON = global.JSON;
var _stringify = $JSON && $JSON.stringify;
var PROTOTYPE = 'prototype';
var HIDDEN = wks('_hidden');
var TO_PRIMITIVE = wks('toPrimitive');
var isEnum = {}.propertyIsEnumerable;
var SymbolRegistry = shared('symbol-registry');
var AllSymbols = shared('symbols');
var OPSymbols = shared('op-symbols');
var ObjectProto = Object[PROTOTYPE];
var USE_NATIVE = typeof $Symbol == 'function';
var QObject = global.QObject;
// Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

// fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
var setSymbolDesc = DESCRIPTORS && $fails(function () {
  return _create(dP({}, 'a', {
    get: function () { return dP(this, 'a', { value: 7 }).a; }
  })).a != 7;
}) ? function (it, key, D) {
  var protoDesc = gOPD(ObjectProto, key);
  if (protoDesc) delete ObjectProto[key];
  dP(it, key, D);
  if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
} : dP;

var wrap = function (tag) {
  var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
  sym._k = tag;
  return sym;
};

var isSymbol = USE_NATIVE && typeof $Symbol.iterator == 'symbol' ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  return it instanceof $Symbol;
};

var $defineProperty = function defineProperty(it, key, D) {
  if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
  anObject(it);
  key = toPrimitive(key, true);
  anObject(D);
  if (has(AllSymbols, key)) {
    if (!D.enumerable) {
      if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
      it[HIDDEN][key] = true;
    } else {
      if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
      D = _create(D, { enumerable: createDesc(0, false) });
    } return setSymbolDesc(it, key, D);
  } return dP(it, key, D);
};
var $defineProperties = function defineProperties(it, P) {
  anObject(it);
  var keys = enumKeys(P = toIObject(P));
  var i = 0;
  var l = keys.length;
  var key;
  while (l > i) $defineProperty(it, key = keys[i++], P[key]);
  return it;
};
var $create = function create(it, P) {
  return P === undefined ? _create(it) : $defineProperties(_create(it), P);
};
var $propertyIsEnumerable = function propertyIsEnumerable(key) {
  var E = isEnum.call(this, key = toPrimitive(key, true));
  if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
  return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
};
var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
  it = toIObject(it);
  key = toPrimitive(key, true);
  if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
  var D = gOPD(it, key);
  if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
  return D;
};
var $getOwnPropertyNames = function getOwnPropertyNames(it) {
  var names = gOPN(toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
  } return result;
};
var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
  var IS_OP = it === ObjectProto;
  var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
  } return result;
};

// 19.4.1.1 Symbol([description])
if (!USE_NATIVE) {
  $Symbol = function Symbol() {
    if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
    var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
    var $set = function (value) {
      if (this === ObjectProto) $set.call(OPSymbols, value);
      if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
      setSymbolDesc(this, tag, createDesc(1, value));
    };
    if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
    return wrap(tag);
  };
  redefine($Symbol[PROTOTYPE], 'toString', function toString() {
    return this._k;
  });

  $GOPD.f = $getOwnPropertyDescriptor;
  $DP.f = $defineProperty;
  __webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js").f = gOPNExt.f = $getOwnPropertyNames;
  __webpack_require__(/*! ./_object-pie */ "./node_modules/core-js/modules/_object-pie.js").f = $propertyIsEnumerable;
  __webpack_require__(/*! ./_object-gops */ "./node_modules/core-js/modules/_object-gops.js").f = $getOwnPropertySymbols;

  if (DESCRIPTORS && !__webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js")) {
    redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
  }

  wksExt.f = function (name) {
    return wrap(wks(name));
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });

for (var es6Symbols = (
  // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
  'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'
).split(','), j = 0; es6Symbols.length > j;)wks(es6Symbols[j++]);

for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);

$export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
  // 19.4.2.1 Symbol.for(key)
  'for': function (key) {
    return has(SymbolRegistry, key += '')
      ? SymbolRegistry[key]
      : SymbolRegistry[key] = $Symbol(key);
  },
  // 19.4.2.5 Symbol.keyFor(sym)
  keyFor: function keyFor(sym) {
    if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
    for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
  },
  useSetter: function () { setter = true; },
  useSimple: function () { setter = false; }
});

$export($export.S + $export.F * !USE_NATIVE, 'Object', {
  // 19.1.2.2 Object.create(O [, Properties])
  create: $create,
  // 19.1.2.4 Object.defineProperty(O, P, Attributes)
  defineProperty: $defineProperty,
  // 19.1.2.3 Object.defineProperties(O, Properties)
  defineProperties: $defineProperties,
  // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
  // 19.1.2.7 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $getOwnPropertyNames,
  // 19.1.2.8 Object.getOwnPropertySymbols(O)
  getOwnPropertySymbols: $getOwnPropertySymbols
});

// 24.3.2 JSON.stringify(value [, replacer [, space]])
$JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
  var S = $Symbol();
  // MS Edge converts symbol values to JSON as {}
  // WebKit converts symbol values to JSON as null
  // V8 throws on boxed symbols
  return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
})), 'JSON', {
  stringify: function stringify(it) {
    var args = [it];
    var i = 1;
    var replacer, $replacer;
    while (arguments.length > i) args.push(arguments[i++]);
    $replacer = replacer = args[1];
    if (!isObject(replacer) && it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
    if (!isArray(replacer)) replacer = function (key, value) {
      if (typeof $replacer == 'function') value = $replacer.call(this, key, value);
      if (!isSymbol(value)) return value;
    };
    args[1] = replacer;
    return _stringify.apply($JSON, args);
  }
});

// 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
$Symbol[PROTOTYPE][TO_PRIMITIVE] || __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js")($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
// 19.4.3.5 Symbol.prototype[@@toStringTag]
setToStringTag($Symbol, 'Symbol');
// 20.2.1.9 Math[@@toStringTag]
setToStringTag(Math, 'Math', true);
// 24.3.3 JSON[@@toStringTag]
setToStringTag(global.JSON, 'JSON', true);


/***/ }),

/***/ "./node_modules/core-js/modules/es6.weak-map.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.weak-map.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var each = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(0);
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var meta = __webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js");
var assign = __webpack_require__(/*! ./_object-assign */ "./node_modules/core-js/modules/_object-assign.js");
var weak = __webpack_require__(/*! ./_collection-weak */ "./node_modules/core-js/modules/_collection-weak.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var WEAK_MAP = 'WeakMap';
var getWeak = meta.getWeak;
var isExtensible = Object.isExtensible;
var uncaughtFrozenStore = weak.ufstore;
var tmp = {};
var InternalMap;

var wrapper = function (get) {
  return function WeakMap() {
    return get(this, arguments.length > 0 ? arguments[0] : undefined);
  };
};

var methods = {
  // 23.3.3.3 WeakMap.prototype.get(key)
  get: function get(key) {
    if (isObject(key)) {
      var data = getWeak(key);
      if (data === true) return uncaughtFrozenStore(validate(this, WEAK_MAP)).get(key);
      return data ? data[this._i] : undefined;
    }
  },
  // 23.3.3.5 WeakMap.prototype.set(key, value)
  set: function set(key, value) {
    return weak.def(validate(this, WEAK_MAP), key, value);
  }
};

// 23.3 WeakMap Objects
var $WeakMap = module.exports = __webpack_require__(/*! ./_collection */ "./node_modules/core-js/modules/_collection.js")(WEAK_MAP, wrapper, methods, weak, true, true);

// IE11 WeakMap frozen keys fix
if (fails(function () { return new $WeakMap().set((Object.freeze || Object)(tmp), 7).get(tmp) != 7; })) {
  InternalMap = weak.getConstructor(wrapper, WEAK_MAP);
  assign(InternalMap.prototype, methods);
  meta.NEED = true;
  each(['delete', 'has', 'get', 'set'], function (key) {
    var proto = $WeakMap.prototype;
    var method = proto[key];
    redefine(proto, key, function (a, b) {
      // store frozen objects on internal weakmap shim
      if (isObject(a) && !isExtensible(a)) {
        if (!this._f) this._f = new InternalMap();
        var result = this._f[key](a, b);
        return key == 'set' ? this : result;
      // store all the rest on native weakmap
      } return method.call(this, a, b);
    });
  });
}


/***/ }),

/***/ "./node_modules/core-js/modules/web.dom.iterable.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/web.dom.iterable.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $iterators = __webpack_require__(/*! ./es6.array.iterator */ "./node_modules/core-js/modules/es6.array.iterator.js");
var getKeys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
var wks = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js");
var ITERATOR = wks('iterator');
var TO_STRING_TAG = wks('toStringTag');
var ArrayValues = Iterators.Array;

var DOMIterables = {
  CSSRuleList: true, // TODO: Not spec compliant, should be false.
  CSSStyleDeclaration: false,
  CSSValueList: false,
  ClientRectList: false,
  DOMRectList: false,
  DOMStringList: false,
  DOMTokenList: true,
  DataTransferItemList: false,
  FileList: false,
  HTMLAllCollection: false,
  HTMLCollection: false,
  HTMLFormElement: false,
  HTMLSelectElement: false,
  MediaList: true, // TODO: Not spec compliant, should be false.
  MimeTypeArray: false,
  NamedNodeMap: false,
  NodeList: true,
  PaintRequestList: false,
  Plugin: false,
  PluginArray: false,
  SVGLengthList: false,
  SVGNumberList: false,
  SVGPathSegList: false,
  SVGPointList: false,
  SVGStringList: false,
  SVGTransformList: false,
  SourceBufferList: false,
  StyleSheetList: true, // TODO: Not spec compliant, should be false.
  TextTrackCueList: false,
  TextTrackList: false,
  TouchList: false
};

for (var collections = getKeys(DOMIterables), i = 0; i < collections.length; i++) {
  var NAME = collections[i];
  var explicit = DOMIterables[NAME];
  var Collection = global[NAME];
  var proto = Collection && Collection.prototype;
  var key;
  if (proto) {
    if (!proto[ITERATOR]) hide(proto, ITERATOR, ArrayValues);
    if (!proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
    Iterators[NAME] = ArrayValues;
    if (explicit) for (key in $iterators) if (!proto[key]) redefine(proto, key, $iterators[key], true);
  }
}


/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--The content below is only a placeholder and can be replaced.-->\n<!-- <div *ngIf=\"techniques && tactics\"> -->\n<tabs>\n    <!-- <tab [tabTitle]=\"'grid'\">\n        <DataTable></DataTable>\n    </tab> -->\n</tabs>\n<span style=\"font-size: 7pt\">MITRE ATT&CK&reg; Navigator v{{nav_version}}</span>\n\n<!-- </div> -->\n<!-- <div *ngIf=\"!techniques && !tactics\">\n    loading...\n</div> -->\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/datatable/data-table.component.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/datatable/data-table.component.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"controlsContainer\">\n    <ul class=\"control-sections\">\n        <li *ngIf=\"configService.getFeatureGroup('selection_controls', 'any') && configService.getFeature('selecting_techniques')\">\n            <div *ngIf=\"configService.getFeatureGroupCount('selection_controls') >= 3\" class=\"section-label\">\n                selection controls\n            </div>\n\n\n            <!-- lock selecting all with technique id -->\n            <div *ngIf=\"configService.getFeature('deselect_all')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                     (click)=\"viewModel.changeTechniqueIDSelectionLock(); currentDropdown = null;\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"lock multi-tactic technique selection\">\n                     <img [src]=\"viewModel.selectTechniquesAcrossTactics ? 'assets/icons/ic_lock_black_24px.svg' : 'assets/icons/ic_lock_open_black_24px.svg'\" alt=\"lock\"/>\n                </div>\n            </div>\n\n\n            <!-- Search -->\n            <div *ngIf=\"configService.getFeature('search')\" class=\"control-row-item\">\n\n                <div class=\"control-row-button dropdown noselect\"\n                    (click)=\"currentDropdown = currentDropdown !== 'search' ? 'search' : null;\"\n                    matTooltipPosition=\"below\"\n                    matTooltip=\"search\">\n                    <img src=\"assets/icons/ic_search_black_24px.svg\"/>\n                </div>\n\n                <div class=\"dropdown-container search\" *ngIf=\"currentDropdown === 'search'\" #dropdown [class.left]=\"checkalign(dropdown)\">\n\n                    <mat-form-field style=\"width:100%; margin-top:5px; padding: 10px; padding-bottom:0px;\">\n                        <input matInput\n\n                        [(ngModel)]=\"searchString\"\n                        (input)=\"updateSearchDropdown()\"\n                        placeholder=\"Search for techniques here...\">\n\n                    </mat-form-field>\n                    <div><b>Properties searched:</b></div>\n\n                    <div>\n                        <div class=\"noselect\">\n                            <input id=\"search-name-checkbox\" class=\"checkbox-custom\" type=\"checkbox\" [(ngModel)]=\"searchingName\" (change)=\"updateSearchDropdown()\">\n                            <label for=\"search-name-checkbox\" class=\"checkbox-custom-label\">Name</label>\n                            <input id=\"search-id-checkbox\" class=\"checkbox-custom\" type=\"checkbox\" [(ngModel)]=\"searchingID\" (change)=\"updateSearchDropdown()\">\n                            <label for=\"search-id-checkbox\" class=\"checkbox-custom-label\">ID</label>\n                            <input id=\"search-description-checkbox\" class=\"checkbox-custom\" type=\"checkbox\" [(ngModel)]=\"searchingDescription\" (change)=\"updateSearchDropdown()\">\n                            <label for=\"search-description-checkbox\" class=\"checkbox-custom-label\">Description</label>\n                        </div>\n                    </div>\n\n                    <div>\n                        <button  (click)=\"selectAllInSearch(); populateEditFields();\" style=\"width:48.5%\" class=\"button\">select all</button>\n                        <button (click)=\"deselectAllInSearch(); populateEditFields();\" style=\"width:48.5%; margin-left:2px;\" class=\"button\">deselect all</button>\n                    </div>\n\n                    <div class=\"search-list\">\n                        <table>\n                            <tr  *ngFor=\"let result of searchResults\" class=\"search-list-item\">\n                                <td>\n                                    <div class=\"search-list-item-label\">\n                                        {{result.name}}\n                                    </div>\n                                </td>\n                                <td><a style=\"margin-right:2px\" [href]=\"result.external_references_url\" target=\"_blank\">view</a></td>\n                                <td><button  (click)=\"viewModel.addToTechniqueSelection_technique_id(result.technique_id); populateEditFields();\" class=\"button\">select</button></td>\n                                <td><button (click)=\"viewModel.removeFromTechniqueSelection_technique_id(result.technique_id); populateEditFields();\" class=\"button\">deselect</button></td>\n                            </tr>\n                        </table>\n                    </div>\n                </div>\n            </div>\n\n\n            <!-- Multi-select -->\n            <div *ngIf=\"configService.getFeature('multiselect')\" class=\"control-row-item\">\n                <div class=\"control-row-button dropdown noselect\"\n                    (click)=\"currentDropdown = currentDropdown !== 'multiselect' ? 'multiselect' : null;\"\n                    matTooltipPosition=\"below\"\n                    [matTooltip]=\"'multi-select'\">\n                    <img src=\"assets/icons/ic_playlist_add_black_24px.svg\"/>\n                </div>\n                <div class=\"dropdown-container multiselect\" *ngIf=\"currentDropdown === 'multiselect'\" #dropdown [class.left]=\"checkalign(dropdown)\">\n                    <div class=\"multiselect-grouping\" *ngFor=\"let multiSelectGroup of [{data: threatGroupList, label: 'Threat Groups'}, {data: softwareGroupList, label: 'Software'}]\">\n                        <div class=\"multiselect-grouping-label\">{{multiSelectGroup.label}}</div>\n                        <div class=\"multiselect-list\">\n                            <table>\n                                <tr  *ngFor=\"let securityInstance of multiSelectGroup.data\" class=\"multiselect-list-item\" [class.selected]=\"isSecurityInstanceSelected(securityInstance)\">\n                                    <td>\n                                        <div class=\"multiselect-list-item-label\">\n                                            {{securityInstance.name}}\n                                        </div>\n                                    </td>\n                                    <td><a *ngIf=\"securityInstance.url\" style=\"margin-right:2px\" [href]=\"securityInstance.url\" target=\"_blank\">view</a><span *ngIf=\"!securityInstance.url\">----</span></td>\n                                    <td><button (click)=\"selectSecurityInstance(securityInstance); populateEditFields();\" class=\"multiselect-list-item-button button\">select</button></td>\n                                    <td><button (click)=\"deselectSecurityInstance(securityInstance); populateEditFields();\" class=\"multiselect-list-item-button button\">deselect</button></td>\n                                </tr>\n                            </table>\n                        </div>\n                    </div>\n                </div>\n            </div>\n\n\n            <!-- deselect all -->\n            <div *ngIf=\"configService.getFeature('deselect_all')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                     (click)=\"viewModel.clearTechniqueSelection(); currentDropdown = null;\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"deselect {{this.viewModel.selectedTechniques.length}} techniques\">\n                    <img src=\"assets/icons/ic_clear_black_24px.svg\" alt=\"deselect all\"/>\n                    <span class=\"deselectNumber\">{{this.viewModel.selectedTechniques.length}}</span>\n                </div>\n            </div>\n\n\n        </li>\n        <li *ngIf=\"configService.getFeatureGroup('layer_controls', 'any')\">\n            <div *ngIf=\"configService.getFeatureGroupCount('layer_controls') >= 2\" class=\"section-label\">\n                layer controls\n            </div>\n\n            <!-- layer name, description and metadata -->\n            <div *ngIf=\"configService.getFeature('layer_info')\" class=\"control-row-item\">\n\n                <div class=\"control-row-button dropdown noselect\"\n                     (click)=\"currentDropdown = currentDropdown !== 'description' ? 'description' : null\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"layer information\">\n                     <img src=\"assets/icons/ic_description_black_24px.svg\" alt=\"layer information\" />\n                 </div>\n\n                 <!-- description input (invisible, absolute) -->\n                 <div class=\"dropdown-container inputfield layer_info\"  #dropdown [class.left]=\"checkalign(dropdown)\"\n                      *ngIf=\"currentDropdown === 'description'\">\n\n                    <!-- layer name field -->\n                    <div class=\"name_desc\">\n                        <mat-form-field>\n                                <input matInput\n                                        type=\"text\"\n                                        placeholder=\"name\"\n                                        [(ngModel)]=\"viewModel.name\" />\n                            </mat-form-field>\n        \n                            <!-- layer description field -->\n                            <mat-form-field>\n                                <textarea matInput\n                                            matTextareaAutosize\n                                            placeholder=\"description\"\n                                            [(ngModel)]=\"viewModel.description\">\n                                </textarea>\n                            </mat-form-field>\n                    </div>\n                    <div class=\"metadata_input\">\n                        <b class=\"metadata-label\">Metadata</b>\n                        <table>\n                            <tr class=\"formfield-group\" *ngFor=\"let metadata of viewModel.metadata; let $i = index\">\n                                <td></td>\n                                <td>\n                                    <mat-form-field>\n                                            <input matInput\n                                                    type=\"text\"\n                                                    placeholder=\"name\"\n                                                    [(ngModel)]=\"metadata.name\" />\n                                        </mat-form-field>\n                                        <mat-form-field>\n                                            <input matInput\n                                                type=\"text\"\n                                                placeholder=\"value\"\n                                                [(ngModel)]=\"metadata.value\" />\n                                        </mat-form-field>\n                                        <button class=\"button\" (click)=\"viewModel.removeMetadata($i)\">remove this metadata</button>\n                                </td>                                \n                            </tr>\n                            <tr>\n                                <td colspan=2 class=\"addmore\">\n                                        <button class=\"button\" (click)=\"viewModel.addMetadata()\">add more metadata</button>\n                                </td>\n                            </tr>\n                        </table>\n\n                    </div>\n                 </div>\n             </div>\n\n            <!-- save locally as JSON -->\n            <div *ngIf=\"configService.getFeature('download_layer')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                    (click)=\"saveLayerLocally()\"\n                    matTooltipPosition=\"below\"\n                    matTooltip=\"download layer as json\">\n                    <img src=\"assets/icons/ic_file_download_black_24px.svg\" alt=\"save layer\"/>\n                </div>\n            </div>\n\n            <!-- save globally as JSON -->\n            <div *ngIf=\"configService.getFeature('save_layer')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                    (click)=\"saveLayerGlobally()\"\n                    matTooltipPosition=\"below\"\n                    matTooltip=\"save layer on server\">\n                    <img src=\"assets/icons/ic_save_black_24px.svg\" alt=\"save layer\"/>\n                </div>\n            </div> <!-- assets/icons/ic_clear_black_24px.svg -->\n                  \n            <!-- delete file from store -->\n            <div *ngIf=\"configService.getFeature('delete_layer')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                    (click)=\"deleteLayerGlobally()\"\n                    matTooltipPosition=\"below\"\n                    matTooltip=\"delete layer from server\">\n                    <img src=\"assets/icons/ic_clear_black_24px.svg\" alt=\"save layer\"/>\n                </div>\n            </div>\n\n            <!-- export to excel -->\n            <div *ngIf=\"configService.getFeature('export_excel')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                    (click)=\"saveLayerLocallyExcel()\"\n                    matTooltipPosition=\"below\"\n                    matTooltip=\"export to excel\">\n                    <img src=\"assets/icons/baseline-grid_on-24px.svg\" alt=\"save layer\"/>\n                </div>\n            </div>\n\n         \n            <!-- render layer to SVG -->\n            <div *ngIf=\"configService.getFeature('export_render')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                    (click)=\"filteredTechniques.length > 0 ? exportRender() : pass\"\n                    matTooltipPosition=\"below\"\n                    matTooltip=\"render layer to SVG\">\n                    <img src=\"assets/icons/ic_camera_alt_black_24px.svg\" alt=\"export render\"/>\n                </div>\n            </div>\n\n            <!-- Filters -->\n            <div *ngIf=\"configService.getFeature('filters')\" class=\"control-row-item\">\n\n                <div class=\"control-row-button dropdown noselect\"\n                    (click)=\"currentDropdown = currentDropdown !== 'filters' ? 'filters' : null;\"\n                    matTooltipPosition=\"below\"\n                    matTooltip=\"filters\">\n                    <img src=\"assets/icons/ic_filter_list_black_24px.svg\"/>\n                </div>\n                <div class=\"dropdown-container filters\" *ngIf=\"currentDropdown === 'filters'\" #dropdown [class.left]=\"checkalign(dropdown)\">\n                    <div class=\"filter\" *ngFor=\"let filter of ['platforms', 'stages']\">\n                        <b class=\"filter-label\">{{filter}}</b>\n                        <div class=\"filter-option\" *ngFor=\"let filterOption of viewModel.filters[filter].options\" >\n                            <!-- <label class=\"noselect\"><input type=\"checkbox\" (click)=\"viewModel.filters.toggleInFilter(filter, filterOption); filterTechniques()\" [checked]=\"viewModel.filters.inFilter(filter, filterOption)\">{{filterOption}}</label> -->\n                            <input [id]=\"filterOption\" class=\"checkbox-custom\" type=\"checkbox\" (click)=\"viewModel.filters.toggleInFilter(filter, filterOption); filterTechniques()\" [checked]=\"viewModel.filters.inFilter(filter, filterOption)\">\n                            <label for=\"{{filterOption}}\" class=\"checkbox-custom-label noselect\">{{filterOption}}</label>\n                        </div>\n                        <!-- <div class=\"filter-option\" *ngFor=\"let filterOption of viewModel.filters[filter].options\" (click)=\"viewModel.filters.toggleInFilter(filter, filterOption); filterTechniques()\">\n                            {{filterOption}}  {{viewModel.filters.inFilter(filter, filterOption)}}\n                        </div> -->\n                    </div>\n                    <!-- <mat-select placeholder=\"platforms\" [(ngModel)]=\"platformControl\"\n                        multiple disableRipple autofocus (change)=\"filterTechniques(); viewModel.filters.platforms.selection = platformsControl\">\n                        <mat-option *ngFor=\"let platformOption of viewModel.filters.platforms.options\" [value]=\"platformOption\">{{platformOption}}</mat-option>\n                    </mat-select> -->\n                    <!-- <filter-menu [dataTable]=\"this\"></filter-menu> -->\n                </div>\n            </div>\n\n            <!-- sorting -->\n            <div *ngIf=\"configService.getFeature('sorting')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                    (click)=\"viewModel.sorting = (viewModel.sorting + 1) % 4; filterTechniques()\"\n                    matTooltipPosition=\"below\"\n                    [matTooltip]=\"['sorting alphabetically ascending', 'sorting alphabetically descending', 'sorting by score ascending', 'sorting by score descending'][viewModel.sorting]\">\n                    <img [src]=\"['assets/icons/ic_sort_alphabetically_ascending_black_24px.svg', 'assets/icons/ic_sort_alphabetically_descending_black_24px.svg', 'assets/icons/ic_sort_numerically_ascending_black_24px.svg', 'assets/icons/ic_sort_numerically_descending_black_24px.svg'][viewModel.sorting]\" alt=\"sorting\"/>\n                </div>\n            </div>\n\n            <!-- color setup -->\n            <div *ngIf=\"configService.getFeature('color_setup')\" class=\"control-row-item\">\n                <div class=\"control-row-button dropdown noselect\"\n                    (click)=\"currentDropdown = currentDropdown !== 'colorSetup' ? 'colorSetup' : null; viewModel.updateGradient()\"\n                    matTooltipPosition=\"below\"\n                    matTooltip=\"color setup\">\n                    <img src=\"assets/icons/ic_palette_black_24px.svg\"/>\n                </div>\n                <div class=\"dropdown-container colorSetup\" *ngIf=\"currentDropdown === 'colorSetup'\" #dropdown [class.left]=\"checkalign(dropdown)\">\n\n                    <div class=\"tacticRowColor\">\n                        <div class=\"gradient-section-label\">\n                            Tactic Row Background\n                        </div>\n                        <div class=\"gradient-section-content\">\n                            <input id=\"showTacticRowBackground\" type=\"checkbox\" class=\"checkbox-custom\" [(ngModel)]=viewModel.showTacticRowBackground>\n                            <label for=\"showTacticRowBackground\" class=\"checkbox-custom-label noselect\">show</label>\n                            <input class=\"colorpicker\" [(colorPicker)]=\"viewModel.tacticRowBackground\" [(ngModel)]=\"viewModel.tacticRowBackground\" [style.background]=\"viewModel.tacticRowBackground\" cpPosition=\"bottom\" [cpPresetColors]=\"['#ddd', '#aaaaaa', '#205B8F', '#B9482D']\">\n                        </div>\n                    </div>\n                    <div class=\"gradient\">\n                        <div class=\"gradient-section-label\">\n                            Scoring Gradient\n                        </div>\n                        <div class=\"gradient-controls gradient-section-content\">\n                            <table>\n                                <tr class=\"minmax top\">\n                                    <td>Low value:</td>\n                                    <td class=\"col2\"><input type=\"number\" (input)=\"viewModel.updateGradient()\" [(ngModel)]=\"viewModel.gradient.minValue\" [max]=viewModel.gradient.maxValue></td>\n                                </tr>\n                                <tr>\n                                    <td class=\"buttons\">\n                                        <div *ngFor=\"let gradientStep of viewModel.gradient.colors; let $i = index\">\n                                            <div class=\"left\">\n                                                <button (click)=\"viewModel.removeGradientColor($i)\" [disabled]=\"viewModel.gradient.colors.length == 2\">remove</button>\n                                            </div>\n                                            <div class=\"right\">\n                                                <input class=\"colorpicker\" (colorPickerChange)=\"viewModel.updateGradient()\" (cpPresetColorsChange)=\"viewModel.updateGradient()\" (cpSliderChange)=\"viewModel.updateGradient()\" (cpInputChange)=\"viewModel.updateGradient()\" [(colorPicker)]=\"gradientStep.color\" [(ngModel)]=\"gradientStep.color\" [style.background]=\"gradientStep.color\" cpPosition=\"bottom\" [cpPresetColors]=\"viewModel.gradient.options\">\n                                                <!-- <select [(ngModel)]=\"gradientStep.color\" (ngModelChange)=\"viewModel.updateGradient()\">\n                                                    <option *ngFor=\"let color of viewModel.gradient.options\" [ngValue]=\"color\">{{color}}</option>\n                                                    option shows up if a nonstandard option is selected, from uploading a custom layer\n                                                    <option *ngIf=\"!(viewModel.gradient.labelToColor.hasOwnProperty(gradientStep.color))\" [ngValue]=gradientStep.color>{{gradientStep.color}}</option>\n                                                </select> -->\n                                            </div>\n                                        </div>\n                                    </td>\n                                    <td class=\"col2\" [style.background-image]=\"sanitize(viewModel.gradient.gradient.css('linear', 'to bottom'))\"> </td>\n                                </tr>\n                                <tr>\n                                    <td><button class=\"addcolor\" (click)=\"viewModel.addGradientColor();\">add another color</button></td>\n                                </tr>\n                                <tr class=\"minmax bottom\">\n                                    <td>High value: </td>\n                                    <td class=\"col2 \"><input type=\"number\" (input)=\"viewModel.updateGradient()\" [(ngModel)]=\"viewModel.gradient.maxValue\" [min]=viewModel.gradient.minValue></td>\n                                </tr>\n                            </table>\n                            <div class=\"display-buttons\">\n                                <div class=\"squarebutton dropdown noselect\" (click)=\"presetsMenuVisible = !presetsMenuVisible\">\n                                    presets<span style=\"font-size:5pt\">▼</span>\n                                </div >\n                                <div class=\"dropdown-container presetsmenu\" *ngIf=\"presetsMenuVisible\">\n                                    <div class=\"squarebutton noselect gradient\" (click)=\"viewModel.gradient.setGradientPreset('redgreen'); presetsMenuVisible = false; viewModel.updateGradient()\" [style.background-image]=\"sanitize(viewModel.gradient.presetToTinyColor('redgreen'))\">red to green</div>\n                                    <div class=\"squarebutton noselect gradient\" (click)=\"viewModel.gradient.setGradientPreset('greenred'); presetsMenuVisible = false; viewModel.updateGradient()\" [style.background-image]=\"sanitize(viewModel.gradient.presetToTinyColor('greenred'))\">green to red</div>\n                                    <div class=\"squarebutton noselect gradient\" (click)=\"viewModel.gradient.setGradientPreset('bluered'); presetsMenuVisible = false; viewModel.updateGradient()\" [style.background-image]=\"sanitize(viewModel.gradient.presetToTinyColor('bluered'))\">blue to red</div>\n                                    <div class=\"squarebutton noselect gradient\" (click)=\"viewModel.gradient.setGradientPreset('redblue'); presetsMenuVisible = false; viewModel.updateGradient()\" [style.background-image]=\"sanitize(viewModel.gradient.presetToTinyColor('redblue'))\">red to blue</div>\n                                    <div class=\"squarebutton noselect gradient\" (click)=\"viewModel.gradient.setGradientPreset('whiteblue'); presetsMenuVisible = false; viewModel.updateGradient()\" [style.background-image]=\"sanitize(viewModel.gradient.presetToTinyColor('whiteblue'))\">white to blue</div>\n                                    <div class=\"squarebutton noselect gradient\" (click)=\"viewModel.gradient.setGradientPreset('whitered'); presetsMenuVisible = false; viewModel.updateGradient()\" [style.background-image]=\"sanitize(viewModel.gradient.presetToTinyColor('whitered'))\">white to red</div>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n\n            <!-- show or hide disabled techniques -->\n            <div *ngIf=\"configService.getFeature('toggle_hide_disabled')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                     (click)=\"viewModel.hideDisabled = !viewModel.hideDisabled; filterTechniques()\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"show/hide disabled\">\n                     <img [src]=\"viewModel.hideDisabled ? 'assets/icons/ic_visibility_off_black_24px.svg' : 'assets/icons/ic_visibility_black_24px.svg'\" [alt]=\"viewModel.hideDisabled ? 'show disabled' : 'hide disabled'\"/>\n                 </div>\n             </div>\n\n             <!-- view mode -->\n            <div *ngIf=\"configService.getFeature('toggle_view_mode')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                     (click)=\"viewModel.viewMode = (viewModel.viewMode + 1) % 3\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"toggle view mode\">\n                      <img [src]=\"['assets/icons/ic_view_large_black_24px.svg', 'assets/icons/ic_view_medium_black_24px.svg', 'assets/icons/ic_view_small_black_24px.svg'][viewModel.viewMode]\" [alt]=\"['full view', 'compact view', 'mini view'][viewModel.viewMode]\"/>\n                 </div>\n             </div>\n\n        </li>\n        <li *ngIf=\"configService.getFeatureGroup('technique_controls', 'any') && configService.getFeature('selecting_techniques')\">\n            <div *ngIf=\"configService.getFeatureGroupCount('technique_controls') >= 3\" class=\"section-label\">\n                technique controls\n            </div>\n            <!-- TECHNIQUE CONTROLS -->\n            <!-- enable/disable technique -->\n            <div *ngIf=\"configService.getFeature('disable_techniques')\" class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                     (click)=\"setSelectedState()\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"toggle state\"\n                     [matTooltipDisabled]=\"!viewModel.isCurrentlyEditing()\">\n                     <img [src]=\"viewModel.isCurrentlyEditing() ? 'assets/icons/ic_texture_black_24px.svg' : 'assets/icons/ic_texture_gray_24px.svg'\" alt=\"toggle state\"/>\n                 </div>\n             </div>\n\n            <!-- background color -->\n            <div *ngIf=\"configService.getFeature('manual_color')\" class=\"control-row-item\">\n\n                <div class=\"control-row-button dropdown noselect\"\n                     (click)=\"viewModel.isCurrentlyEditing() ? currentDropdown = currentDropdown !== 'colorpicker' ? 'colorpicker' : null : continue\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"background color\"\n                     [matTooltipDisabled]=\"!viewModel.isCurrentlyEditing()\"\n                     [style.color]=\"viewModel.isCurrentlyEditing() ? '#000000' : '#aaaaaa'\">\n\n                    <svg border=\"#dddddd\" [attr.fill]=\"viewModel.isCurrentlyEditing() ? '#000000' : '#aaaaaa'\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" xmlns=\"http://www.w3.org/2000/svg\">\n                        <path d=\"M0 0h24v24H0z\" fill=\"none\"/>\n                        <path d=\"M16.56 8.94L7.62 0 6.21 1.41l2.38 2.38-5.15 5.15c-.59.59-.59 1.54 0 2.12l5.5 5.5c.29.29.68.44 1.06.44s.77-.15 1.06-.44l5.5-5.5c.59-.58.59-1.53 0-2.12zM5.21 10L10 5.21 14.79 10H5.21zM19 11.5s-2 2.17-2 3.5c0 1.1.9 2 2 2s2-.9 2-2c0-1.33-2-3.5-2-3.5z\"/>\n                        <path [attr.class]=\"viewModel.isCurrentlyEditing() ? viewModel.getEditingCommonValue('color') : none\" d=\"M0 20h24v4H0z\"/>\n                    </svg>\n                </div>\n                <!-- color picker (invisible, absolute)-->\n                <div class=\"colorpicker dropdown-container\" #dropdown [class.left]=\"checkalign(dropdown)\"\n                     *ngIf=\"currentDropdown === 'colorpicker'\">\n\n                    <div class=\"color-block wide noselect dropdown\"\n                         (click)=\"viewModel.editSelectedTechniques('color', '')\">\n                        no color\n                    </div>\n                    <div class=\"color-block square\"\n                         *ngFor=\"let color of viewModel.backgroundPresets\"\n                         [style.background]=\"color\"\n                         (click)=\"viewModel.editSelectedTechniques('color', color)\"></div>\n                </div>\n            </div>\n\n\n            <!-- score -->\n            <div *ngIf=\"configService.getFeature('scoring')\" class=\"control-row-item\" >\n                <div class=\"control-row-button dropdown noselect\"\n                     (click)=\"viewModel.isCurrentlyEditing() ? currentDropdown = currentDropdown !== 'score' ? 'score' : null : continue\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"scoring\"\n                     [matTooltipDisabled]=\"!viewModel.isCurrentlyEditing()\"\n                     [style.color]=\"viewModel.isCurrentlyEditing() ? '#000000' : '#aaaaaa'\">\n                     <img [src]=\"viewModel.isCurrentlyEditing() ? 'assets/icons/ic_insert_chart_black_24px.svg' : 'assets/icons/ic_insert_chart_gray_24px.svg'\" alt=\"score\"/>\n                </div>\n                <div class=\"dropdown-container inputfield\" #dropdown [class.left]=\"checkalign(dropdown)\"\n                     *ngIf=\"currentDropdown === 'score'\">\n                     <mat-form-field>\n                         <!-- update data whenever it is typed in -->\n                         <input matInput\n                                type=\"text\"\n                                onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57) || event.charCode == 46 || event.charCode == 45\"\n                                [(ngModel)]=\"scoreEditField\"\n                                placeholder=\"score\"\n                                (input)=\"viewModel.editSelectedTechniques('score', $event.target.value); viewModel.editSelectedTechniques('scoreColor', viewModel.gradient.getColor($event.target.value)); filterTechniques()\">\n                         <mat-hint style=\"color: red\" align=\"start\" *ngIf=\"validateScoreInput()\">not a number</mat-hint>\n                     </mat-form-field>\n                </div>\n            </div>\n\n\n            <!-- comment -->\n            <div *ngIf=\"configService.getFeature('comments')\"  class=\"control-row-item\">\n\n                <div class=\"control-row-button dropdown noselect\"\n                     (click)=\"viewModel.isCurrentlyEditing() ? currentDropdown = currentDropdown !== 'comment' ? 'comment' : null : continue\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"comment\"\n                     [matTooltipDisabled]=\"!viewModel.isCurrentlyEditing()\"\n                     [style.color]=\"viewModel.isCurrentlyEditing() ? '#000000' : '#aaaaaa'\">\n                     <img [src]=\"viewModel.isCurrentlyEditing() ? 'assets/icons/ic_insert_comment_black_24px.svg' : 'assets/icons/ic_insert_comment_gray_24px.svg'\" alt=\"comment\" />\n                 </div>\n                 <!-- comment input (invisible, absolute) -->\n                 <div class=\"dropdown-container inputfield left\" #dropdown [class.left]=\"checkalign(dropdown)\"\n                      *ngIf=\"currentDropdown === 'comment'\">\n\n                    <mat-form-field>\n                        <textarea matInput\n                                  matTextareaAutosize\n                                  placeholder=\"comment\"\n                                  [(ngModel)]=\"commentEditField\"\n                                  (input)=\"viewModel.editSelectedTechniques('comment', $event.target.value)\">\n                        </textarea>\n                    </mat-form-field>\n                 </div>\n             </div>\n             <!-- remove all annotations -->\n             <div *ngIf=\"configService.getFeature('clear_annotations')\" class=\"control-row-item\">\n                 <div class=\"control-row-button noselect\"\n                      (click)=\"viewModel.resetSelectedTechniques(); populateEditFields()\"\n                      matTooltipPosition=\"below\"\n                      matTooltip=\"clear annotations on selected\"\n                      [matTooltipDisabled]=\"!viewModel.isCurrentlyEditing()\">\n                      <img [src]=\"viewModel.isCurrentlyEditing() ? 'assets/icons/ic_layers_clear_black_24px.svg' : 'assets/icons/ic_layers_clear_gray_24px.svg'\" alt=\"remove all annotations\"/>\n                  </div>\n              </div>\n        </li>\n    </ul>\n</div>\n\n\n<div class=\"tableContainer\" oncontextmenu=\"return false\">\n    <div [class]=\"'dataTable noselect ' + ['full', 'compact', 'mini'][viewModel.viewMode]\">\n        <table>\n            <tr [style.background]=\"viewModel.showTacticRowBackground && viewModel.viewMode != 2  ? sanitize(viewModel.tacticRowBackground) : 'none'\"\n                [style.border-color]=\"viewModel.showTacticRowBackground && viewModel.viewMode != 2  ? sanitize(viewModel.tacticRowBackground) : 'none'\"\n                [style.color]=\"getTacticRowTextColor()\">\n                <td *ngFor=\"let tactic of dataService.tacticNames(filteredTechniques)\"\n                    [class]=\"'header column ' + ['full', 'compact', 'mini'][viewModel.viewMode]\"\n                    [class.anti-highlight]=\"viewModel.highlightedTactic && tactic != viewModel.highlightedTactic\"\n>\n                    <div\n                        [matTooltipDisabled]=\"viewModel.viewMode == 0\"\n                         matTooltip=\"{{tacticDisplayNames[tactic]}}\"\n                         matTooltipPosition=\"right\"\n                         (click)=\"clickTactic(tactic)\"\n                         [class]=\"'cell link header ' + ['full', 'compact', 'mini'][viewModel.viewMode]\"\n                         [style.border-width]=\"viewModel.showTacticRowBackground || viewModel.viewMode == 0 ? '0px' : '1px'\">\n                         {{[tacticDisplayNames[tactic], viewModel.acronym(tacticDisplayNames[tactic]), ''][viewModel.viewMode]}}\n                    </div>\n                </td>\n            </tr>\n            <tr *ngIf=\"viewModel.viewMode != 2\"\n                [style.background]=\"viewModel.showTacticRowBackground && viewModel.viewMode != 2  ? sanitize(viewModel.tacticRowBackground) : 'none'\"\n                [style.border-color]=\"viewModel.showTacticRowBackground && viewModel.viewMode != 2  ? sanitize(viewModel.tacticRowBackground) : 'none'\"\n                [style.color]=\"getTacticRowTextColor()\">\n                <td *ngFor=\"let tactic of dataService.tacticNames(filteredTechniques)\"\n                    [class]=\"'column' + ['full', 'compact', 'mini'][viewModel.viewMode]\"\n                    [class.anti-highlight]=\"viewModel.highlightedTactic && tactic != viewModel.highlightedTactic\">\n\n                    <div class=\"cell itemcount\">\n                        {{tactics[tactic].length}}<span *ngIf=\"viewModel.viewMode == 0\"> items</span>\n                    </div>\n                </td>\n            </tr>\n            <tr>\n                <td *ngFor=\"let tactic of dataService.tacticNames(filteredTechniques)\"\n                    [class]=\"'techniques column ' + ['full', 'compact', 'mini'][viewModel.viewMode]\"\n                    [class.anti-highlight]=\"viewModel.highlightedTactic && tactic != viewModel.highlightedTactic\">\n                    <technique-cell *ngFor=\"let technique of tactics[tactic]\" \n                                    [class.editing]=\"viewModel.isTechniqueSelected(technique)\"\n                                    [technique]=\"technique\" \n                                    [viewModel]=\"viewModel\"\n                                    (leftclick)=\"onTechniqueSelect($event.technique, $event.shift || $event.ctrl || $event.meta, $event.x, $event.y)\"\n                                    (rightclick)=\"onTechniqueContextMenu($event.technique, $event.x, $event.y)\"\n                                    (highlight)=\"viewModel.highlightedTechnique=$event; this.viewModel.hoverTactic = tactic;\">\n                    </technique-cell>\n                </td>\n            </tr>\n        </table>\n    </div>\n</div>\n\n\n<!--\n   ___ ___  _  _ _____ _____  _______   __  __ ___ _  _ _   _ ___     _   _  _ ___    _____ ___   ___  _  _____ ___ ___  ___\n  / __/ _ \\| \\| |_   _| __\\ \\/ /_   _| |  \\/  | __| \\| | | | / __|   /_\\ | \\| |   \\  |_   _/ _ \\ / _ \\| ||_   _|_ _| _ \\/ __|\n | (_| (_) | .` | | | | _| >  <  | |   | |\\/| | _|| .` | |_| \\__ \\  / _ \\| .` | |) |   | || (_) | (_) | |__| |  | ||  _/\\__ \\\n  \\___\\___/|_|\\_| |_| |___/_/\\_\\ |_|   |_|  |_|___|_|\\_|\\___/|___/ /_/ \\_\\_|\\_|___/    |_| \\___/ \\___/|____|_| |___|_|  |___/\n -->\n\n\n<!-- Context Menu: page cover -->\n<div *ngIf=\"contextMenuVisible\"\n    (click)=\"contextMenuVisible = false; \"\n    (contextmenu)=\"contextMenuVisible = false;\"\n    class=\"contextMenu-cover\">\n</div>\n<!-- Context Menu: Menu -->\n<div [hidden]=\"!contextMenuVisible\"\n     class=\"contextMenu-box dropdown-container noselect\"\n     (contextmenu)=\"contextMenuVisible = false;\"\n     [id]=\"'contextMenu'+viewModel.uid\">\n    <div *ngIf=\"configService.getFeature('selecting_techniques')\" class=\"contextMenu-section\">\n        <div class=\"contextMenu-button\" (click)=\"viewModel.replaceTechniqueSelection(contextMenuSelectedTechnique); contextMenuVisible = false; populateEditFields();\">\n            select\n        </div>\n        <div class=\"contextMenu-button\" (click)=\"viewModel.addToTechniqueSelection(contextMenuSelectedTechnique); contextMenuVisible = false; populateEditFields();\">\n            add to selection\n        </div>\n        <div class=\"contextMenu-button\" (click)=\"viewModel.removeFromTechniqueSelection(contextMenuSelectedTechnique); contextMenuVisible = false; populateEditFields();\">\n            remove from selection\n        </div>\n    </div>\n    <div *ngIf=\"configService.getFeature('selecting_techniques')\" class=\"contextMenu-section\">\n        <div class=\"contextMenu-button\" (click)=\"viewModel.selectAllTechniques(); contextMenuVisible = false; populateEditFields();\">\n            select all\n        </div>\n        <div class=\"contextMenu-button\" (click)=\"viewModel.clearTechniqueSelection(); contextMenuVisible = false; populateEditFields();\">\n            deselect all\n        </div>\n        <div class=\"contextMenu-button\" (click)=\"viewModel.invertSelection(); contextMenuVisible = false; populateEditFields();\">\n            invert selection\n        </div>\n    </div>\n    <div class=\"contextMenu-section\">\n        <div class=\"contextMenu-button\" (click)=\"openURL($event, contextMenuSelectedTechnique); contextMenuVisible = false; \">\n            view technique\n        </div>\n    </div>\n    <div *ngIf=\"customContextMenuItems.length > 0\" class=\"contextMenu-section\">\n        <div *ngFor=\"let option of customContextMenuItems\" class=\"contextMenu-button\" (click)=\"openCustomURL($event, contextMenuSelectedTechnique, option.url); contextMenuVisible = false; \">\n            {{option.label}}\n        </div>\n    </div>\n</div>\n\n<!-- Tooltip -->\n<div class=\"tooltip noselect\" [id]=\"'tooltip'+viewModel.uid\">\n    <div *ngIf=\"viewModel.highlightedTechnique\">\n        <div>\n            <span *ngIf=\"viewModel.viewMode != 0\">{{viewModel.highlightedTechnique.name}} (</span>{{viewModel.highlightedTechnique.technique_id}}<span *ngIf=\"viewModel.viewMode != 0\">)</span>\n        </div>\n        <!-- <table>\n            <tr *ngIf=\"viewModel.getTechniqueVM(viewModel.highlightedTechnique.technique_id).score\">\n                <td>Score:</td>\n                <td>{{viewModel.getTechniqueVM(viewModel.highlightedTechnique.technique_id).score}}</td>\n            </tr>\n            <tr *ngIf=\"viewModel.getTechniqueVM(viewModel.highlightedTechnique.technique_id).comment\">\n                <td>Comment:</td>\n                <td>{{viewModel.getTechniqueVM(viewModel.highlightedTechnique.technique_id).comment}}</td>\n            </tr>\n        </table> -->\n        <div *ngIf=\"viewModel.getTechniqueVM(viewModel.highlightedTechnique.technique_tactic_union_id).score\">\n            <b>Score:</b> {{viewModel.getTechniqueVM(viewModel.highlightedTechnique.technique_tactic_union_id).score}}\n        </div>\n        <div class=\"comment\" [id]=\"'comment'+viewModel.uid\" *ngIf=\"viewModel.getTechniqueVM(viewModel.highlightedTechnique.technique_tactic_union_id).comment\">\n            <b>Comment:</b> {{viewModel.getTechniqueVM(viewModel.highlightedTechnique.technique_tactic_union_id).comment}}\n        </div>\n        <div class=\"comment-overflow-note\" *ngIf=\"toolTipOverflows\">\n            ...\n        </div>\n        <div *ngIf=\"viewModel.getTechniqueVM(viewModel.highlightedTechnique.technique_tactic_union_id).metadata.length > 0\">\n            <b>Metadata:</b>\n            <ul class=\"metadatalist\">\n                <li *ngFor=\"let metadata of viewModel.getTechniqueVM(viewModel.highlightedTechnique.technique_tactic_union_id).metadata\">\n                    {{metadata.name}}: {{metadata.value}}\n                </li>\n            </ul>\n        </div>\n\n    </div>\n\n</div>\n\n<div class=\"legendBar\" (click)=\"toggleLegend()\" *ngIf=\"!showingLegend && configService.getFeature('legend')\">\n    <img src=\"assets/icons/ic_keyboard_arrow_up_black_24px.svg\" style=\"position: absolute; left:4px; top: 3px;\">\n    <div class=\"noselect\" style=\"padding:4px; font-size:14px; position: absolue; width: 100%; text-align:center\">\n        legend\n    </div>\n</div>\n\n<div class=\"legend\" *ngIf=\"showingLegend && configService.getFeature('legend')\">\n    <div class=\"legendBar\" (click)=\"toggleLegend()\" style=\"position: absolute; top:0px; left:0px;\">\n        <img src=\"assets/icons/ic_keyboard_arrow_down_black_24px.svg\" style=\"position: absolute; left:4px; top: 3px;\">\n        <div class=\"noselect\" style=\"padding:4px; font-size:14px; position: absolue; width: 100%; text-align:center\">\n            legend\n        </div>\n    </div>\n    <div class=\"itemArea\">\n        <div class=\"item\" *ngFor=\"let item of viewModel.legendItems; let Even=even; let i=index\" [class.even]=\"!Even\">\n            <input [(colorPicker)]=\"item.color\" [(ngModel)]=\"item.color\" [style.background]=\"item.color\" [cpPosition]=\"'top'\" [cpPresetColors]=\"viewModel.legendColorPresets\" style=\"width:75px;\"/>\n            <!-- <input class=\"label\" [(ngModel)]=\"item.label\"> -->\n            <mat-form-field class=\"label\">\n                    <input matInput\n\n                    [(ngModel)]=\"item.label\">\n\n            </mat-form-field>\n            <img src=\"assets/icons/ic_clear_gray_24px.svg\" style=\"position: relative; top:5px; right:0px;\" (click)=\"viewModel.deleteLegendItem(i);\">\n        </div>\n        <button style=\"margin-left:75px; margin-top:10px; margin-bottom:10px;\" class=\"button\" (click)=\"viewModel.addLegendItem();\">Add Item</button>\n        <button style=\"margin-top:10px; margin-bottom:10px;\" class=\"button\" (click)=\"viewModel.clearLegend();\">Clear</button>\n    </div>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/datatable/technique-cell/technique-cell.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/datatable/technique-cell/technique-cell.component.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"cell\" \n     [ngStyle]=\"getTechniqueBackground()\" \n     [ngClass]=\"getClass()\"\n     (click)=\"onLeftClick($event)\"\n     (contextmenu)=\"onRightClick($event)\"\n     (mouseenter)=\"onHighlight()\"\n     (mouseleave)=\"onUnhighlight()\">\n    <span [style.border-color]=\"configService.comment_color\" \n          [style.color]=\"getTechniqueTextColor()\">\n        {{ [technique.name, viewModel.acronym(technique.name), ''][viewModel.viewMode] }}\n    </span>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/exporter/exporter.component.html":
/*!****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/exporter/exporter.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"controlsContainer\">\n    <ul class=\"control-sections\">\n        <li>\n            <div class=\"control-row-item noselect\">\n                <!-- {{exportData.tableConfig.unit}} -->\n                <div class=\"control-row-button\"\n                     (click)=\"unitEnum = (unitEnum + 1) % 3; exportData.tableConfig.unit = ['in', 'cm', 'px'][unitEnum]; buildSVG()\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"toggle measurement unit\">\n                    <svg fill=\"#000000\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" xmlns=\"http://www.w3.org/2000/svg\">\n                        <text x=\"4px\" y=\"50%\" dominant-baseline=\"middle\" style=\"font-size: 14px; font-weight: bold; font-family:monospace\">{{exportData.tableConfig.unit}}</text>\n                    </svg>\n                </div>\n            </div>\n\n        </li>\n        <li>\n            <div class=\"control-row-item\">\n                <div class=\"control-row-button dropdown noselect\"\n                     (click)=\"currentDropdown = currentDropdown !== 'imgsize' ? 'imgsize' : null;\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"image size\">\n                    <img src=\"assets/icons/ic_photo_size_select_large_black_24px.svg\"/>\n                </div>\n                <div class=\"dropdown-container size\" *ngIf=\"currentDropdown === 'imgsize'\" #dropdown [class.left]=\"checkalign(dropdown)\">\n                    <ul>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"width\"\n                                       step=\"0.01\"\n                                       [(ngModel)]=\"exportData.tableConfig.width\"\n                                       (input)=\"buildSVG()\" />\n                                <span matSuffix>{{exportData.tableConfig.unit}}</span>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"height\"\n                                       step=\"0.01\"\n                                       [(ngModel)]=\"exportData.tableConfig.height\"\n                                       (input)=\"buildSVG()\" />\n                                <span matSuffix>{{exportData.tableConfig.unit}}</span>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"header height\"\n                                       step=\"0.01\"\n                                       [disabled]=\"!exportData.tableConfig.showHeader\"\n                                       [(ngModel)]=\"exportData.tableConfig.headerHeight\"\n                                       (input)=\"buildSVG()\" />\n                                <span matSuffix  [style.color]=\"!exportData.tableConfig.showHeader ? 'rgba(0,0,0,0.42)' : 'black'\">{{exportData.tableConfig.unit}}</span>\n                            </mat-form-field>\n                        </li>\n                        <!-- <li>\n                            <mat-form-field>\n                                <mat-select placeholder=\"measurement unit\" [(ngModel)]=\"exportData.tableConfig.unit\" (change)=\"buildSVG()\">\n                                    <mat-option value=\"px\">pixels</mat-option>\n                                    <mat-option value=\"in\">inches</mat-option>\n                                    <mat-option value=\"cm\">centimeters</mat-option>\n                                </mat-select>\n                            </mat-form-field>\n                        </li> -->\n                    </ul>\n                </div>\n            </div>\n\n            <div class=\"control-row-item\">\n                <div class=\"control-row-button dropdown noselect\"\n                     (click)=\"currentDropdown = currentDropdown !== 'font' ? 'font' : null;\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"text\">\n                    <img src=\"assets/icons/ic_format_size_black_24px.svg\"/>\n                </div>\n                <div class=\"dropdown-container font\" *ngIf=\"currentDropdown === 'font'\" #dropdown [class.left]=\"checkalign(dropdown)\">\n                    <ul>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"title font size\"\n                                       step=\"1\"\n                                       [disabled]=\"!showName()\"\n                                       [(ngModel)]=\"exportData.tableConfig.headerLayerNameFontSize\"\n                                       (input)=\"buildSVG()\" />\n                                <span matSuffix [style.color]=\"!showName() ? 'rgba(0,0,0,0.42)' : 'black'\">{{exportData.tableConfig.fontUnit}}</span>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"font size in header\"\n                                       step=\"1\"\n                                       [disabled]=\"!exportData.tableConfig.showHeader\"\n                                       [(ngModel)]=\"exportData.tableConfig.headerFontSize\"\n                                       (input)=\"buildSVG()\" />\n                                <span matSuffix [style.color]=\"!exportData.tableConfig.showHeader ? 'rgba(0,0,0,0.42)' : 'black'\">{{exportData.tableConfig.fontUnit}}</span>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"tactic header font size\"\n                                       step=\"1\"\n                                       [(ngModel)]=\"exportData.tableConfig.tableTacticFontSize\"\n                                       (input)=\"buildSVG()\" />\n                                <span matSuffix>{{exportData.tableConfig.fontUnit}}</span>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"technique font size\"\n                                       step=\"1\"\n                                       [disabled]=\"exportData.tableConfig.tableTextDisplay === 'none'\"\n                                       [(ngModel)]=\"exportData.tableConfig.tableFontSize\"\n                                       (input)=\"buildSVG()\" />\n                                       <span matSuffix [style.color]=\"exportData.tableConfig.tableTextDisplay === 'none' ? 'rgba(0,0,0,0.42)' : 'black'\">{{exportData.tableConfig.fontUnit}}</span>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <mat-select placeholder=\"font size unit\" [(ngModel)]=\"exportData.tableConfig.fontUnit\" (selectionChange)=\"buildSVG()\">\n                                    <mat-option value=\"pt\">points</mat-option>\n                                    <mat-option value=\"px\">pixels</mat-option>\n                                </mat-select>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <mat-select placeholder=\"font\" [(ngModel)]=\"exportData.tableConfig.font\" (selectionChange)=\"buildSVG()\">\n                                    <mat-option value=\"serif\">serif</mat-option>\n                                    <mat-option value=\"sans-serif\">sans-serif</mat-option>\n                                    <mat-option value=\"monospace\">monospace</mat-option>\n                                </mat-select>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <mat-select placeholder=\"technique text\" [(ngModel)]=\"exportData.tableConfig.tableTextDisplay\" (selectionChange)=\"buildSVG()\">\n                                    <mat-option value=\"0\">no text</mat-option>\n                                    <mat-option value=\"1\">technique name</mat-option>\n                                    <mat-option value=\"2\">technique name (acronym)</mat-option>\n                                    <mat-option value=\"3\">technique ID</mat-option>\n                                </mat-select>\n                            </mat-form-field>\n                        </li>\n                    </ul>\n                </div>\n            </div>\n            <div class=\"control-row-item\">\n                <div class=\"control-row-button dropdown noselect\"\n                     (click)=\"showLegend()? currentDropdown = currentDropdown !== 'legend' ? 'legend' : null : continue;\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"legend\"\n                     [style.color]=\"showLegend() ? '#000000' : '#aaaaaa'\">\n                    <img [src]=\"showLegend()? 'assets/icons/ic_view_list_black_24px.svg' : 'assets/icons/ic_view_list_grey_24px.svg'\"/>\n                </div>\n                <div class=\"dropdown-container legend\" *ngIf=\"currentDropdown === 'legend'\" #dropdown [class.left]=\"checkalign(dropdown)\">\n                    <ul>\n                        <li>\n                            <input [id]=\"uid + 'legendDockedCheckbox'\"type=\"checkbox\" class=\"checkbox-custom\" [(ngModel)]=\"exportData.tableConfig.legendDocked\" (change)=\"buildSVG()\">\n                            <label [for]=\"uid + 'legendDockedCheckbox'\" class=\"checkbox-custom-label noselect\">\n                                dock legend in header\n                            </label>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"legend X position\"\n                                       [disabled]=\"exportData.tableConfig.legendDocked\"\n                                       step=\"1\"\n                                       [(ngModel)]=\"exportData.tableConfig.legendX\"\n                                       (input)=\"buildSVG()\" />\n                                <span [style.color]=\"exportData.tableConfig.legendDocked ? 'rgba(0,0,0,0.42)' : 'black'\" matSuffix>{{exportData.tableConfig.unit}}</span>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"legend Y position\"\n                                       [disabled]=\"exportData.tableConfig.legendDocked\"\n                                       step=\"1\"\n                                       [(ngModel)]=\"exportData.tableConfig.legendY\"\n                                       (input)=\"buildSVG()\" />\n                                <span [style.color]=\"exportData.tableConfig.legendDocked ? 'rgba(0,0,0,0.42)' : 'black'\" matSuffix>{{exportData.tableConfig.unit}}</span>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"legend width\"\n                                       [disabled]=\"exportData.tableConfig.legendDocked\"\n                                       step=\"1\"\n                                       [(ngModel)]=\"exportData.tableConfig.legendWidth\"\n                                       (input)=\"buildSVG()\" />\n                                <span [style.color]=\"exportData.tableConfig.legendDocked ? 'rgba(0,0,0,0.42)' : 'black'\" matSuffix>{{exportData.tableConfig.unit}}</span>\n                            </mat-form-field>\n                        </li>\n                        <li>\n                            <mat-form-field>\n                                <input matInput\n                                       class=\"has-suffix\"\n                                       type=\"number\"\n                                       placeholder=\"legend height\"\n                                       [disabled]=\"exportData.tableConfig.legendDocked\"\n                                       step=\"1\"\n                                       [(ngModel)]=\"exportData.tableConfig.legendHeight\"\n                                       (input)=\"buildSVG()\" />\n                                <span [style.color]=\"exportData.tableConfig.legendDocked ? 'rgba(0,0,0,0.42)' : 'black'\" matSuffix>{{exportData.tableConfig.unit}}</span>\n                            </mat-form-field>\n                        </li>\n                    </ul>\n                </div>\n            </div>\n            <div class=\"control-row-item\">\n                <div class=\"control-row-button dropdown noselect\"\n                     (click)=\"currentDropdown = currentDropdown !== 'visibility' ? 'visibility' : null;\"\n                     matTooltipPosition=\"below\"\n                     matTooltip=\"display settings\">\n                    <img src=\"assets/icons/ic_visibility_black_24px.svg\"/>\n                </div>\n                <div class=\"dropdown-container visibility\" *ngIf=\"currentDropdown === 'visibility'\" #dropdown [class.left]=\"checkalign(dropdown)\">\n                    <ul>\n                        <li>\n                            <input [id]=\"uid+'checkboxheader'\" type=\"checkbox\" class=\"checkbox-custom\" [(ngModel)]=\"exportData.tableConfig.showHeader\" (change)=\"buildSVG()\">\n                            <label [for]=\"uid+'checkboxheader'\" class=\"checkbox-custom-label noselect\">show header</label>\n                        </li>\n                        <li>\n                            <input [id]=\"uid+'checkboxname'\" type=\"checkbox\" [disabled]=\"!hasName() || !exportData.tableConfig.showHeader\" class=\"checkbox-custom\" [(ngModel)]=\"exportData.tableConfig.showName\" (change)=\"buildSVG()\">\n                            <label [for]=\"uid+'checkboxname'\" class=\"checkbox-custom-label noselect\" [class.disabled]=\"!hasName() || !exportData.tableConfig.showHeader\">show title</label>\n                        </li>\n                        <li>\n                            <input [id]=\"uid+'checkboxdescription'\" type=\"checkbox\" [disabled]=\"!hasDescription() || !exportData.tableConfig.showHeader\" class=\"checkbox-custom\" [(ngModel)]=\"exportData.tableConfig.showDescription\" (change)=\"buildSVG()\">\n                            <label [for]=\"uid+'checkboxdescription'\" class=\"checkbox-custom-label noselect\" [class.disabled]=\"!hasDescription() || !exportData.tableConfig.showHeader\">show description</label>\n                        </li>\n                        <li>\n                            <input [id]=\"uid+'checkboxfilters'\" type=\"checkbox\" class=\"checkbox-custom\" [disabled]=\"!exportData.tableConfig.showHeader\"[(ngModel)]=\"exportData.tableConfig.showFilters\" (change)=\"buildSVG()\">\n                            <label [for]=\"uid+'checkboxfilters'\" class=\"checkbox-custom-label noselect\" [class.disabled]=\"!exportData.tableConfig.showHeader\">show filters</label>\n                        </li>\n                        <li>\n                            <input [id]=\"uid+'checkboxgradient'\" type=\"checkbox\" [disabled]=\"!hasScores || !exportData.tableConfig.showHeader\" class=\"checkbox-custom\" [(ngModel)]=\"exportData.tableConfig.showGradient\" (change)=\"buildSVG()\">\n                            <label [for]=\"uid+'checkboxgradient'\" class=\"checkbox-custom-label noselect\" [class.disabled]=\"!hasScores || !exportData.tableConfig.showHeader\">show score gradient</label>\n                        </li>\n                        <li>\n                            <input [id]=\"uid+'checkboxlegend'\" type=\"checkbox\" [disabled]=\"!hasLegendItems()\" class=\"checkbox-custom\" [(ngModel)]=\"exportData.tableConfig.showLegend\" (change)=\"buildSVG()\">\n                            <label [for]=\"uid+'checkboxlegend'\" class=\"checkbox-custom-label noselect\" [class.disabled]=\"!hasLegendItems()\" >show legend</label>\n                        </li>\n                        <li>\n                            <input [id]=\"uid+'checkboxtcount'\" type=\"checkbox\" class=\"checkbox-custom\" [(ngModel)]=\"exportData.tableConfig.showTechniqueCount\" (change)=\"buildSVG()\">\n                            <label [for]=\"uid+'checkboxtcount'\" class=\"checkbox-custom-label noselect\">show technique count</label>\n                        </li>\n                        <li>\n                            <input [id]=\"uid+'tableBorderInput'\" class=\"colorpicker\" [(colorPicker)]=\"exportData.tableConfig.tableBorderColor\" [style.background]=\"exportData.tableConfig.tableBorderColor\" cpPosition=\"bottom\" [cpPresetColors]=\"['#ddd', '#aaaaaa', '#205B8F', '#B9482D', '#ffffff', '#000000']\"\n                             (colorPickerSelect)=\"buildSVG()\" [cpOKButton]=\"true\" [cpOKButtonText]=\"'apply'\" [cpCancelButton]=\"true\" style=\"width: 14px; margin: 5px 0 0 5px;\">\n                             <label [for]=\"uid+'tableBorderInput'\" class=\"noselect\">cell border</label>\n\n                        </li>\n                    </ul>\n                </div>\n            </div>\n        </li>\n        <li>\n            <div class=\"control-row-item\">\n                <div class=\"control-row-button noselect\"\n                [id]=\"'download-button' + exportData.viewModel.uid\"\n                    (click)=\"downloadSVG()\"\n                    matTooltipPosition=\"below\"\n                    matTooltip=\"download SVG\">\n                    <img src=\"assets/icons/ic_file_download_black_24px.svg\" alt=\"save layer\"/>\n                </div>\n            </div>\n\n        </li>\n    </ul>\n<!-- <ul>\n    <li *ngFor=\"let configItem of getKeys(exportData.tableConfig)\">\n        {{configItem}}:\n        <select *ngIf=\"configItem === 'unit'\" [(ngModel)]=\"exportData.tableConfig[configItem]\" (change)=\"buildSVG()\">\n            <option value=\"px\">px</option>\n            <option value=\"in\">in</option>\n            <option value=\"cm\">cm</option>\n        </select>\n        <select *ngIf=\"configItem === 'tableTextDisplay'\" [(ngModel)]=\"exportData.tableConfig[configItem]\" (change)=\"buildSVG()\">\n            <option value=\"none\">No Text</option>\n            <option value=\"name\">Technique Name</option>\n            <option value=\"id\">Technique ID</option>\n        </select>\n        <select *ngIf=\"configItem === 'font'\" [(ngModel)]=\"exportData.tableConfig[configItem]\" (change)=\"buildSVG()\">\n            <option value=\"serif\">serif</option>\n            <option value=\"sans-serif\">sans-serif</option>\n            <option value=\"monospace\">monospace</option>\n        </select>\n\n        <input *ngIf=\"type(exportData.tableConfig[configItem]) == 'number'\" type=\"number\" [(ngModel)]=exportData.tableConfig[configItem] (input)=\"buildSVG()\">\n        <input *ngIf=\"type(exportData.tableConfig[configItem]) == 'boolean'\" type=\"checkbox\" [(ngModel)]=exportData.tableConfig[configItem] (change)=\"buildSVG()\">\n\n    </li>\n</ul> -->\n\n\n</div>\n\n<div class=\"svgcontainer\" [id]=\"'svgInsert' + exportData.viewModel.uid\">\n    loading...\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/help/help.component.html":
/*!********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/help/help.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"help\">\n\n    <h1>Table of Contents</h1>\n\n    <ul class=\"toc\">\n        <li>\n            <a href=\"#about\">About</a>\n        </li>\n        <li>\n            <a href=\"#help_Layers\">Layers</a>\n            <ul>\n                <li><a href=\"#help_Creating_New_Layers\">Creating New Layers</a></li>\n                <li><a href=\"#help_Saving_and_Loading_Layers\">Saving and Loading Layers</a></li>\n                <li><a href=\"#help_Creating_Layers_from_Other_Layers\">Creating Layers from Other Layers</a></li>\n            </ul>\n        </li>\n\n        <li>\n            <a href=\"#help_Layer_Controls\">Layer Controls</a>\n            <ul>\n                <li><a href=\"#help_Layer_Information\">Layer Information</a></li>\n                <li><a href=\"#help_Sorting\">Sorting</a></li>\n                <li><a href=\"#help_Filtering\">Filtering</a></li>\n                <li>\n                    <a href=\"#help_Color_Setup\">Color Setup</a>\n                    <ul>\n                        <li><a href=\"#help_Tactic_Row_Background\">Tactic Row Background</a></li>\n                        <li><a href=\"#help_Scoring_Gradient\">Scoring Gradient</a></li>\n                    </ul>\n                </li>\n                <li><a href=\"#help_Hiding_Disabled_Techniques\">Hiding Disabled Techniques</a></li>\n                <li>\n                    <a href=\"#help_Changing_Views\">Changing Views</a>\n                    <ul>\n                        <li><a href=\"#help_Full_View\">Full View</a></li>\n                        <li><a href=\"#help_Compact_View\">Compact View</a></li>\n                        <li><a href=\"#help_Mini_View\">Mini View</a></li>\n                    </ul>\n                </li>\n                <li><a href=\"#help_Legend\">Legend</a></li>\n            </ul>\n        </li>\n        <li>\n            <a href=\"#help_Technique_Controls\">Technique Controls</a>\n            <ul>\n\n                <li><a href=\"#help_Disabling_Techniques\">Disabling Techniques</a></li>\n                <li><a href=\"#help_Assigning_Manual_Colors\">Assigning Manual Colors</a></li>\n                <li><a href=\"#help_Scoring_Techniques\">Scoring Techniques</a></li>\n                <li><a href=\"#help_Adding_Comments_to_Techniques\">Adding Comments to Techniques</a></li>\n                <li><a href=\"#help_Clearing_Selected_Techniques_Annotations\">Clearing Annotations on Techniques</a> </li>\n            </ul>\n        </li>\n        <li>\n            <a href=\"#help_Selecting_Techniques\">Selecting Techniques</a>\n            <ul>\n                <li><a href=\"#help_Selecting_with_the_Mouse\">Selecting with the Mouse</a></li>\n                <li><a href=\"#help_Lock_Multi-Tactic_Technique_Selection\">Lock Multi-Tactic Technique Selection</a></li>\n                <li><a href=\"#help_Search_Interface\">Search Interface</a></li>\n                <li><a href=\"#help_Multiselct_Interface\">Multiselect Interface</a></li>\n            </ul>\n        </li>\n        <li>\n            <a href=\"#help_Customizing_The_Navigator\">Customizing The Navigator</a>\n            <ul>\n                <li><a href=\"#help_Default_Layers\">Default Layers</a></li>\n                <li><a href=\"#help_Disable_Features\">Disabling Features</a></li>\n            </ul>\n        </li>\n        <li>\n            <a href=\"#help_Rendering_Layers_As_SVG\">Exporting Layers as SVG</a>\n            <ul>\n                <li><a href=\"#help_exporting_units\">Measurement Units</a></li>\n                <li><a href=\"#help_exporting_image_size\">Configuring Image Size</a></li>\n                <li><a href=\"#help_exporting_text\">Configuring Text</a></li>\n                <li><a href=\"#help_exporting_legend_config\">Customizing the Legend</a></li>\n                <li><a href=\"#help_exporting_display_settings\">Display Settings</a></li>\n            </ul>\n        </li>\n        <li>\n            <a href=\"#help_Rendering_Layers_As_XLSX\">Exporting Layers to MS Excel</a>\n        </li>\n        <li><a href=\"#notice\">Notice</a></li>\n\n    </ul>\n\n    <h1 id=\"about\"> MITRE ATT&CK® Navigator Version {{nav_version}}</h1>\n    <p>\n        The ATT&CK Navigator is designed to provide basic navigation and\n        annotation of ATT&CK matrices, something that people are already doing\n        today in tools like Excel. We've designed it to be simple and generic -\n        you can use the Navigator to visualize your defensive coverage, your\n        red/blue team planning, the frequency of detected techniques or anything\n        else you want to do. The Navigator doesn't care - it just allows you to\n        manipulate the cells in the matrix (color coding, adding a comment,\n        assigning a numerical value, etc.). We thought having a simple tool that\n        everyone could use to visualize the matrix would help make it easy to\n        use ATT&CK.\n    </p>\n    <p>\n        The principal feature of the Navigator is the ability for users to\n        define layers - custom views of the ATT&CK knowledge base - e.g. showing\n        just those techniques for a particular platform or highlighting\n        techniques a specific adversary has been known to use. Layers can be\n        created interactively within the Navigator or generated programmatically\n        and then visualized via the Navigator.\n    </p>\n    <p>\n        Bug reports and feature requests can be submitted to our <a href=\"https://github.com/mitre-attack/attack-navigator/issues\">GitHub Issue Tracker</a>.\n        The source code for the ATT&CK Navigator can be retrieved from our\n        <a href=\"https://github.com/mitre-attack/attack-navigator\">GitHub repository</a>.\n    </p>\n\n\n    <!-- sections -->\n    <h1 id=\"help_Layers\">Layers</h1>\n    <p>\n      A layer constitutes a view of the tactics and techniques matrix for a\n      specific technology domain. Version {{nav_version}} of the Navigator can manipulate\n      either the Enterprise (Windows, Linux & Mac) or Mobile (Android & iOS)\n      ATT&CK technology domain knowledge bases. Within a technology domain, the\n      Navigator allows you to filter your view of the matrix in a variety of\n      ways, displaying the tactics and techniques that are important to you.\n    </p>\n    <p>\n      You can view the definition of any technique in the visible matrix by\n      right-clicking on the technique and selecting \"view technique\" in the\n      pop-up menu. A new browser tab will be opened displaying the definition of\n      the technique. In this way the Navigator allows you to explore a given\n      ATT&CK matrix and access the definitions of the techniques.\n    </p>\n    <p>\n      Beyond the filters, layers also provide a means to customize your view of\n      the matrix. To that end you can <a href=\"#help_Assigning_Manual_Colors\">color</a>, <a href=\"#help_Hiding_Disabled_Techniques\">hide</a>, <a href=\"#help_Adding_Comments_to_Techniques\">comment</a>, and assign <a href=\"#help_Scoring_Techniques\">numeric\n      scores</a> to techniques to aid in analysis of threats and your defenses\n      against those threats. As stated earlier, the Navigator is designed to be\n      simple, allowing you to assign whatever meaning you want to the\n      color-codings, scores, and comments. This way the Navigator can support\n      whatever you want to do without requiring changes to the Navigator code\n      itself.\n    </p>\n    <p>\n      Each layer created is independent of other layers. However, layers can be\n      <a href=\"#help_Creating_Layers_from_Other_Layers\">combined</a> in ways to support analysis, or <a href=\"#help_Saving_and_Loading_Layers\">saved locally</a>. Layer files are\n      saved in easy to parse and easy to generate JSON file so that ATT&CK data\n      can be used in other applications, analyzed beyond the capability of the\n      ATT&CK Navigator, and generated by tools for import into the Navigator.\n      The Layer file format is described <a href=\"assets/NavigatorLayerFileFormatv2_2.pdf\">here</a>.\n    </p>\n\n\n    <h2 id=\"help_Creating_New_Layers\">Creating New Layers</h2>\n    <p>\n        To create a new layer, open a new tab and click the \"Create New Layer\" button.\n        Note that for performance reasons, the Navigator currently imposes a limit of\n        ten (10) active layers at any given point in time.\n    </p>\n    <h2 id=\"help_Saving_and_Loading_Layers\">Saving and Loading Layers</h2>\n    <p>\n        Layers can be saved by clicking the \"save layer\" button (<img src=\"assets/icons/ic_file_download_black_24px.svg\">). This will open a dialog\n        to save a layer configuration file to your local computer. This contains\n        the configuration for the techniques that have been customized\n        (commented, colored, assigned a score, or disabled) as well as the\n        scoring gradient setup, filter selection, layer name, layer description,\n        view configuration.\n    </p>\n    <p>\n        Saved layer configuration files can be opened in the ATT&CK navigator to\n        restore a layer you've worked on previously. To do so, open a new tab\n        and open the \"Open Existing Layer\" panel. Then click \"Upload from\n        local\", and select your saved configuration file. Doing so will restore\n        your saved layer to the ATT&CK navigator. This interface also has a \"load from URL\"\n        input allowing you to open a layer json from a remote source.\n    </p>\n    <h2 id=\"help_Creating_Layers_from_Other_Layers\">Creating Layers from Other Layers</h2>\n    <p>\n        Layers can be created which inherit properties from other layers. Several fields\n        exist which can be used to choose which layers to inherit properties from:\n    </p>\n    <ul>\n        <li>\n            <p>\n                <b>Score Expression:</b> Technique <a href=\"#help_Scoring_Techniques\">scores</a>  in the created layer are\n                initialized to the result of this expression. This field should take\n                the form of an equation or constant, using variables for layers.\n                Layer variables are shown in yellow on tabs when the \"create layer\n                from other layers\" panel is opened:\n            </p>\n            <img src=\"assets/image_scoreVariableExample.png\" height=\"100px\">\n            <p>\n                Each technique's score is created independently using the score expression. For example,\n                with a score expression of <code>a+b</code>, some technique <i>t</i> in the output layer would\n                be the sum of <i>t<sub>a</sub></i> and <i>t<sub>b</sub></i>.\n            </p>\n            <p>\n                Expressions can also be comparative, for example <code>a>b</code>\n                will create a layer with a score of 1 whereever <code>a>b</code> and\n                0 whereever <code>a<=b</code>. Such boolean expressions can be\n                extended using <code>and</code>, <code>or</code>, <code>xor</code>\n                and <code>not</code>. You can also use ternary expressions such as <code>a > b ? 25 : 10</code>\n                See <a href=\"http://mathjs.org/docs/expressions/syntax.html#operators\">\n                    this page</a> for a  full list of operators.\n                </p>\n                Some example score expressions:\n                <ul>\n                    <li>\n                        <code>(a+b)/2</code> (average two layers)\n                    </li>\n                    <li>\n                        <code>a+b+c</code>\n                    </li>\n                    <li>\n                        <code>a*(b+c)</code>\n                    </li>\n                    <li>\n                        <code>100-a</code> (reverse the scoring of <code>a</code>, assuming <code>a</code> is on a 0-100 scale)\n                    </li>\n                    <li>\n                        <code>(a>b) and (a>=75)</code>\n                    </li>\n                </ul>\n            </li>\n            <li>\n                <b>Coloring:</b> choose which layer to inherit <a href=\"#help_Assigning_Manual_Colors\">manually assigned technique colors</a> from.\n            </li>\n            <li>\n                <b>Comments:</b> choose which layer to inherit <a href=\"#help_Adding_Comments_to_Techniques\">technique comments</a> from.\n            </li>\n            <li>\n                <b>States:</b> choose which layer to inherit technique <a href=\"#help_Disabling_Techniques\">enabled/disabled states</a> from.\n            </li>\n            <li>\n                <b>Filters:</b> choose which layer to inherit <a href=\"#help_Filtering\">layer filter configuration</a> from.\n            </li>\n            <li>\n                <b>Legend:</b> choose which layer to inherit <a href=\"#help_Legend\">legend items</a> from.\n            </li>\n        </ul>\n        <p>\n            <!-- TODO: update this with links to main doc section for feature -->\n            Tactic-spanning Techniques are evaluated individually: if a technique is annotated differently\n            in two tactics, the output layers' techniques will honor this difference.\n        </p>\n        <p>\n            <b>Tip:</b> Score expressions don't need to use variables! You can use\n            this to create a new layer with a constant score for each technique. For\n            example, if you wanted a new layer where all techniques are scored 50, you \n            could simply type 50 into the score expression input.\n        </p>\n\n        <h1 id=\"help_Layer_Controls\">Layer Controls</h1>\n        <h2 id=\"help_Layer_Information\">\n            <img src=\"assets/icons/ic_description_black_24px.svg\">\n            Layer Information\n        </h2>\n        <p>\n                The layer name and description can be edited in the layer information dropdown. The layer name can also be edited where it appears in the tab title. \n                Additionally, the layer information panel allows the user to add metadata to the layer. Metadata can be useful for supporting other applications that use the layer format, \n                or for attaching additional descriptive fields to the layer. \n        </p>\n        <p>\n          \n            <b>Note:</b> techniques can also have metadata, however metadata on techniques is not editable in the Navigator. Metadata on techniques is shown\n            in tooltips.\n        </p>\n        \n\n        <h2 id=\"help_Sorting\">\n            Sorting\n        </h2>\n        <p>\n            There are four modes of sorting. Clicking the sorting button will toggle between the modes.\n        </p>\n\n        <ul>\n            <li>\n                <img src=\"assets/icons/ic_sort_alphabetically_ascending_black_24px.svg\"/>\n                The table will sort techniques alphabietically by name in ascending order.\n            </li>\n            <li>\n                <img src=\"assets/icons/ic_sort_alphabetically_descending_black_24px.svg\"/>\n                The table will sort techniques alphabetically by name in descending order.\n            </li>\n            <li>\n                <img src=\"assets/icons/ic_sort_numerically_ascending_black_24px.svg\"/>\n                The table will sort techniques by their score in ascending order. Techniques with no score are treated as if their score is 0.\n            </li>\n            <li>\n                <img src=\"assets/icons/ic_sort_numerically_descending_black_24px.svg\"/>\n                The table will sort techniques by their score in descending order. Techniques with no score are treated as if their score is 0.\n            </li>\n        </ul>\n\n\n\n        <h2 id=\"help_Filtering\">\n            <img src=\"assets/icons/ic_filter_list_black_24px.svg\"/>\n            Filtering\n        </h2>\n        <p>\n            The list of techniques and tactics can be filtered in the filtering menu.\n            Filters are additive - the displayed set of techniques is the logical <i>or</i>\n            of the techniques of the filters selected. There are two categories of filters that you can apply to a layer - a platform filter and a stages filter.\n        </p>\n        <h3>Platform Filter</h3>\n        <p>\n            The platform filter allows the user to control which techniques are\n            included in a layer based on whether or not a particular technique\n            applies to a particular technology platform.  Technology platforms\n            are tied to the specific technology domain you are visualizing. For\n            the Enterprise technology domain, the defined platforms are:\n            Windows, Linux, macOS, AWS, GCP, Azure, Azure AD, Office 365, and SaaS.  For the Mobile technology domain, the\n            defined platforms are: Android and iOS. \n        </p>\n        <p>\n            Each technique in an ATT&CK matrix is tied to one or more platforms.\n            In the Navigator, if you wanted to see only those techniques in\n            Enterprise ATT&CK which applied to the Linux platform, you would\n            deselect \"Windows\" and \"macOS\" under the platform filter. If later you\n            decided to also include techniques known to apply to macOS\n            platforms, you could select \"macOS\" as well and those techniques would\n            be added to the visible layer.\n        </p>\n        <h3>Stage Filter</h3>\n        <p>\n            In addition to filtering based on technology platform, you can also\n            control which techniques to include in a layer based on where they\n            fall in the cyber attack lifecycle.  The Navigator defines two\n            \"stages\" in this lifecycle: \"prepare\" - those tactics that an\n            adversary uses prior to compromise of their target and \"act\" - those\n            tactic categories at and after the launch of a compromise attempt.\n            By default, only the \"act\" stage is selected in a newly-created\n            layer to help keep the visible matrix to a manageable size. Note\n            that when viewing a layer with both the prepare and act stages\n            selected, you may find the \"compact\" matrix view particularly\n            useful.\n        </p>\n\n        <p>\n            <b>Tip:</b> Techniques can also be hidden from your view by using the <a href=\"#help_Hiding_Disabled_Techniques\">hide disabled techniques</a>\n            button. Couple this with the <a href=\"#help_Multiselct_Interface\">multiselect interface</a>\n            to hide techniques which are contained in specific threat or software groupings.\n        </p>\n\n        <h2 id=\"help_Color_Setup\">\n            <img src=\"assets/icons/ic_palette_black_24px.svg\"/>\n            Color Setup\n        </h2>\n        <h3 id=\"help_Tactic_Row_Background\">\n            Tactic Row Background\n        </h3>\n        <p>\n            The background color of the tactic row can be set in the tactic row background section of the color setup menu. The color\n            will only be displayed if the \"show\" checkbox is selected. The tactic row background will not be shown when in the <a href=\"#help_Mini_View\">mini view</a>.\n        </p>\n\n\n        <h3 id=\"help_Scoring_Gradient\">Scoring Gradient</h3>\n        <p>\n            Techniques which are assigned a score will be colored according to a\n            gradient defined in the scoring gradient section in the color setup menu. Technique scores are\n            mapped to a color scaled linearly between the \"low value\" and \"high value\"\n            inputs. For example, on a red-green scale, if \"low value\" were set to 0 and\n            \"high value\" were set to 50, a score of 25 would fall on yellow -- exactly\n            halfway between red and green. Scores below the low value are colored as if\n            they have the low value, and scores above the high value are colored as if\n            they have the high value.\n        </p>\n        <p>\n            Several preset gradients are present within the preset dropdown. If no preset\n            matches your desired gradient, you can create your own by adding and removing\n            colors using the interface.\n        </p>\n        <p>\n            <b>Tip:</b> If your scores are binary (0 or 1), consider setting the low\n            value of 0 to white and the high of 1 to some other\n            color to only color the techniques which have the value of 1.\n        </p>\n\n        <h2 id=\"help_Hiding_Disabled_Techniques\">\n            <img src=\"assets/icons/ic_visibility_off_black_24px.svg\">\n            Hiding Disabled Techniques\n        </h2>\n        <p>\n            Techniques that are <a href=\"#help_Disabling_Techniques\">disabled</a> can be hidden by toggling the \"hide disabled techniques\" button.\n            Hidden techniques are still present in the data when saved and can still be annotated, but won't be visible in the view.\n        </p>\n        <p>\n            <b>Tip:</b> This button has powerful synergy with the <a\n            href=\"#help_Multiselct_Interface\">multiselect interface</a>. Use the\n            multiselect interface to select techniques which match your criteria,\n            disable them, and then turn on hiding disabled techniques to remove entire\n            groups of techniques from your view.\n        </p>\n\n        <h2 id=\"help_Changing_Views\">\n            Changing Views\n        </h2>\n        <p>\n            The ATT&CK Navigator has multiple ways to view the data. Toggle between these views\n            with the \"toggle view mode\" button.\n        </p>\n        <h3 id=\"help_Full_View\">\n            <img src=\"assets/icons/ic_view_large_black_24px.svg\">\n            Full View\n        </h3>\n        <p>\n            The full view (default), shows the full names of tactics\n            (column headers) and techniques (column cells). It also shows the\n            number of displayed techniques inside of each tactic. Techniques that are\n            hidden by filtering or by hiding disabled techniques do not count towards\n            this count.\n        </p>\n        <h3 id=\"help_Compact_View\">\n            <img src=\"assets/icons/ic_view_medium_black_24px.svg\">\n            Compact View\n        </h3>\n        <p>\n            The compact view is designed to fit more techniques\n            on the screen simultaneously by reducing their size. To do so all text is\n            abbreviated to acronyms. Full technique and tactic names are displayed as tooltips when you hover over a technique. Otherwise it behaves the same as the <a href=\"#help_Full_View\">full view</a>.\n        </p>\n\n        <h3 id=\"help_Mini_View\">\n            <img src=\"assets/icons/ic_view_small_black_24px.svg\">\n            Mini View\n        </h3>\n        <p>\n            The mini view is designed to fit more techniques on the screen\n            simultaneously by reducing their size. To do so all text is removed\n            and techniques are visualized as boxes. In this view techniques can arrange themselves\n            as grids inside of each tactic column to conserve space. Tactic headers\n            are visualized as black cells above the columns. Technique\n            and tactic names are displayed as tooltips when you hover over a\n            technique or tactic-header cell. The presence of a comment upon a technique\n            is not displayed in this mode, but comments can still be seen inside of\n            tooltips.\n        </p>\n        <h2 id=\"help_Legend\">\n            Legend\n        </h2>\n        <p>\n            The legend helps associate meanings with colors displayed by customized techniques in the ATT&CK Navigator.\n            To open the legend, click on the bar labled \"legend\" in the bottom-right corner of the screen. Click on the same bar to close the legend. To add an item to the legend, click the \"Add Item\"\n            button. To clear all items in the legend, click \"Clear\".\n            <br/><br/>\n            An item's color can be changed by either clicking in the color field and typing a hex color value, or by clicking in the field and choosing a color from the color picker. Click and type in the\n            text field to change the item's label. To remove an item, click on the (<img src=\"assets/icons/ic_clear_gray_24px.svg\"/>) button on the right side. Legend items are saved to the layer file and will be\n            loaded when a layer with saved legend items is loaded.\n        </p>\n\n        <h1 id=\"help_Technique_Controls\">Technique Controls</h1>\n        <p>\n            Techniques in the layer can be annotated. The technique controls on the menubar\n            are only enabled when one or more techniques are <a href=\"#help_Selecting_Techniques\">selected</a>.\n            If multiple techniques are selected, they will all be annotated simultaneously.\n        </p>\n\n\n\n        <h2 id=\"help_Disabling_Techniques\">\n            <img src=\"assets/icons/ic_texture_black_24px.svg\">\n            Disabling Techniques\n        </h2>\n        <p>\n            Clicking the \"toggle state\" button toggles selected techniques between an\n            enabled and disabled state. In the disabled state, the technique text is greyed\n            out and no colors (<a href=\"#help_Assigning_Manual_Colors\">assigned manually</a> or via <a href=\"#help_Scoring_Techniques\">score</a>)\n            will be displayed.\n        </p>\n        <p>\n            The <a href=\"#help_Hiding_Disabled_Techniques\">hide disabled techniques</a>\n            button can be used to hide disabled techniques from the view.\n        </p>\n\n        <h2 id=\"help_Assigning_Manual_Colors\">\n            <img src=\"assets/icons/ic_format_color_fill_black_24px.svg\">\n            Assigning Manual Colors\n        </h2>\n        <p>\n            Techniques can be assigned colors manually. Manually assigned colors supersede\n            colors created by score. To remove a manually assigned color, select the \"no color\"\n            box at the top of the interface.\n        </p>\n\n        <h2 id=\"help_Scoring_Techniques\">\n            <img src=\"assets/icons/ic_insert_chart_black_24px.svg\">\n            Scoring Techniques\n        </h2>\n        <p>\n            A score is a numeric value assigned to a technique. The meaning or\n            interpretation of scores is completely up to the user user - the\n            Navigator simply visualizes the matrix based on any scores you have\n            assigned. Some possible uses of scores include:\n        </p>\n        <ul>\n            <li>\n                Assigning a score to techniques based on whether or not a given\n                adversary group has been observed to use that technique.\n            </li>\n            <li>\n                Assigning a score to techniques based on your organization's\n                ability to detect, prevent and/or mitigate the use of a\n                particular technique.\n            </li>\n             <li>\n                 Assigning a score to those techniques that a red-team has\n                 successfully employed during an exercise.\n             </li>\n        </ul>\n        <p>\n            By default, techniques are \"unscored\" meaning that no score has been\n            assigned to the technique.  Note that \"unscored\" and a score of zero\n            are not the same, specifically with respect to automatically\n            assigned colors. Scores show up in technique tooltips if a score has\n            been assigned. To change a technique with a numeric score to\n            unscored, select the technique and delete the score value in the score\n            control. The technique will revert to unscored.\n        </p>\n        <p>\n            Techniques are automatically assigned a color according to its\n            score. This color is determined according to the <a href=\"#help_Scoring\">scoring gradient setup interface</a>. Colors\n            assigned <a href=\"#help_Assigning_Manual_Colors\">manually</a>\n            supersede the score-generated color. It is a good idea to assign\n            techniques scores inside of a given range, such as 0-1 or 0-100. Set\n            the \"high value\" and \"low value\" inputs in the <a href=\"#help_Scoring\">scoring gradient setup interface</a> to this\n            range to make sure that the color for the score is properly mapped\n            to the gradient. Techniques that are unscored are not assigned a\n            color based on the gradient - they are displayed with a white\n            background in the matrix.\n        </p>\n\n        <h2 id=\"help_Adding_Comments_to_Techniques\">\n            <img src=\"assets/icons/ic_insert_comment_black_24px.svg\">\n            Adding Comments to Techniques\n        </h2>\n        <p>\n            A text comment can be added to techniques. This comment will show up in the technique tooltip if a comment has been added.\n            Techniques with a comment will be given a yellow underline.\n        </p>\n        <h2 id=\"help_Clearing_Selected_Techniques_Annotations\">\n            <img src=\"assets/icons/ic_clear_black_24px.svg\">\n            Clearing Annotations on Techniques\n        </h2>\n        <p>\n            Clicking the \"clear annotations on selected\" button removes comments,\n            colors, scores, and enabled/disabled state from all selected techniques.\n        </p>\n\n        <h1 id=\"help_Selecting_Techniques\">Selecting Techniques</h1>\n\n        <p>\n            In order to be annotated, techniques must first be selected. There are multiple ways\n            to select techniques.\n        </p>\n        <h2 id=\"help_Selecting_with_the_Mouse\">Selecting with the Mouse</h2>\n        <p>\n            Techniques can be selected using the mouse. Left click a technique to select\n            it. Pressing control (windows) command (mac) or shift (both) while left-clicking a technique will add it to or remove it from the selection. Right\n            clicking a technique will bring up a context menu with more options:\n        </p>\n        <ul>\n            <li><b>select:</b> Select only this technique.</li>\n            <li><b>add to selection:</b> Add this technique to the selection.</li>\n            <li><b>remove from selection:</b> remove this technique from the selection.</li>\n            <li><b>invert selection:</b> Select all techniques that are not currently selected and unselect all techniques that are currently selected.</li>\n            <li><b>select all:</b> Select all techniques.</li>\n            <li><b>deselect all:</b> Deselect all techniques. This action can also be completed by the \"deselect\" (<img src=\"assets/icons/ic_clear_black_24px.svg\"/>) button.</li>\n            <li><b>view technique:</b> For more information / details on the technique.</li>\n        </ul>\n\n        <h2 id=\"help_Lock_Multi-Tactic_Technique_Selection\">\n            <img src=\"assets/icons/ic_lock_black_24px.svg\">\n            Lock Multi-Tactic Technique Selection\n        </h2>\n        <p>\n            This control toggles whether selecting a technique selects that technique across all tactics or just that one instance.\n        </p>\n\n        <h2 id=\"help_Search_Interface\">\n            <img src=\"assets/icons/ic_search_black_24px.svg\">\n            Search Interface\n        </h2>\n        <p>\n            The search interface provides a text input to search through techniques in the matrix.\n            Toggles in the interface allow for searching of specific technique fields (name, ID, and description).\n        </p>\n        <p>\n            The interface provides\n            buttons to select and deselect techniques. These buttons modify the currently selected techniques rather\n            than replacing then, allowing for the selection of the multiple techniques by selecting them in sequence.\n            There are 'view' links that lead to more info on each technique.\n        </p>\n        <p>\n            Buttons labelled 'select all' and 'deselect all' are provided to quickly select/deselect all techniques in the results\n            area.\n        </p>\n\n        <h2 id=\"help_Multiselct_Interface\">\n            <img src=\"assets/icons/ic_playlist_add_black_24px.svg\">\n            Multiselect Interface\n        </h2>\n        <p>\n            The multiselect interface provides a way to quickly select and deselect\n            groups of techniques. The interface provides two types of groupings, threat\n            groups and software. Threat groups constitute related intrusion activity\n            tracked by a common name. Software constitutes software, malware\n            or utilities that use known techniques for intrusion.\n        </p>\n        <p>\n            The interface provides\n            buttons to select and deselect techniques associated with each software or\n            threat group. These buttons modify the currently selected techniques rather\n            than replacing then, allowing for the selection of the techniques of multiple\n            threat groups or software by selecting them in sequence.\n        </p>\n        <p>\n            Threat groups and software in the list are given a gray background when all\n            of their techniques are selected, even if the selection was not made using\n            the multiselect interface.\n        </p>\n\n        <h1 id=\"help_Customizing_The_Navigator\">Customizing The Navigator</h1>\n        <p>\n            The ATT&CK Navigator can be customized by modifying the fragment (e.g <code>example.com<b>#fragment</b></code>) of the URL.\n            A panel on the new tab page exists to build a properly formatted ATT&CK Navigator URL\n            such that, when opened, it will create an ATT&CK Navigator instance with the desired\n            customizations. This feature may be useful for sharing or embedding the ATT&CK Navigator.\n        </p>\n\n\n        <h2 id=\"help_Default_Layers\">Default Layers</h2>\n        <p>\n            Click the \"add a layer link\" button, then enter a default layer URL pointing to a layer hosted on the web. \n            This will cause the customized ATT&CK Navigator to initialize with this layer open by default. \n            This is especially useful for embedding or sharing specific layers.\n        </p>\n        <p>\n            You can click the \"add another layer link\" button to specify additional default layers, or click the \"x\" button next to a layer link you've already added to remove it.\n        </p>\n        <p>\n            The following is an example ATT&CK Navigator URL with the default layer specified to be the *Bear APTs layer from <a href=\"https://github.com/mitre-attack/attack-navigator\">our github repo</a>: <br /><code>https://mitre-attack.github.io/attack-navigator/enterprise/<b>#layerURL=https%3A%2F%2Fraw.githubusercontent.com%2Fmitre%2Fattack-navigator%2Fmaster%2Flayers%2Fdata%2Fsamples%2FBear_APT.json</b></code>\n        </p>\n\n\n        <h2 id=\"help_Disable_Features\">Disabling Features</h2>\n        <p>\n            Individual ATT&CK Navigator features can be disabled with the checkboxes. Removing\n            a feature only removes the interface elements of the feature -- opened\n            layers utilizing those features will still have them present. For example,\n            even if comments are disabled layers with comments present will still display\n            them visually and in tooltips.\n        </p>\n        <p>\n            If you are hosting your own navigator instance, you can also disable\n            features by editing the configuration file <code>assets/config.json</code>.\n        </p>\n        <p>\n            The following is an example ATT&CK Navigator URL with the ability to download the layer and add comments disabled: <br /><code>https://mitre-attack.github.io/attack-navigator/enterprise/<b>#download_layer=false&comments=false</b></code>\n        </p>\n\n        <h1 id=\"help_Rendering_Layers_As_SVG\">\n            <img src=\"assets/icons/ic_camera_alt_black_24px.svg\">\n            Rendering Layers as SVG\n        </h1>\n        <p>\n            Clicking the \"render layer to SVG\" button will open a new tab allowing the current layer\n            to be rendered to an SVG image. Changes to the layer after opening the render tab\n            will not be reflected in the render layer.\n        </p>\n        <p>\n            Clicking the <i>download svg</i> button (<img src=\"assets/icons/ic_file_download_black_24px.svg\">) will download\n            the image, as displayed, in SVG format.\n        </p>\n        <p>\n            The Microsoft Edge browser has a bug where the downloaded SVG\n            will have the <code>.txt</code> extension. Renaming the extension to <code>.svg</code> will\n            restore it as a valid svg file.\n        </p>\n\n        <h2 id=\"help_exporting_units\">Measurement Units</h2>\n        <p>\n            Clicking the \"toggle measurement unit\" button will toggle between\n            measuring in inches (in), centimeters (cm), and pixels (px). This unit\n            applies to controls for image size and legend position.\n        </p>\n\n        <h2 id=\"help_exporting_image_size\">\n            <img src=\"assets/icons/ic_photo_size_select_large_black_24px.svg\">\n            Configuring Image Size\n        </h2>\n        <p>\n            The image size controls allow you to specify the width and height of\n            the image, as well as the height of the header if one is present.\n            The measurements are in units specified by the <a href=\"#help_exporting_units\">measurement units</a> control.\n        </p>\n        <p>\n            The header height contributes to the total image height: if you have specified\n            the image height to be 8.5 inches and the header height to be 1 inch,\n            the technique table will be 7.5 inches and the header 1 inch for a total height of 8.5 inches.\n            If the header is disabled this control will not be editable.\n        </p>\n        <h2 id=\"help_exporting_text\">\n            <img src=\"assets/icons/ic_format_size_black_24px.svg\">\n            Configuring Text\n        </h2>\n        <p>\n            The text configuration dropdown allows for the configuration of various\n            aspects of the text in the rendered layer.\n        </p>\n        <ul>\n            <li>\n                <b>Title font size</b> controls the font size of rendered layer title,\n                which is the same as the layer name. If the title or header are disabled this control\n                will not be editable.\n            </li>\n            <li>\n                <b>Font size in header</b> controls the size of the font size in\n                the table header: description, filters, score gradient, and legend.\n                If the header is disabled this control will not be editable.\n            </li>\n            <li>\n                <b>Tactic header font size</b> controls the font size of the tactic names\n                and technique count in the header of each tactic column.\n            </li>\n            <li>\n                <b>Technique font size</b> controls the size of the text in the technique\n                cells. If no text is displayed in the technique cells this control\n                will not be editable.\n            </li>\n            <li>\n                <b>Font size unit</b> controls whether the font-size controls are\n                measured in points (pt) or pixels (px).\n            </li>\n            <li>\n                <b>Font</b> controls the font used in the entire table. Options are given\n                for serif, sans-serif and monospace.\n            </li>\n            <li>\n                <b>Technique text</b> controls which text is shown in the technique\n                cells. Technique name or ID can be shown, or all text can be removed.\n            </li>\n        </ul>\n\n        <h2 id=\"help_exporting_legend_config\">\n            <img src=\"assets/icons/ic_view_list_black_24px.svg\">\n            Customizing the Legend\n        </h2>\n        <p>\n            This menu can only be opened if a <a href=\"#help_Legend\">legend</a> is present on the layer.\n            The checkbox allows you to undock the legend from the SVG header.\n            Once undocked, the X and Y position controls can be used to position\n            the legend in the image. The width and height inputs control\n            the size of the legend when it is undocked. The measurements are in units specified by the <a href=\"#help_exporting_units\">measurement units</a> control.\n        </p>\n\n        <h2 id=\"help_exporting_display_settings\">\n            <img src=\"assets/icons/ic_visibility_black_24px.svg\">\n            Display Settings\n        </h2>\n        <p>\n            The header itself, or specific parts of the header, can be hidden\n            using the controls in this dropdown. The color of table cell borders\n            can also be edited.\n        </p>\n        <ul>\n            <li>\n                <b>Show header</b> controls whether the header is shown at all. If\n                the legend is undocked from the header it will still be shown.\n            </li>\n            <li>\n                <b>Show title</b> controls whether the layer name is visible in\n                the header. If the layer has no title, the control will be disabled and the description section automatically hidden.\n            </li>\n            <li>\n                <b>Show description</b> controls whether the layer description is visible in\n                the header. If the layer has no description, the control will be disabled and the description section automatically hidden.\n            </li>\n            <li>\n                <b>Show filters</b> controls whether the current filters (selected stages and platforms) are visible in\n                the header. This control will be disabled if the header is hidden in entirety.\n            </li>\n            <li>\n                <b>Show score gradient</b> controls whether the score gradient is visible in the header.\n                If none of the techniques in the layer have a score, the control will be disabled and the score gradient section automatically hidden.\n            </li>\n            <li>\n                <b>Show Legend</b> controls whether the layer legend is visible.\n                If the layer has no defined legend items, the control will be disabled and the legend will be automatically hidden.\n            </li>\n            <li>\n                <b>Show technique count</b> controls whether the technique count is visible within the header of each tactic column. \n            </li>\n            <li>\n                <b>Cell border</b> controls the border of cells in the body of the table.\n                The borders in the header are not modified by this control.\n            </li>\n        </ul>\n\n        <h1 id=\"help_Rendering_Layers_As_XLSX\">\n            <img src=\"assets/icons/baseline-grid_on-24px.svg\">\n            Exporting layers to MS Excel\n        </h1>\n        <p>\n            Layers can be exported to MS excel (.xlsx) format. Clicking on the \"export to excel\" button in the toolbar will download an .xlsx\n            file which contains the current layer. This layer contains the annotations from the view --\n            color (via score or manually assigned) and disabled states. The exporter also honors tactic header background, sorting, filtering and hidden techniques.\n        </p>\n\n        <h1 id=\"notice\">Notice</h1>\n        <p>Copyright 2020 The MITRE Corporation</p>\n        <p>Approved for Public Release; Distribution Unlimited. Case Number 18-0128.</p>\n        <p>\n            Licensed under the Apache License, Version 2.0 (the \"License\"); you may not\n            use this file except in compliance with the License. You may obtain a copy\n            of the License at\n        </p>\n        <ul style=\"list-style: none\">\n            <li>http://www.apache.org/licenses/LICENSE-2.0</li>\n        </ul>\n\n        <p>\n            Unless required by applicable law or agreed to in writing, software\n            distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT\n            WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the\n            License for the specific language governing permissions and limitations\n            under the License.\n        </p>\n\n        <p>This project makes use of ATT&CK&reg;</p>\n        <a href=\"https://attack.mitre.org/resources/terms-of-use/\">ATT&CK&reg; Terms of Use</a>\n    </div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/tab/tab.component.html":
/*!******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/tab/tab.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [hidden]=\"!active\" class=\"pane\">\n    <ng-content></ng-content>\n    <ng-container *ngIf=\"template\" [ngTemplateOutlet]=\"template\"  [ngTemplateOutletContext]=\"{ data: dataContext, active: active }\"></ng-container>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/tabs/tabs.component.html":
/*!********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/tabs/tabs.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<link href=\"https://fonts.googleapis.com/css?family=Roboto+Mono:500\" rel=\"stylesheet\">\n<div *ngIf=\"configService.getFeature('header')\" [style.margin-bottom]=\"configService.getFeature('tabs') ? '0px' : '15px'\" class=\"header\" >\n    <div class=\"logo\">\n        <a href=\"http://attack.mitre.org\">MITRE ATT&CK&reg; Navigator</a>\n    </div>\n    <div *ngIf=\"configService.getFeature('tabs')\" class=\"helpButton\" matTooltip=\"help\" (click)=\"newHelpTab(forceNew=false)\">\n        ?\n    </div>\n</div>\n<div [style.margin-top]=\"configService.getFeature('header') ? '0px' : '15px'\" *ngIf=\"dynamicTabs.length > 0 && configService.getFeature('tabs')\">\n    <ul class=\"tabs\">\n        <!-- dynamic tabs (can be opened and closed) -->\n        <li *ngFor=\"let tab of dynamicTabs; let $i = index\" (click)=\"selectTab(tab)\" [class.active]=\"tab.active\">\n            <!-- <input *ngIf=\"tab.dataContext\" [disabled]=\"!tab.active\" [style.cursor]=\"tab.active ? 'text' : 'pointer'\" type=\"text\" [(ngModel)]=\"tab.dataContext.name\" [style.width]=\"tab.dataContext ? ((tab.dataContext.name.length) * 8.4) + 'px' : ''\"> -->\n            <!-- <a   *ngIf=\"!tab.dataContext\" href=\"#\" [style.cursor]=\"tab.active ? 'default' : 'pointer'\">{{tab.title}}</a> -->\n\n            <!-- <input [disabled]=\"!tab.active || !tab.dataContext\" (click)=\"!tab.active || !tab.dataContext ? selectTab(tab) : selectTab(tab)\" [style.cursor]=\"tab.active ? tab.dataContext ? 'text' : 'default' : 'pointer'\" type=\"text\" [(ngModel)]=\"tab.dataContext ? tab.dataContext.name : tab.title\" [style.width]=\"tab.dataContext ? ((tab.dataContext.name.length) * 8.4) + 'px' : (tab.title.length * 8.4) + 'px' \"> -->\n            <!-- <input [id]=\"'tabtitleinput' + $i\" (click)=\"!tab.active || !tab.dataContext ? selectTab(tab, 'tabtitleinput' + $i) : continue\" [style.cursor]=\"tab.active ? tab.dataContext ? 'text' : 'default' : 'pointer'\" type=\"text\" [(ngModel)]=\"tab.dataContext ? tab.dataContext.name : tab.title\" [style.width]=\"tab.dataContext ? ((tab.dataContext.name.length) * 8.4) + 'px' : (tab.title.length * 8.4) + 'px' \"> -->\n\n            <a *ngIf=\"!tab.active || !tab.isDataTable\" href=\"#\" [style.cursor]=\"tab.active ? 'default' : 'pointer'\">{{tab.isDataTable ? tab.dataContext.name : tab.title}}</a>\n            <input *ngIf=\"!(!tab.active || !tab.isDataTable)\" [style.cursor]=\"tab.active ? tab.isDataTable ? 'text' : 'default' : 'pointer'\" type=\"text\" [(ngModel)]=\"tab.dataContext.name\" [style.width]=\"tab.isDataTable ? ((tab.dataContext.name.length) * 8.4) + 'px' : (tab.title.length * 8.4) + 'px' \">\n            <span class=\"tab-close\" *ngIf=\"tab.isCloseable\" (click)=\"closeTab(tab)\">x</span>\n\n            <span class=\"tabEnumerator\" *ngIf=\"getActiveTab().showScoreVariables && tab.isDataTable && alphabetical(indexToChar($i))\">{{indexToChar($i)}}</span>\n        </li>\n        <!-- open new tab button -->\n        <!-- <li (click)=\"openTab('new tab', blankTab, null, true, false, true)\"> -->\n        <li *ngIf=\"dynamicTabs.length < 10\" class=\"addTab\" (click)=\"newBlankTab()\">\n            +\n        </li>\n    </ul>\n</div>\n<div *ngIf=\"dynamicTabs.length == 0\" class=\"newTab\">\n    <!-- you shouldn't ever see this, but just in case -->\n    <button (click)=\"newBlankTab()\">Start</button>\n</div>\n\n\n<div [style.margin-top]=\"configService.getFeature('tabs') || configService.getFeature('header') ? '0px' : '15px'\">\n    <ng-content></ng-content>\n</div>\n\n<ng-template dynamic-tabs #container></ng-template>\n\n\n<ng-template #blankTab>\n    <!-- <div style=\"background-color: #ddd; height: 3px;\">\n    </div> -->\n    <div class=\"newTab border\">\n        <mat-accordion class=\"headers-align\">\n            <mat-expansion-panel #newlayer hideToggle=\"true\" (click)=\"newLayer(); newlayer.close()\">\n                <mat-expansion-panel-header>\n                    <mat-panel-title>\n                        Create New Layer\n                    </mat-panel-title>\n                    <mat-panel-description>\n                        Create a new empty layer\n                    </mat-panel-description>\n\n                </mat-expansion-panel-header>\n                <!-- this content will never be shown because clicking opens a new layer tab -->\n            </mat-expansion-panel>\n\n            <!-- <mat-expansion-panel #uploadlayer hideToggle=\"true\" (click)=\"openUploadPrompt(); uploadlayer.close()\">\n                <mat-expansion-panel-header>\n                    <mat-panel-title>\n                        Upload Existing Layer\n                    </mat-panel-title>\n                    <mat-panel-description>\n                        Upload a layer from your computer\n                    </mat-panel-description>\n\n                </mat-expansion-panel-header>\n                <input id=\"uploader\" type=\"file\" style=\"display: none\" (change)=\"loadLayer()\"/>\n                <!-- this content will never be shown because clicking opens a new layer tab -->\n            <!--</mat-expansion-panel> -->\n\n            <mat-expansion-panel>\n                <mat-expansion-panel-header>\n                    <mat-panel-title>\n                    Open Existing Layer\n                    </mat-panel-title>\n                    <mat-panel-description>\n                        Load a layer from your computer or a URL\n                    </mat-panel-description>\n                </mat-expansion-panel-header>\n                <table class=\"inputTable\">\n                    <tr>\n                        <td><button mat-button (click)=\"openUploadPrompt()\">Upload from local</button>\n                        <input id=\"uploader\" type=\"file\" style=\"display: none\" (change)=\"loadLayerFromFile()\"/></td>\n\n                        <td><b style=\"font-size: 8pt\">OR</b></td>\n                        <td><mat-form-field>\n                            <input type=\"text\"\n                                   matInput\n                                   placeholder=\"Load from URL\"\n                                   [(ngModel)]=\"loadURL\"/>\n                            <button mat-button matSuffix mat-icon-button aria-label=\"go\" *ngIf=\"loadURL\" (click)=\"loadLayerFromURL(loadURL, true)\">></button>\n                        </mat-form-field></td>\n                    </tr>\n                </table>\n\n\n\n            </mat-expansion-panel>\n\n            <!-- <mat-expansion-panel [disabled]=\"viewModelsService.viewModels.length < 2\"> -->\n            <mat-expansion-panel (opened)=\"getActiveTab().showScoreVariables = true\" (closed)=\"getActiveTab().showScoreVariables = false\">\n                <mat-expansion-panel-header>\n                    <mat-panel-title>\n                        Create Layer from other layers\n                    </mat-panel-title>\n                    <mat-panel-description>\n                        Choose layers to inherit properties from\n                    </mat-panel-description>\n                </mat-expansion-panel-header>\n\n                <table class=\"layerOpTable\">\n                    <tr>\n                        <td>\n                            <mat-form-field>\n                                <input type=\"text\"\n                                       matInput\n                                       placeholder=\"score expression\"\n                                       [(ngModel)]=\"scoreExpression\"\n                                       (keyup)=\"scoreExpression = scoreExpression.toLowerCase()\"\n                                       style=\"letter-spacing: 2px\" />\n                                <mat-hint style=\"color: red\" align=\"start\">{{getScoreExpressionError()}}</mat-hint>\n                            </mat-form-field>\n                        </td>\n                        <td>\n                            Use constants (numbers) and layer variables (yellow, above) to write an expression for the initial value of scores in the new layer. A full list of supported operations can be found <a href=\"http://mathjs.org/docs/expressions/syntax.html#operators\">here</a>. Leave blank to initialize scores to 0.\n                        </td>\n                    </tr>\n                    <tr>\n                        <td>\n                            <mat-form-field>\n                                <mat-select placeholder=\"coloring\" [(ngModel)]=\"coloring\">\n                                    <mat-option [value]=\"null\">none</mat-option>\n                                    <mat-option *ngFor=\"let vm of viewModelsService.viewModels\" [value]=vm>{{vm.name}}</mat-option>\n                                </mat-select>\n                            </mat-form-field>\n                        </td>\n                        <td>\n                            Choose which layer to import manually assigned colors from. Leave blank to initialze with no colors.\n                        </td>\n                    </tr>\n                    <tr>\n                        <td>\n                            <mat-form-field>\n                                <mat-select placeholder=\"comments\" [(ngModel)]=\"comments\">\n                                    <mat-option [value]=\"null\">none</mat-option>\n                                    <mat-option *ngFor=\"let vm of viewModelsService.viewModels\" [value]=vm>{{vm.name}}</mat-option>\n                                </mat-select>\n                            </mat-form-field>\n                        </td>\n                        <td>\n                            Choose which layer to import comments from. Leave blank to initialize with no comments.\n                        </td>\n                    </tr>\n                    <tr>\n                        <td>\n                            <mat-form-field>\n                                <mat-select placeholder=\"states\" [(ngModel)]=\"enabledness\">\n                                    <mat-option [value]=\"null\">none</mat-option>\n                                    <mat-option *ngFor=\"let vm of viewModelsService.viewModels\" [value]=vm>{{vm.name}}</mat-option>\n                                </mat-select>\n                            </mat-form-field>\n                        </td>\n                        <td>\n                            Choose which layer to import enabled/disabled states from. Leave blank to initialize all to enabled.\n                        </td>\n                    </tr>\n                    <tr>\n                        <td>\n                            <mat-form-field>\n                                <mat-select placeholder=\"filters\" [(ngModel)]=\"filters\">\n                                    <mat-option [value]=\"null\">none</mat-option>\n                                    <mat-option *ngFor=\"let vm of viewModelsService.viewModels\" [value]=vm>{{vm.name}}</mat-option>\n                                </mat-select>\n                            </mat-form-field>\n                        </td>\n                        <td>\n                            Choose which layer to import filters - stages and platforms - from. Leave blank to initialize with no filters.\n                        </td>\n                    </tr>\n                    <tr>\n                        <td>\n                            <mat-form-field>\n                                <mat-select placeholder=\"legend\" [(ngModel)]=\"legendItems\">\n                                    <mat-option [value]=\"null\">none</mat-option>\n                                    <mat-option *ngFor=\"let vm of viewModelsService.viewModels\" [value]=vm>{{vm.name}}</mat-option>\n                                </mat-select>\n                            </mat-form-field>\n                        </td>\n                        <td>\n                            Choose which layer to import the legend from. Leave blank to initialize with an empty legend.\n                        </td>\n                    </tr>\n                </table>\n\n                <button mat-button [disabled]=\"getScoreExpressionError()\" (click)=\"layerByOperation(); showScoreVariables = false\">Create</button>\n\n            </mat-expansion-panel>\n\n            <mat-expansion-panel>\n                <mat-expansion-panel-header>\n                    <mat-panel-title>\n                        Create Customized Navigator\n                    </mat-panel-title>\n                    <mat-panel-description>\n                        Create a hyperlink to a customized ATT&CK Navigator\n                    </mat-panel-description>\n                </mat-expansion-panel-header>\n\n\n                <table class=\"inputTable\">\n                    <tr>\n                        <td><h1>Default Layers</h1></td>\n                        <td></td>\n                    </tr>\n                    <tr class=\"custom_nav_inputsection\">\n                        <td>\n                            <ul class=\"layerLinks\">\n                                <li *ngFor=\"let layerLinkURL of layerLinkURLs; let i = index\">\n                                    <mat-form-field>\n                                        <input type=\"text\"\n                                        matInput\n                                        [placeholder]=\"'default layer URL ' + (i + 1)\"\n                                        [(ngModel)]=\"layerLinkURLs[i]\"/>\n                                        <button mat-button matSuffix mat-icon-button aria-label=\"remove\" (click)=\"removeLayerLink(i)\">\n                                            x\n                                        </button>\n                                    </mat-form-field>\n                                </li>\n                                <li>\n                                    <button mat-button (click)=\"addLayerLink()\">\n                                        add {{layerLinkURLs.length > 0? \"another\" : \"a\"}} layer link\n                                    </button>\n                                </li>\n                            </ul>\n                        </td>\n                        <td>Enter the URLs of layers hosted on the web. The custom navigator will open these layers by default.</td>\n                    </tr>\n                    <tr>\n                        <td><h1>Navigator Features</h1></td>\n                        <td></td>\n                    </tr>\n                    <ng-template ngFor let-featureItem [ngForOf]=\"customizedConfig\" let-featureItemIndex=\"index\">\n                        <tr class=\"featureRow noselect\" *ngIf=\"!featureItem.subfeatures\"  (click)=\"featureItem.enabled = !featureItem.enabled\">\n                            <td class=\"featureRow-button\">\n                                <img height=\"16px\" [src]=\"featureItem.enabled ? 'assets/icons/ic_check_box_black_24px.svg' : 'assets/icons/ic_check_box_outline_blank_black_24px.svg'\"/> {{featureItem.name.split(\"_\").join(\" \")}}\n                            </td>\n                            <td>{{featureItem.description}}</td>\n\n                        </tr>\n                        <tr *ngIf=\"featureItem.subfeatures\">\n                            <td>\n                                <h2>{{featureItem.name.split(\"_\").join(\" \")}}</h2>\n                            </td>\n                            <td></td>\n                        </tr>\n                        <ng-template ngFor let-subfeature [ngForOf]=\"featureItem.subfeatures\" let-subfeatureIndex=\"index\" let-last=\"last\">\n                            <tr class=\"featureRow noselect\" (click)=\"subfeature.enabled = !subfeature.enabled\">\n                                <td class=\"featureRow-button subfeature\" [class.last]=\"last\" style=\"padding-left: 20px\" >\n                                    <img height=\"16px\" [src]=\"subfeature.enabled ? 'assets/icons/ic_check_box_black_24px.svg' : 'assets/icons/ic_check_box_outline_blank_black_24px.svg'\"/> {{subfeature.name.split(\"_\").join(\" \")}}\n                                </td>\n                                <td class=\"subfeature\" [class.last]=\"last\">{{subfeature.description}}</td>\n                            </tr>\n                        </ng-template>\n                    </ng-template>\n                </table>\n                <div style=\"text-align: center; margin-top: 20px\">\n                    <mat-form-field id=\"layerlinkfield\">\n                        <input id=\"layerLink\" type=\"text\"\n                        matInput\n                        readonly=\"readonly\"\n                        (click)=\"selectLayerLink()\"\n                        [value]=\"getLayerLink()\"\n                        placeholder=\"custom navigator URL\"/>\n                        <button (click)=\"copyLayerLink()\" mat-button matSuffix mat-icon-button aria-label=\"copy\"><img src=\"assets/icons/ic_content_copy_black_24px.svg\" width=\"14px\" alt=\"copy\" matTooltip=\"copy\" matTooltipPosition=\"right\"></button>\n                        <mat-hint *ngIf=\"copiedRecently\">copied</mat-hint>\n                    </mat-form-field>\n                </div>\n\n\n\n            </mat-expansion-panel>\n        </mat-accordion>\n\n        <div class=\"helpButtonContainer\">\n            <button mat-button (click)=\"newHelpTab(replace=false, forceNew=false)\">help</button>\n        </div>\n\n    </div>\n\n</ng-template>\n\n<ng-template #layerTab let-data=\"data\" let-active=\"active\">\n    <DataTable *ngIf=\"active\" [viewModel]=data></DataTable>\n</ng-template>\n\n<ng-template #helpTab>\n    <div class=\"border help\">\n        <help></help>\n    </div>\n\n</ng-template>\n\n<ng-template #exporterTab let-data=\"data\">\n    <div class=\"border\">\n        <exporter [exportData]=data></exporter>\n    </div>\n</ng-template>\n"

/***/ }),

/***/ "./node_modules/webpack/buildin/global.js":
/*!***********************************!*\
  !*** (webpack)/buildin/global.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || new Function("return this")();
} catch (e) {
	// This works if the window reference is available
	if (typeof window === "object") g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "tabs {\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif;\n  font-size: 9pt;\n}"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./data.service */ "./src/app/data.service.ts");
/* harmony import */ var _tabs_tabs_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tabs/tabs.component */ "./src/app/tabs/tabs.component.ts");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./globals */ "./src/app/globals.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

 //import the DataService component so we can use it


var AppComponent = /** @class */ (function () {
    /*
    @HostListener('window:beforeunload', ['$event'])
    promptNavAway($event) {
        //this text only shows in the data, not visible to user as far as I can tell
        //however, if it's not included the window doesn't open.
        $event.returnValue='Are you sure you want to navigate away? Your data may be lost!';
    }
    */
    function AppComponent(dataService) {
        this.dataService = dataService;
        this.nav_version = _globals__WEBPACK_IMPORTED_MODULE_3__["nav_version"];
        Array.prototype.includes = function (value) {
            // console.log("checking include")
            for (var i = 0; i < this.length; i++) {
                if (this[i] === value)
                    return true;
            }
            return false;
        };
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_tabs_tabs_component__WEBPACK_IMPORTED_MODULE_2__["TabsComponent"], { static: false }),
        __metadata("design:type", Object)
    ], AppComponent.prototype, "tabsComponent", void 0);
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
            providers: [_data_service__WEBPACK_IMPORTED_MODULE_1__["DataService"]] //add this provider to make sure we know we need DataService for this component
            ,
            styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
        }),
        __metadata("design:paramtypes", [_data_service__WEBPACK_IMPORTED_MODULE_1__["DataService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/esm5/input.es5.js");
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/select */ "./node_modules/@angular/material/esm5/select.es5.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/esm5/button.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/tooltip */ "./node_modules/@angular/material/esm5/tooltip.es5.js");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/menu */ "./node_modules/@angular/material/esm5/menu.es5.js");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/esm5/expansion.es5.js");
/* harmony import */ var ngx_color_picker__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-color-picker */ "./node_modules/ngx-color-picker/dist/ngx-color-picker.es5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _datatable_data_table_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./datatable/data-table.component */ "./src/app/datatable/data-table.component.ts");
/* harmony import */ var _tabs_tabs_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./tabs/tabs.component */ "./src/app/tabs/tabs.component.ts");
/* harmony import */ var _tabs_dynamic_tabs_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./tabs/dynamic-tabs.directive */ "./src/app/tabs/dynamic-tabs.directive.ts");
/* harmony import */ var _tab_tab_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./tab/tab.component */ "./src/app/tab/tab.component.ts");
/* harmony import */ var _help_help_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./help/help.component */ "./src/app/help/help.component.ts");
/* harmony import */ var _exporter_exporter_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./exporter/exporter.component */ "./src/app/exporter/exporter.component.ts");
/* harmony import */ var _datatable_technique_cell_technique_cell_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./datatable/technique-cell/technique-cell.component */ "./src/app/datatable/technique-cell/technique-cell.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



// material


















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_13__["AppComponent"],
                _datatable_data_table_component__WEBPACK_IMPORTED_MODULE_14__["DataTableComponent"],
                _tabs_tabs_component__WEBPACK_IMPORTED_MODULE_15__["TabsComponent"],
                _tab_tab_component__WEBPACK_IMPORTED_MODULE_17__["TabComponent"],
                _tabs_dynamic_tabs_directive__WEBPACK_IMPORTED_MODULE_16__["DynamicTabsDirective"],
                _help_help_component__WEBPACK_IMPORTED_MODULE_18__["HelpComponent"],
                _exporter_exporter_component__WEBPACK_IMPORTED_MODULE_19__["ExporterComponent"],
                _datatable_technique_cell_technique_cell_component__WEBPACK_IMPORTED_MODULE_20__["TechniqueCellComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClientModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__["BrowserAnimationsModule"],
                _angular_material_select__WEBPACK_IMPORTED_MODULE_5__["MatSelectModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ReactiveFormsModule"],
                _angular_material_input__WEBPACK_IMPORTED_MODULE_4__["MatInputModule"],
                _angular_material_button__WEBPACK_IMPORTED_MODULE_6__["MatButtonModule"],
                _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_8__["MatTooltipModule"],
                _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenuModule"],
                _angular_material_expansion__WEBPACK_IMPORTED_MODULE_10__["MatExpansionModule"],
                ngx_color_picker__WEBPACK_IMPORTED_MODULE_11__["ColorPickerModule"],
            ],
            exports: [
                _angular_material_select__WEBPACK_IMPORTED_MODULE_5__["MatSelectModule"],
                _angular_material_input__WEBPACK_IMPORTED_MODULE_4__["MatInputModule"],
                _angular_material_button__WEBPACK_IMPORTED_MODULE_6__["MatButtonModule"],
                _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_8__["MatTooltipModule"],
                _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__["MatMenuModule"],
                _angular_material_expansion__WEBPACK_IMPORTED_MODULE_10__["MatExpansionModule"],
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_13__["AppComponent"]],
            entryComponents: [_tab_tab_component__WEBPACK_IMPORTED_MODULE_17__["TabComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/config.service.ts":
/*!***********************************!*\
  !*** ./src/app/config.service.ts ***!
  \***********************************/
/*! exports provided: ConfigService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigService", function() { return ConfigService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./data.service */ "./src/app/data.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

 //import the DataService component so we can use it
var ConfigService = /** @class */ (function () {
    function ConfigService(dataService) {
        this.dataService = dataService;
        this.comment_color = "yellow";
        this.features = new Map();
        this.featureGroups = new Map();
        var self = this;
        dataService.getConfig().subscribe(function (config) {
            //parse feature preferences from config json
            config["features"].forEach(function (featureObject) {
                self.setFeature_object(featureObject);
            });
            //override json preferences with preferences from URL fragment
            self.getAllFragments().forEach(function (value, key) {
                var valueBool = (value == 'true');
                if (self.isFeature(key) || self.isFeatureGroup(key)) {
                    // console.log("setting feature", key, valueBool)
                    self.setFeature(key, valueBool);
                }
                // else {
                //     console.log(key, "is not a feature")
                // }
            });
            self.featureStructure = config["features"];
            self.comment_color = config["comment_color"];
        });
    }
    ConfigService.prototype.getFeatureList = function () {
        if (!this.featureStructure)
            return [];
        return this.featureStructure;
    };
    ConfigService.prototype.getFeature = function (featureName) {
        return this.features.get(featureName);
    };
    /**
     * Return true if any/all features in the group are enabled
     * @param  featureGroup feature group name
     * @param  type         'any' or 'all' for logical or/and
     * @return              true iffany/all are enabled, false otherwise
     */
    ConfigService.prototype.getFeatureGroup = function (featureGroup, type) {
        if (!this.featureGroups.has(featureGroup))
            return true;
        var subFeatures = this.featureGroups.get(featureGroup);
        var count = this.getFeatureGroupCount(featureGroup);
        return type == "any" ? count > 0 : count === subFeatures.length;
    };
    /**
     * Return the number of enabled features in the group
     * @param  featureGroup feature group name
     * @return              the number of enabled features in the group, or -1 if
     *                      the group does not exist
     */
    ConfigService.prototype.getFeatureGroupCount = function (featureGroup) {
        if (!this.featureGroups.has(featureGroup))
            return -1;
        var count = 0;
        var subFeatures = this.featureGroups.get(featureGroup);
        for (var i = 0; i < subFeatures.length; i++) {
            if (this.getFeature(subFeatures[i]))
                count += 1;
        }
        return count;
    };
    /**
     * Recursively search an object for boolean properties, set these as features
     * Take a key:value pair of an object. If the value is a boolean, set the
     * feature[key] to value. Otherwise recursively walk value to find boolean
     * options.
     *
     * Additionally, if the given feature grouping (where value is an obj)
     * has been previously defined, boolean properties assigned to the grouping
     * name will apply to all subfeatures of the grouping.
     *
     * @param  featureName string, the fieldname the value was found in
     * @param  value       boolean:object the value of the field. If a boolean,
     *                     sets feature[featureName] = value, otherwise walks recursively
     */
    ConfigService.prototype.setFeature = function (featureName, value) {
        var self = this;
        // console.log(featureName, value);
        if (typeof (value) == "boolean") { //base case
            if (this.featureGroups.has(featureName)) { //feature group, assign to all subfeatures
                this.featureGroups.get(featureName).forEach(function (subFeatureName) {
                    self.setFeature(subFeatureName, value);
                });
            }
            else { //single feature
                this.features.set(featureName, value);
            }
            return [featureName];
        }
        if (typeof (value) == "object") { //keep walking
            var subfeatures_1 = [];
            Object.keys(value).forEach(function (fieldname) {
                subfeatures_1 = Array.prototype.concat(subfeatures_1, self.setFeature(fieldname, value[fieldname]));
            });
            this.featureGroups.set(featureName, subfeatures_1);
            return subfeatures_1;
        }
    };
    /**
     * given a set of feature objects, set the enabledness of that object and all subobjects
     *
     * @param  featureObject {name: string, enabled: boolean, subfeatures?: featureObject[] }
     *                       Of enabled is false and it has subfeatures, they will all be forced to be false too
     * @param  override      Set all subfeatures, and their subfeatures, values to
     *                       this value
     */
    ConfigService.prototype.setFeature_object = function (featureObject, override) {
        if (override === void 0) { override = null; }
        var self = this;
        // base case
        if (!featureObject.hasOwnProperty("subfeatures")) {
            var enabled = override !== null ? override : featureObject.enabled;
            this.features.set(featureObject.name, enabled);
            return [featureObject.name];
        }
        else { //has subfeatures
            override = override ? override : !featureObject.enabled ? false : null;
            var subfeatures_2 = [];
            featureObject.subfeatures.forEach(function (subfeature) {
                subfeatures_2 = Array.prototype.concat(subfeatures_2, self.setFeature_object(subfeature, override));
            });
            this.featureGroups.set(featureObject.name, subfeatures_2);
            return subfeatures_2;
        }
    };
    /**
     * Return if the given string corresponds to a defined feature
     * @param  featureName the name of the feature
     * @return             true if the feature exists, false otherwise
     */
    ConfigService.prototype.isFeature = function (featureName) {
        return this.features.has(featureName);
    };
    /**
     * return if the given string corresponds to a defined feature group
     * @param  featureGroupName the name of the feature group
     * @return                  true if it is a feature group, false otherwise
     */
    ConfigService.prototype.isFeatureGroup = function (featureGroupName) {
        return this.featureGroups.has(featureGroupName);
    };
    ConfigService.prototype.getFeatureGroups = function () {
        var keys = [];
        this.featureGroups.forEach(function (value, key) { keys.push(key); });
        return keys;
    };
    ConfigService.prototype.getFeatures = function () {
        var keys = [];
        this.features.forEach(function (value, key) { keys.push(key); });
        return keys;
    };
    /**
     * Get all url fragments
     * @param  url optional, url to parse instead of window location href
     * @return     all fragments as key-value pairs
     */
    ConfigService.prototype.getAllFragments = function (url) {
        if (!url)
            url = window.location.href;
        var fragments = new Map();
        var regex = /[#&](\w+)=(\w+)/g;
        // let results = url.match(regex)
        var match;
        while (match = regex.exec(url)) {
            fragments.set(match[1], match[2]);
        }
        return fragments;
    };
    ConfigService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_data_service__WEBPACK_IMPORTED_MODULE_1__["DataService"]])
    ], ConfigService);
    return ConfigService;
}());



/***/ }),

/***/ "./src/app/data.service.ts":
/*!*********************************!*\
  !*** ./src/app/data.service.ts ***!
  \*********************************/
/*! exports provided: DataService, Technique */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataService", function() { return DataService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Technique", function() { return Technique; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_Rx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Rx */ "./node_modules/rxjs-compat/_esm5/Rx.js");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/observable/fromPromise */ "./node_modules/rxjs-compat/_esm5/observable/fromPromise.js");
/* harmony import */ var _taxii2lib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./taxii2lib */ "./src/app/taxii2lib.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


// import { Http } from '@angular/http'



var DataService = /** @class */ (function () {
    function DataService(http) {
        this.http = http;
        // Order of tactics to be displayed in application
        this.actTacticsOrder = [];
        this.prepareTacticsOrder = [];
        this.totalTacticsOrder = [];
        // URLs in case config file doesn't load properly
        this.enterpriseAttackURL = "assets/enterprise-attack.json";
        this.pre_attack_URL = "assets/pre-attack.json";
        this.mobileDataURL = "assets/mobile-attack.json";
        this.useTAXIIServer = false;
        this.taxiiURL = '';
        this.taxiiCollections = [];
    }
    DataService.prototype.setUpURLs = function (eAttackURL, preAttackURL, mURL, useTAXIIServer, taxiiURL, taxiiCollections) {
        this.enterpriseAttackURL = eAttackURL;
        this.pre_attack_URL = preAttackURL;
        this.mobileDataURL = mURL;
        this.useTAXIIServer = useTAXIIServer;
        this.taxiiURL = taxiiURL;
        this.taxiiCollections = taxiiCollections;
    };
    DataService.prototype.getConfig = function (refresh) {
        if (refresh === void 0) { refresh = false; }
        if (refresh || !this.configData$) {
            this.configData$ = this.http.get("./assets/config.json");
        }
        return this.configData$;
    };
    DataService.prototype.getEnterpriseData = function (refresh, useTAXIIServer) {
        if (refresh === void 0) { refresh = false; }
        if (useTAXIIServer === void 0) { useTAXIIServer = false; }
        if (useTAXIIServer) {
            console.log("fetching data from TAXII server");
            var conn = new _taxii2lib__WEBPACK_IMPORTED_MODULE_4__["TaxiiConnect"](this.taxiiURL, '', '', 5000);
            var enterpriseCollectionInfo = {
                'id': this.taxiiCollections['enterprise_attack'],
                'title': 'Enterprise ATT&CK',
                'description': '',
                'can_read': true,
                'can_write': false,
                'media_types': ['application/vnd.oasis.stix+json']
            };
            var enterpriseCollection = new _taxii2lib__WEBPACK_IMPORTED_MODULE_4__["Collection"](enterpriseCollectionInfo, this.taxiiURL + 'stix', conn);
            var preattackCollectionInfo = {
                'id': this.taxiiCollections['pre_attack'],
                'title': 'Pre-ATT&CK',
                'description': '',
                'can_read': true,
                'can_write': false,
                'media_types': ['application/vnd.oasis.stix+json']
            };
            var preattackCollection = new _taxii2lib__WEBPACK_IMPORTED_MODULE_4__["Collection"](preattackCollectionInfo, this.taxiiURL + 'stix', conn);
            this.enterpriseData$ = rxjs_Rx__WEBPACK_IMPORTED_MODULE_2__["Observable"].forkJoin(Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(enterpriseCollection.getObjects('', undefined)), Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(preattackCollection.getObjects('', undefined)));
        }
        else if (refresh || !this.enterpriseData$) {
            this.enterpriseData$ = rxjs_Rx__WEBPACK_IMPORTED_MODULE_2__["Observable"].forkJoin(this.http.get(this.enterpriseAttackURL), this.http.get(this.pre_attack_URL));
        }
        return this.enterpriseData$; //observable
    };
    DataService.prototype.getMobileData = function (refresh, useTAXIIServer) {
        if (refresh === void 0) { refresh = false; }
        if (useTAXIIServer === void 0) { useTAXIIServer = false; }
        //load from remote if not yet loaded or refresh=true
        if (useTAXIIServer) {
            console.log("fetching data from TAXII server");
            var conn = new _taxii2lib__WEBPACK_IMPORTED_MODULE_4__["TaxiiConnect"](this.taxiiURL, '', '', 5000);
            var mobileCollectionInfo = {
                'id': this.taxiiCollections['mobile_attack'],
                'title': 'Mobile ATT&CK',
                'description': '',
                'can_read': true,
                'can_write': false,
                'media_types': ['application/vnd.oasis.stix+json']
            };
            var mobileCollection = new _taxii2lib__WEBPACK_IMPORTED_MODULE_4__["Collection"](mobileCollectionInfo, this.taxiiURL + 'stix', conn);
            var preattackCollectionInfo = {
                'id': this.taxiiCollections['pre_attack'],
                'title': 'Pre-ATT&CK',
                'description': '',
                'can_read': true,
                'can_write': false,
                'media_types': ['application/vnd.oasis.stix+json']
            };
            var preattackCollection = new _taxii2lib__WEBPACK_IMPORTED_MODULE_4__["Collection"](preattackCollectionInfo, this.taxiiURL + 'stix', conn);
            this.mobileData$ = rxjs_Rx__WEBPACK_IMPORTED_MODULE_2__["Observable"].forkJoin(Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(mobileCollection.getObjects('', undefined)), Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(preattackCollection.getObjects('', undefined)));
        }
        else if (refresh || !this.mobileData$) {
            this.mobileData$ = rxjs_Rx__WEBPACK_IMPORTED_MODULE_2__["Observable"].forkJoin(this.http.get(this.mobileDataURL), this.http.get(this.pre_attack_URL));
        }
        return this.mobileData$; //observable
    };
    DataService.prototype.setTacticOrder = function (retrievedTactics) {
        // this.totalTacticsOrder = retrievedTactics;
        for (var i = 0; i < retrievedTactics.length; i++) {
            var phase = retrievedTactics[i].phase;
            var tactic = retrievedTactics[i].tactic;
            if (phase.localeCompare("prepare") === 0) {
                this.prepareTacticsOrder.push(tactic);
            }
            else {
                this.actTacticsOrder.push(tactic);
            }
            this.totalTacticsOrder.push(tactic);
        }
    };
    /**
     * Convert a list of techniques to a list of tactics, each one containing the techniques of the tactic
     * @param  {[object]} techniques the techniques to convert
     * @return {object}              object with keys of each tactic and values of the techniques of those tactics
     */
    DataService.prototype.techniquesToTactics = function (techniques) {
        if (techniques.length === 0)
            return [];
        var tactics = {};
        techniques.forEach(function (technique) {
            var tt = technique.tactic;
            if (tactics[tt])
                tactics[tt].push(technique);
            else
                tactics[tt] = [technique];
        });
        return tactics;
    };
    /**
     * Extract all tactic names from the list of techniques
     * @param  {[object]} techniques the techniques to extract
     * @return {[string]}            an array of all tactic names
     */
    DataService.prototype.tacticNames = function (techniques) {
        if (techniques.length === 0)
            return [];
        var techniquesFinal = [];
        var seen = new Set();
        techniques.forEach(function (technique) {
            var tt = technique.tactic;
            seen.add(tt);
        });
        for (var i = 0; i < this.totalTacticsOrder.length; i++) {
            var tactic = this.totalTacticsOrder[i];
            if (seen.has(tactic)) {
                techniquesFinal.push(tactic);
            }
        }
        return techniquesFinal;
    };
    DataService.prototype.saveFile = function (filename, json) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json', }),
            responseType: 'text'
        };
        this.http.post('layer/' + filename, json, httpOptions).subscribe(function (res) {
            if (res.error) {
                alert("Couldn't save file. Please store locally");
            }
            else
                alert("Saved successfully");
        });
    };
    DataService.prototype.deleteFile = function (filename) {
        this.http.delete('layer/' + filename, { responseType: 'text' }).subscribe(function (res) {
            if (res.error) {
                alert("Couldn't delete file. Please contact admin");
            }
            else
                alert("Deleted successfully");
        });
    };
    DataService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], DataService);
    return DataService;
}());

var Technique = /** @class */ (function () {
    function Technique(name, description, tactic, url, platforms, id, tid) {
        this.name = name;
        this.description = description, this.tactic = tactic;
        this.id = id;
        this.platforms = platforms;
        this.external_references_url = url;
        this.technique_id = tid;
        this.technique_tactic_union_id = this.technique_id + "^" + this.tactic;
    }
    return Technique;
}());



/***/ }),

/***/ "./src/app/datatable/data-table.component.scss":
/*!*****************************************************!*\
  !*** ./src/app/datatable/data-table.component.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n/* You can add global styles to this file, and also import other style files */\n.mat-badge-content{font-weight:600;font-size:12px;font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-badge-small .mat-badge-content{font-size:9px}\n.mat-badge-large .mat-badge-content{font-size:24px}\n.mat-h1,.mat-headline,.mat-typography h1{font:400 24px/32px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 16px}\n.mat-h2,.mat-title,.mat-typography h2{font:500 20px/32px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 16px}\n.mat-h3,.mat-subheading-2,.mat-typography h3{font:400 16px/28px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 16px}\n.mat-h4,.mat-subheading-1,.mat-typography h4{font:400 15px/24px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 16px}\n.mat-h5,.mat-typography h5{font:400 11.62px/20px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 12px}\n.mat-h6,.mat-typography h6{font:400 9.38px/20px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 12px}\n.mat-body-2,.mat-body-strong{font:500 14px/24px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-body,.mat-body-1,.mat-typography{font:400 14px/20px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-body p,.mat-body-1 p,.mat-typography p{margin:0 0 12px}\n.mat-caption,.mat-small{font:400 12px/20px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-display-4,.mat-typography .mat-display-4{font:300 112px/112px Roboto,\"Helvetica Neue\",sans-serif;letter-spacing:-.05em;margin:0 0 56px}\n.mat-display-3,.mat-typography .mat-display-3{font:400 56px/56px Roboto,\"Helvetica Neue\",sans-serif;letter-spacing:-.02em;margin:0 0 64px}\n.mat-display-2,.mat-typography .mat-display-2{font:400 45px/48px Roboto,\"Helvetica Neue\",sans-serif;letter-spacing:-.005em;margin:0 0 64px}\n.mat-display-1,.mat-typography .mat-display-1{font:400 34px/40px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 64px}\n.mat-bottom-sheet-container{font:400 14px/20px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-button,.mat-fab,.mat-flat-button,.mat-icon-button,.mat-mini-fab,.mat-raised-button,.mat-stroked-button{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:14px;font-weight:500}\n.mat-button-toggle{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-card{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-card-title{font-size:24px;font-weight:500}\n.mat-card-header .mat-card-title{font-size:20px}\n.mat-card-content,.mat-card-subtitle{font-size:14px}\n.mat-checkbox{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-checkbox-layout .mat-checkbox-label{line-height:24px}\n.mat-chip{font-size:14px;font-weight:500}\n.mat-chip .mat-chip-remove.mat-icon,.mat-chip .mat-chip-trailing-icon.mat-icon{font-size:18px}\n.mat-table{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-header-cell{font-size:12px;font-weight:500}\n.mat-cell,.mat-footer-cell{font-size:14px}\n.mat-calendar{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-calendar-body{font-size:13px}\n.mat-calendar-body-label,.mat-calendar-period-button{font-size:14px;font-weight:500}\n.mat-calendar-table-header th{font-size:11px;font-weight:400}\n.mat-dialog-title{font:500 20px/32px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-expansion-panel-header{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:15px;font-weight:400}\n.mat-expansion-panel-content{font:400 14px/20px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-form-field{font-size:inherit;font-weight:400;line-height:1.125;font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-form-field-wrapper{padding-bottom:1.34375em}\n.mat-form-field-prefix .mat-icon,.mat-form-field-suffix .mat-icon{font-size:150%;line-height:1.125}\n.mat-form-field-prefix .mat-icon-button,.mat-form-field-suffix .mat-icon-button{height:1.5em;width:1.5em}\n.mat-form-field-prefix .mat-icon-button .mat-icon,.mat-form-field-suffix .mat-icon-button .mat-icon{height:1.125em;line-height:1.125}\n.mat-form-field-infix{padding:.5em 0;border-top:.84375em solid transparent}\n.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{-webkit-transform:translateY(-1.34375em) scale(.75);transform:translateY(-1.34375em) scale(.75);width:133.33333%}\n.mat-form-field-can-float .mat-input-server[label]:not(:label-shown)+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.34374em) scale(.75);transform:translateY(-1.34374em) scale(.75);width:133.33334%}\n.mat-form-field-label-wrapper{top:-.84375em;padding-top:.84375em}\n.mat-form-field-label{top:1.34375em}\n.mat-form-field-underline{bottom:1.34375em}\n.mat-form-field-subscript-wrapper{font-size:75%;margin-top:.66667em;top:calc(100% - 1.79167em)}\n.mat-form-field-appearance-legacy .mat-form-field-wrapper{padding-bottom:1.25em}\n.mat-form-field-appearance-legacy .mat-form-field-infix{padding:.4375em 0}\n.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-appearance-legacy.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{-webkit-transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.001px);transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.001px);-ms-transform:translateY(-1.28125em) scale(.75);width:133.33333%}\n.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.00101px);transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.00101px);-ms-transform:translateY(-1.28124em) scale(.75);width:133.33334%}\n.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-input-server[label]:not(:label-shown)+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.00102px);transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.00102px);-ms-transform:translateY(-1.28123em) scale(.75);width:133.33335%}\n.mat-form-field-appearance-legacy .mat-form-field-label{top:1.28125em}\n.mat-form-field-appearance-legacy .mat-form-field-underline{bottom:1.25em}\n.mat-form-field-appearance-legacy .mat-form-field-subscript-wrapper{margin-top:.54167em;top:calc(100% - 1.66667em)}\n@media print{.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-appearance-legacy.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{-webkit-transform:translateY(-1.28122em) scale(.75);transform:translateY(-1.28122em) scale(.75)}.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.28121em) scale(.75);transform:translateY(-1.28121em) scale(.75)}.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-input-server[label]:not(:label-shown)+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.2812em) scale(.75);transform:translateY(-1.2812em) scale(.75)}}\n.mat-form-field-appearance-fill .mat-form-field-infix{padding:.25em 0 .75em 0}\n.mat-form-field-appearance-fill .mat-form-field-label{top:1.09375em;margin-top:-.5em}\n.mat-form-field-appearance-fill.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-appearance-fill.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{-webkit-transform:translateY(-.59375em) scale(.75);transform:translateY(-.59375em) scale(.75);width:133.33333%}\n.mat-form-field-appearance-fill.mat-form-field-can-float .mat-input-server[label]:not(:label-shown)+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-.59374em) scale(.75);transform:translateY(-.59374em) scale(.75);width:133.33334%}\n.mat-form-field-appearance-outline .mat-form-field-infix{padding:1em 0 1em 0}\n.mat-form-field-appearance-outline .mat-form-field-label{top:1.84375em;margin-top:-.25em}\n.mat-form-field-appearance-outline.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-appearance-outline.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{-webkit-transform:translateY(-1.59375em) scale(.75);transform:translateY(-1.59375em) scale(.75);width:133.33333%}\n.mat-form-field-appearance-outline.mat-form-field-can-float .mat-input-server[label]:not(:label-shown)+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.59374em) scale(.75);transform:translateY(-1.59374em) scale(.75);width:133.33334%}\n.mat-grid-tile-footer,.mat-grid-tile-header{font-size:14px}\n.mat-grid-tile-footer .mat-line,.mat-grid-tile-header .mat-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;box-sizing:border-box}\n.mat-grid-tile-footer .mat-line:nth-child(n+2),.mat-grid-tile-header .mat-line:nth-child(n+2){font-size:12px}\ninput.mat-input-element{margin-top:-.0625em}\n.mat-menu-item{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:14px;font-weight:400}\n.mat-paginator,.mat-paginator-page-size .mat-select-trigger{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:12px}\n.mat-radio-button{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-select{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-select-trigger{height:1.125em}\n.mat-slide-toggle-content{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-slider-thumb-label-text{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:12px;font-weight:500}\n.mat-stepper-horizontal,.mat-stepper-vertical{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-step-label{font-size:14px;font-weight:400}\n.mat-step-sub-label-error{font-weight:400}\n.mat-step-label-error{font-size:14px}\n.mat-step-label-selected{font-size:14px;font-weight:500}\n.mat-tab-group{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-tab-label,.mat-tab-link{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:14px;font-weight:500}\n.mat-toolbar,.mat-toolbar h1,.mat-toolbar h2,.mat-toolbar h3,.mat-toolbar h4,.mat-toolbar h5,.mat-toolbar h6{font:500 20px/32px Roboto,\"Helvetica Neue\",sans-serif;margin:0}\n.mat-tooltip{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:10px;padding-top:6px;padding-bottom:6px}\n.mat-tooltip-handset{font-size:14px;padding-top:8px;padding-bottom:8px}\n.mat-list-item{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-list-option{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-list-base .mat-list-item{font-size:16px}\n.mat-list-base .mat-list-item .mat-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;box-sizing:border-box}\n.mat-list-base .mat-list-item .mat-line:nth-child(n+2){font-size:14px}\n.mat-list-base .mat-list-option{font-size:16px}\n.mat-list-base .mat-list-option .mat-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;box-sizing:border-box}\n.mat-list-base .mat-list-option .mat-line:nth-child(n+2){font-size:14px}\n.mat-list-base .mat-subheader{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:14px;font-weight:500}\n.mat-list-base[dense] .mat-list-item{font-size:12px}\n.mat-list-base[dense] .mat-list-item .mat-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;box-sizing:border-box}\n.mat-list-base[dense] .mat-list-item .mat-line:nth-child(n+2){font-size:12px}\n.mat-list-base[dense] .mat-list-option{font-size:12px}\n.mat-list-base[dense] .mat-list-option .mat-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;box-sizing:border-box}\n.mat-list-base[dense] .mat-list-option .mat-line:nth-child(n+2){font-size:12px}\n.mat-list-base[dense] .mat-subheader{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:12px;font-weight:500}\n.mat-option{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:16px}\n.mat-optgroup-label{font:500 14px/24px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-simple-snackbar{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:14px}\n.mat-simple-snackbar-action{line-height:1;font-family:inherit;font-size:inherit;font-weight:500}\n.mat-tree{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-nested-tree-node,.mat-tree-node{font-weight:400;font-size:14px}\n.mat-ripple{overflow:hidden;position:relative}\n.mat-ripple.mat-ripple-unbounded{overflow:visible}\n.mat-ripple-element{position:absolute;border-radius:50%;pointer-events:none;transition:opacity,-webkit-transform 0s cubic-bezier(0,0,.2,1);transition:opacity,transform 0s cubic-bezier(0,0,.2,1);transition:opacity,transform 0s cubic-bezier(0,0,.2,1),-webkit-transform 0s cubic-bezier(0,0,.2,1);-webkit-transform:scale(0);transform:scale(0)}\n@media (-ms-high-contrast:active){.mat-ripple-element{display:none}}\n.cdk-visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;outline:0;-webkit-appearance:none;-moz-appearance:none}\n.cdk-global-overlay-wrapper,.cdk-overlay-container{pointer-events:none;top:0;left:0;height:100%;width:100%}\n.cdk-overlay-container{position:fixed;z-index:1000}\n.cdk-overlay-container:empty{display:none}\n.cdk-global-overlay-wrapper{display:flex;position:absolute;z-index:1000}\n.cdk-overlay-pane{position:absolute;pointer-events:auto;box-sizing:border-box;z-index:1000;display:flex;max-width:100%;max-height:100%}\n.cdk-overlay-backdrop{position:absolute;top:0;bottom:0;left:0;right:0;z-index:1000;pointer-events:auto;-webkit-tap-highlight-color:transparent;transition:opacity .4s cubic-bezier(.25,.8,.25,1);opacity:0}\n.cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:1}\n@media screen and (-ms-high-contrast:active){.cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.6}}\n.cdk-overlay-dark-backdrop{background:rgba(0,0,0,.32)}\n.cdk-overlay-transparent-backdrop,.cdk-overlay-transparent-backdrop.cdk-overlay-backdrop-showing{opacity:0}\n.cdk-overlay-connected-position-bounding-box{position:absolute;z-index:1000;display:flex;flex-direction:column;min-width:1px;min-height:1px}\n.cdk-global-scrollblock{position:fixed;width:100%;overflow-y:scroll}\n@-webkit-keyframes cdk-text-field-autofill-start{/*!*/}\n@keyframes cdk-text-field-autofill-start{/*!*/}\n@-webkit-keyframes cdk-text-field-autofill-end{/*!*/}\n@keyframes cdk-text-field-autofill-end{/*!*/}\n.cdk-text-field-autofill-monitored:-webkit-autofill{-webkit-animation-name:cdk-text-field-autofill-start;animation-name:cdk-text-field-autofill-start}\n.cdk-text-field-autofill-monitored:not(:-webkit-autofill){-webkit-animation-name:cdk-text-field-autofill-end;animation-name:cdk-text-field-autofill-end}\ntextarea.cdk-textarea-autosize{resize:none}\ntextarea.cdk-textarea-autosize-measuring{height:auto!important;overflow:hidden!important;padding:2px 0!important;box-sizing:content-box!important}\n.mat-ripple-element{background-color:rgba(0,0,0,.1)}\n.mat-option{color:rgba(0,0,0,.87)}\n.mat-option:focus:not(.mat-option-disabled),.mat-option:hover:not(.mat-option-disabled){background:rgba(0,0,0,.04)}\n.mat-option.mat-selected:not(.mat-option-multiple):not(.mat-option-disabled){background:rgba(0,0,0,.04)}\n.mat-option.mat-active{background:rgba(0,0,0,.04);color:rgba(0,0,0,.87)}\n.mat-option.mat-option-disabled{color:rgba(0,0,0,.38)}\n.mat-primary .mat-option.mat-selected:not(.mat-option-disabled){color:#3f51b5}\n.mat-accent .mat-option.mat-selected:not(.mat-option-disabled){color:#ff4081}\n.mat-warn .mat-option.mat-selected:not(.mat-option-disabled){color:#f44336}\n.mat-optgroup-label{color:rgba(0,0,0,.54)}\n.mat-optgroup-disabled .mat-optgroup-label{color:rgba(0,0,0,.38)}\n.mat-pseudo-checkbox{color:rgba(0,0,0,.54)}\n.mat-pseudo-checkbox::after{color:#fafafa}\n.mat-pseudo-checkbox-disabled{color:#b0b0b0}\n.mat-accent .mat-pseudo-checkbox-checked,.mat-accent .mat-pseudo-checkbox-indeterminate,.mat-pseudo-checkbox-checked,.mat-pseudo-checkbox-indeterminate{background:#ff4081}\n.mat-primary .mat-pseudo-checkbox-checked,.mat-primary .mat-pseudo-checkbox-indeterminate{background:#3f51b5}\n.mat-warn .mat-pseudo-checkbox-checked,.mat-warn .mat-pseudo-checkbox-indeterminate{background:#f44336}\n.mat-pseudo-checkbox-checked.mat-pseudo-checkbox-disabled,.mat-pseudo-checkbox-indeterminate.mat-pseudo-checkbox-disabled{background:#b0b0b0}\n.mat-elevation-z0{box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-elevation-z1{box-shadow:0 2px 1px -1px rgba(0,0,0,.2),0 1px 1px 0 rgba(0,0,0,.14),0 1px 3px 0 rgba(0,0,0,.12)}\n.mat-elevation-z2{box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}\n.mat-elevation-z3{box-shadow:0 3px 3px -2px rgba(0,0,0,.2),0 3px 4px 0 rgba(0,0,0,.14),0 1px 8px 0 rgba(0,0,0,.12)}\n.mat-elevation-z4{box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12)}\n.mat-elevation-z5{box-shadow:0 3px 5px -1px rgba(0,0,0,.2),0 5px 8px 0 rgba(0,0,0,.14),0 1px 14px 0 rgba(0,0,0,.12)}\n.mat-elevation-z6{box-shadow:0 3px 5px -1px rgba(0,0,0,.2),0 6px 10px 0 rgba(0,0,0,.14),0 1px 18px 0 rgba(0,0,0,.12)}\n.mat-elevation-z7{box-shadow:0 4px 5px -2px rgba(0,0,0,.2),0 7px 10px 1px rgba(0,0,0,.14),0 2px 16px 1px rgba(0,0,0,.12)}\n.mat-elevation-z8{box-shadow:0 5px 5px -3px rgba(0,0,0,.2),0 8px 10px 1px rgba(0,0,0,.14),0 3px 14px 2px rgba(0,0,0,.12)}\n.mat-elevation-z9{box-shadow:0 5px 6px -3px rgba(0,0,0,.2),0 9px 12px 1px rgba(0,0,0,.14),0 3px 16px 2px rgba(0,0,0,.12)}\n.mat-elevation-z10{box-shadow:0 6px 6px -3px rgba(0,0,0,.2),0 10px 14px 1px rgba(0,0,0,.14),0 4px 18px 3px rgba(0,0,0,.12)}\n.mat-elevation-z11{box-shadow:0 6px 7px -4px rgba(0,0,0,.2),0 11px 15px 1px rgba(0,0,0,.14),0 4px 20px 3px rgba(0,0,0,.12)}\n.mat-elevation-z12{box-shadow:0 7px 8px -4px rgba(0,0,0,.2),0 12px 17px 2px rgba(0,0,0,.14),0 5px 22px 4px rgba(0,0,0,.12)}\n.mat-elevation-z13{box-shadow:0 7px 8px -4px rgba(0,0,0,.2),0 13px 19px 2px rgba(0,0,0,.14),0 5px 24px 4px rgba(0,0,0,.12)}\n.mat-elevation-z14{box-shadow:0 7px 9px -4px rgba(0,0,0,.2),0 14px 21px 2px rgba(0,0,0,.14),0 5px 26px 4px rgba(0,0,0,.12)}\n.mat-elevation-z15{box-shadow:0 8px 9px -5px rgba(0,0,0,.2),0 15px 22px 2px rgba(0,0,0,.14),0 6px 28px 5px rgba(0,0,0,.12)}\n.mat-elevation-z16{box-shadow:0 8px 10px -5px rgba(0,0,0,.2),0 16px 24px 2px rgba(0,0,0,.14),0 6px 30px 5px rgba(0,0,0,.12)}\n.mat-elevation-z17{box-shadow:0 8px 11px -5px rgba(0,0,0,.2),0 17px 26px 2px rgba(0,0,0,.14),0 6px 32px 5px rgba(0,0,0,.12)}\n.mat-elevation-z18{box-shadow:0 9px 11px -5px rgba(0,0,0,.2),0 18px 28px 2px rgba(0,0,0,.14),0 7px 34px 6px rgba(0,0,0,.12)}\n.mat-elevation-z19{box-shadow:0 9px 12px -6px rgba(0,0,0,.2),0 19px 29px 2px rgba(0,0,0,.14),0 7px 36px 6px rgba(0,0,0,.12)}\n.mat-elevation-z20{box-shadow:0 10px 13px -6px rgba(0,0,0,.2),0 20px 31px 3px rgba(0,0,0,.14),0 8px 38px 7px rgba(0,0,0,.12)}\n.mat-elevation-z21{box-shadow:0 10px 13px -6px rgba(0,0,0,.2),0 21px 33px 3px rgba(0,0,0,.14),0 8px 40px 7px rgba(0,0,0,.12)}\n.mat-elevation-z22{box-shadow:0 10px 14px -6px rgba(0,0,0,.2),0 22px 35px 3px rgba(0,0,0,.14),0 8px 42px 7px rgba(0,0,0,.12)}\n.mat-elevation-z23{box-shadow:0 11px 14px -7px rgba(0,0,0,.2),0 23px 36px 3px rgba(0,0,0,.14),0 9px 44px 8px rgba(0,0,0,.12)}\n.mat-elevation-z24{box-shadow:0 11px 15px -7px rgba(0,0,0,.2),0 24px 38px 3px rgba(0,0,0,.14),0 9px 46px 8px rgba(0,0,0,.12)}\n.mat-app-background{background-color:#fafafa;color:rgba(0,0,0,.87)}\n.mat-theme-loaded-marker{display:none}\n.mat-autocomplete-panel{background:#fff;color:rgba(0,0,0,.87)}\n.mat-autocomplete-panel:not([class*=mat-elevation-z]){box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12)}\n.mat-autocomplete-panel .mat-option.mat-selected:not(.mat-active):not(:hover){background:#fff}\n.mat-autocomplete-panel .mat-option.mat-selected:not(.mat-active):not(:hover):not(.mat-option-disabled){color:rgba(0,0,0,.87)}\n.mat-badge-content{color:#fff;background:#3f51b5}\n@media (-ms-high-contrast:active){.mat-badge-content{outline:solid 1px;border-radius:0}}\n.mat-badge-accent .mat-badge-content{background:#ff4081;color:#fff}\n.mat-badge-warn .mat-badge-content{color:#fff;background:#f44336}\n.mat-badge{position:relative}\n.mat-badge-hidden .mat-badge-content{display:none}\n.mat-badge-disabled .mat-badge-content{background:#b9b9b9;color:rgba(0,0,0,.38)}\n.mat-badge-content{position:absolute;text-align:center;display:inline-block;border-radius:50%;transition:-webkit-transform .2s ease-in-out;transition:transform .2s ease-in-out;transition:transform .2s ease-in-out, -webkit-transform .2s ease-in-out;-webkit-transform:scale(.6);transform:scale(.6);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;pointer-events:none}\n.mat-badge-content._mat-animation-noopable,.ng-animate-disabled .mat-badge-content{transition:none}\n.mat-badge-content.mat-badge-active{-webkit-transform:none;transform:none}\n.mat-badge-small .mat-badge-content{width:16px;height:16px;line-height:16px}\n.mat-badge-small.mat-badge-above .mat-badge-content{top:-8px}\n.mat-badge-small.mat-badge-below .mat-badge-content{bottom:-8px}\n.mat-badge-small.mat-badge-before .mat-badge-content{left:-16px}\n[dir=rtl] .mat-badge-small.mat-badge-before .mat-badge-content{left:auto;right:-16px}\n.mat-badge-small.mat-badge-after .mat-badge-content{right:-16px}\n[dir=rtl] .mat-badge-small.mat-badge-after .mat-badge-content{right:auto;left:-16px}\n.mat-badge-small.mat-badge-overlap.mat-badge-before .mat-badge-content{left:-8px}\n[dir=rtl] .mat-badge-small.mat-badge-overlap.mat-badge-before .mat-badge-content{left:auto;right:-8px}\n.mat-badge-small.mat-badge-overlap.mat-badge-after .mat-badge-content{right:-8px}\n[dir=rtl] .mat-badge-small.mat-badge-overlap.mat-badge-after .mat-badge-content{right:auto;left:-8px}\n.mat-badge-medium .mat-badge-content{width:22px;height:22px;line-height:22px}\n.mat-badge-medium.mat-badge-above .mat-badge-content{top:-11px}\n.mat-badge-medium.mat-badge-below .mat-badge-content{bottom:-11px}\n.mat-badge-medium.mat-badge-before .mat-badge-content{left:-22px}\n[dir=rtl] .mat-badge-medium.mat-badge-before .mat-badge-content{left:auto;right:-22px}\n.mat-badge-medium.mat-badge-after .mat-badge-content{right:-22px}\n[dir=rtl] .mat-badge-medium.mat-badge-after .mat-badge-content{right:auto;left:-22px}\n.mat-badge-medium.mat-badge-overlap.mat-badge-before .mat-badge-content{left:-11px}\n[dir=rtl] .mat-badge-medium.mat-badge-overlap.mat-badge-before .mat-badge-content{left:auto;right:-11px}\n.mat-badge-medium.mat-badge-overlap.mat-badge-after .mat-badge-content{right:-11px}\n[dir=rtl] .mat-badge-medium.mat-badge-overlap.mat-badge-after .mat-badge-content{right:auto;left:-11px}\n.mat-badge-large .mat-badge-content{width:28px;height:28px;line-height:28px}\n.mat-badge-large.mat-badge-above .mat-badge-content{top:-14px}\n.mat-badge-large.mat-badge-below .mat-badge-content{bottom:-14px}\n.mat-badge-large.mat-badge-before .mat-badge-content{left:-28px}\n[dir=rtl] .mat-badge-large.mat-badge-before .mat-badge-content{left:auto;right:-28px}\n.mat-badge-large.mat-badge-after .mat-badge-content{right:-28px}\n[dir=rtl] .mat-badge-large.mat-badge-after .mat-badge-content{right:auto;left:-28px}\n.mat-badge-large.mat-badge-overlap.mat-badge-before .mat-badge-content{left:-14px}\n[dir=rtl] .mat-badge-large.mat-badge-overlap.mat-badge-before .mat-badge-content{left:auto;right:-14px}\n.mat-badge-large.mat-badge-overlap.mat-badge-after .mat-badge-content{right:-14px}\n[dir=rtl] .mat-badge-large.mat-badge-overlap.mat-badge-after .mat-badge-content{right:auto;left:-14px}\n.mat-bottom-sheet-container{box-shadow:0 8px 10px -5px rgba(0,0,0,.2),0 16px 24px 2px rgba(0,0,0,.14),0 6px 30px 5px rgba(0,0,0,.12);background:#fff;color:rgba(0,0,0,.87)}\n.mat-button,.mat-icon-button,.mat-stroked-button{color:inherit;background:0 0}\n.mat-button.mat-primary,.mat-icon-button.mat-primary,.mat-stroked-button.mat-primary{color:#3f51b5}\n.mat-button.mat-accent,.mat-icon-button.mat-accent,.mat-stroked-button.mat-accent{color:#ff4081}\n.mat-button.mat-warn,.mat-icon-button.mat-warn,.mat-stroked-button.mat-warn{color:#f44336}\n.mat-button.mat-accent[disabled],.mat-button.mat-primary[disabled],.mat-button.mat-warn[disabled],.mat-button[disabled][disabled],.mat-icon-button.mat-accent[disabled],.mat-icon-button.mat-primary[disabled],.mat-icon-button.mat-warn[disabled],.mat-icon-button[disabled][disabled],.mat-stroked-button.mat-accent[disabled],.mat-stroked-button.mat-primary[disabled],.mat-stroked-button.mat-warn[disabled],.mat-stroked-button[disabled][disabled]{color:rgba(0,0,0,.26)}\n.mat-button.mat-primary .mat-button-focus-overlay,.mat-icon-button.mat-primary .mat-button-focus-overlay,.mat-stroked-button.mat-primary .mat-button-focus-overlay{background-color:#3f51b5}\n.mat-button.mat-accent .mat-button-focus-overlay,.mat-icon-button.mat-accent .mat-button-focus-overlay,.mat-stroked-button.mat-accent .mat-button-focus-overlay{background-color:#ff4081}\n.mat-button.mat-warn .mat-button-focus-overlay,.mat-icon-button.mat-warn .mat-button-focus-overlay,.mat-stroked-button.mat-warn .mat-button-focus-overlay{background-color:#f44336}\n.mat-button[disabled] .mat-button-focus-overlay,.mat-icon-button[disabled] .mat-button-focus-overlay,.mat-stroked-button[disabled] .mat-button-focus-overlay{background-color:transparent}\n.mat-button .mat-ripple-element,.mat-icon-button .mat-ripple-element,.mat-stroked-button .mat-ripple-element{opacity:.1;background-color:currentColor}\n.mat-button-focus-overlay{background:#000}\n.mat-stroked-button:not([disabled]){border-color:rgba(0,0,0,.12)}\n.mat-fab,.mat-flat-button,.mat-mini-fab,.mat-raised-button{color:rgba(0,0,0,.87);background-color:#fff}\n.mat-fab.mat-primary,.mat-flat-button.mat-primary,.mat-mini-fab.mat-primary,.mat-raised-button.mat-primary{color:#fff}\n.mat-fab.mat-accent,.mat-flat-button.mat-accent,.mat-mini-fab.mat-accent,.mat-raised-button.mat-accent{color:#fff}\n.mat-fab.mat-warn,.mat-flat-button.mat-warn,.mat-mini-fab.mat-warn,.mat-raised-button.mat-warn{color:#fff}\n.mat-fab.mat-accent[disabled],.mat-fab.mat-primary[disabled],.mat-fab.mat-warn[disabled],.mat-fab[disabled][disabled],.mat-flat-button.mat-accent[disabled],.mat-flat-button.mat-primary[disabled],.mat-flat-button.mat-warn[disabled],.mat-flat-button[disabled][disabled],.mat-mini-fab.mat-accent[disabled],.mat-mini-fab.mat-primary[disabled],.mat-mini-fab.mat-warn[disabled],.mat-mini-fab[disabled][disabled],.mat-raised-button.mat-accent[disabled],.mat-raised-button.mat-primary[disabled],.mat-raised-button.mat-warn[disabled],.mat-raised-button[disabled][disabled]{color:rgba(0,0,0,.26)}\n.mat-fab.mat-primary,.mat-flat-button.mat-primary,.mat-mini-fab.mat-primary,.mat-raised-button.mat-primary{background-color:#3f51b5}\n.mat-fab.mat-accent,.mat-flat-button.mat-accent,.mat-mini-fab.mat-accent,.mat-raised-button.mat-accent{background-color:#ff4081}\n.mat-fab.mat-warn,.mat-flat-button.mat-warn,.mat-mini-fab.mat-warn,.mat-raised-button.mat-warn{background-color:#f44336}\n.mat-fab.mat-accent[disabled],.mat-fab.mat-primary[disabled],.mat-fab.mat-warn[disabled],.mat-fab[disabled][disabled],.mat-flat-button.mat-accent[disabled],.mat-flat-button.mat-primary[disabled],.mat-flat-button.mat-warn[disabled],.mat-flat-button[disabled][disabled],.mat-mini-fab.mat-accent[disabled],.mat-mini-fab.mat-primary[disabled],.mat-mini-fab.mat-warn[disabled],.mat-mini-fab[disabled][disabled],.mat-raised-button.mat-accent[disabled],.mat-raised-button.mat-primary[disabled],.mat-raised-button.mat-warn[disabled],.mat-raised-button[disabled][disabled]{background-color:rgba(0,0,0,.12)}\n.mat-fab.mat-primary .mat-ripple-element,.mat-flat-button.mat-primary .mat-ripple-element,.mat-mini-fab.mat-primary .mat-ripple-element,.mat-raised-button.mat-primary .mat-ripple-element{background-color:rgba(255,255,255,.1)}\n.mat-fab.mat-accent .mat-ripple-element,.mat-flat-button.mat-accent .mat-ripple-element,.mat-mini-fab.mat-accent .mat-ripple-element,.mat-raised-button.mat-accent .mat-ripple-element{background-color:rgba(255,255,255,.1)}\n.mat-fab.mat-warn .mat-ripple-element,.mat-flat-button.mat-warn .mat-ripple-element,.mat-mini-fab.mat-warn .mat-ripple-element,.mat-raised-button.mat-warn .mat-ripple-element{background-color:rgba(255,255,255,.1)}\n.mat-flat-button:not([class*=mat-elevation-z]),.mat-stroked-button:not([class*=mat-elevation-z]){box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-raised-button:not([class*=mat-elevation-z]){box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}\n.mat-raised-button:not([disabled]):active:not([class*=mat-elevation-z]){box-shadow:0 5px 5px -3px rgba(0,0,0,.2),0 8px 10px 1px rgba(0,0,0,.14),0 3px 14px 2px rgba(0,0,0,.12)}\n.mat-raised-button[disabled]:not([class*=mat-elevation-z]){box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-fab:not([class*=mat-elevation-z]),.mat-mini-fab:not([class*=mat-elevation-z]){box-shadow:0 3px 5px -1px rgba(0,0,0,.2),0 6px 10px 0 rgba(0,0,0,.14),0 1px 18px 0 rgba(0,0,0,.12)}\n.mat-fab:not([disabled]):active:not([class*=mat-elevation-z]),.mat-mini-fab:not([disabled]):active:not([class*=mat-elevation-z]){box-shadow:0 7px 8px -4px rgba(0,0,0,.2),0 12px 17px 2px rgba(0,0,0,.14),0 5px 22px 4px rgba(0,0,0,.12)}\n.mat-fab[disabled]:not([class*=mat-elevation-z]),.mat-mini-fab[disabled]:not([class*=mat-elevation-z]){box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-button-toggle-group,.mat-button-toggle-standalone{box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}\n.mat-button-toggle-group-appearance-standard,.mat-button-toggle-standalone.mat-button-toggle-appearance-standard{box-shadow:none}\n.mat-button-toggle{color:rgba(0,0,0,.38)}\n.mat-button-toggle .mat-button-toggle-focus-overlay{background-color:rgba(0,0,0,.12)}\n.mat-button-toggle-appearance-standard{color:rgba(0,0,0,.87);background:#fff}\n.mat-button-toggle-appearance-standard .mat-button-toggle-focus-overlay{background-color:#000}\n.mat-button-toggle-group-appearance-standard .mat-button-toggle+.mat-button-toggle{border-left:solid 1px rgba(0,0,0,.12)}\n[dir=rtl] .mat-button-toggle-group-appearance-standard .mat-button-toggle+.mat-button-toggle{border-left:none;border-right:solid 1px rgba(0,0,0,.12)}\n.mat-button-toggle-group-appearance-standard.mat-button-toggle-vertical .mat-button-toggle+.mat-button-toggle{border-left:none;border-right:none;border-top:solid 1px rgba(0,0,0,.12)}\n.mat-button-toggle-checked{background-color:#e0e0e0;color:rgba(0,0,0,.54)}\n.mat-button-toggle-checked.mat-button-toggle-appearance-standard{color:rgba(0,0,0,.87)}\n.mat-button-toggle-disabled{color:rgba(0,0,0,.26);background-color:#eee}\n.mat-button-toggle-disabled.mat-button-toggle-appearance-standard{background:#fff}\n.mat-button-toggle-disabled.mat-button-toggle-checked{background-color:#bdbdbd}\n.mat-button-toggle-group-appearance-standard,.mat-button-toggle-standalone.mat-button-toggle-appearance-standard{border:solid 1px rgba(0,0,0,.12)}\n.mat-card{background:#fff;color:rgba(0,0,0,.87)}\n.mat-card:not([class*=mat-elevation-z]){box-shadow:0 2px 1px -1px rgba(0,0,0,.2),0 1px 1px 0 rgba(0,0,0,.14),0 1px 3px 0 rgba(0,0,0,.12)}\n.mat-card.mat-card-flat:not([class*=mat-elevation-z]){box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-card-subtitle{color:rgba(0,0,0,.54)}\n.mat-checkbox-frame{border-color:rgba(0,0,0,.54)}\n.mat-checkbox-checkmark{fill:#fafafa}\n.mat-checkbox-checkmark-path{stroke:#fafafa!important}\n@media (-ms-high-contrast:black-on-white){.mat-checkbox-checkmark-path{stroke:#000!important}}\n.mat-checkbox-mixedmark{background-color:#fafafa}\n.mat-checkbox-checked.mat-primary .mat-checkbox-background,.mat-checkbox-indeterminate.mat-primary .mat-checkbox-background{background-color:#3f51b5}\n.mat-checkbox-checked.mat-accent .mat-checkbox-background,.mat-checkbox-indeterminate.mat-accent .mat-checkbox-background{background-color:#ff4081}\n.mat-checkbox-checked.mat-warn .mat-checkbox-background,.mat-checkbox-indeterminate.mat-warn .mat-checkbox-background{background-color:#f44336}\n.mat-checkbox-disabled.mat-checkbox-checked .mat-checkbox-background,.mat-checkbox-disabled.mat-checkbox-indeterminate .mat-checkbox-background{background-color:#b0b0b0}\n.mat-checkbox-disabled:not(.mat-checkbox-checked) .mat-checkbox-frame{border-color:#b0b0b0}\n.mat-checkbox-disabled .mat-checkbox-label{color:rgba(0,0,0,.54)}\n@media (-ms-high-contrast:active){.mat-checkbox-disabled{opacity:.5}}\n@media (-ms-high-contrast:active){.mat-checkbox-background{background:0 0}}\n.mat-checkbox .mat-ripple-element{background-color:#000}\n.mat-checkbox-checked:not(.mat-checkbox-disabled).mat-primary .mat-ripple-element,.mat-checkbox:active:not(.mat-checkbox-disabled).mat-primary .mat-ripple-element{background:#3f51b5}\n.mat-checkbox-checked:not(.mat-checkbox-disabled).mat-accent .mat-ripple-element,.mat-checkbox:active:not(.mat-checkbox-disabled).mat-accent .mat-ripple-element{background:#ff4081}\n.mat-checkbox-checked:not(.mat-checkbox-disabled).mat-warn .mat-ripple-element,.mat-checkbox:active:not(.mat-checkbox-disabled).mat-warn .mat-ripple-element{background:#f44336}\n.mat-chip.mat-standard-chip{background-color:#e0e0e0;color:rgba(0,0,0,.87)}\n.mat-chip.mat-standard-chip .mat-chip-remove{color:rgba(0,0,0,.87);opacity:.4}\n.mat-chip.mat-standard-chip:not(.mat-chip-disabled):active{box-shadow:0 3px 3px -2px rgba(0,0,0,.2),0 3px 4px 0 rgba(0,0,0,.14),0 1px 8px 0 rgba(0,0,0,.12)}\n.mat-chip.mat-standard-chip:not(.mat-chip-disabled) .mat-chip-remove:hover{opacity:.54}\n.mat-chip.mat-standard-chip.mat-chip-disabled{opacity:.4}\n.mat-chip.mat-standard-chip::after{background:#000}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-primary{background-color:#3f51b5;color:#fff}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-primary .mat-chip-remove{color:#fff;opacity:.4}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-primary .mat-ripple-element{background:rgba(255,255,255,.1)}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-warn{background-color:#f44336;color:#fff}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-warn .mat-chip-remove{color:#fff;opacity:.4}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-warn .mat-ripple-element{background:rgba(255,255,255,.1)}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-accent{background-color:#ff4081;color:#fff}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-accent .mat-chip-remove{color:#fff;opacity:.4}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-accent .mat-ripple-element{background:rgba(255,255,255,.1)}\n.mat-table{background:#fff}\n.mat-table tbody,.mat-table tfoot,.mat-table thead,.mat-table-sticky,[mat-footer-row],[mat-header-row],[mat-row],mat-footer-row,mat-header-row,mat-row{background:inherit}\nmat-footer-row,mat-header-row,mat-row,td.mat-cell,td.mat-footer-cell,th.mat-header-cell{border-bottom-color:rgba(0,0,0,.12)}\n.mat-header-cell{color:rgba(0,0,0,.54)}\n.mat-cell,.mat-footer-cell{color:rgba(0,0,0,.87)}\n.mat-calendar-arrow{border-top-color:rgba(0,0,0,.54)}\n.mat-datepicker-content .mat-calendar-next-button,.mat-datepicker-content .mat-calendar-previous-button,.mat-datepicker-toggle{color:rgba(0,0,0,.54)}\n.mat-calendar-table-header{color:rgba(0,0,0,.38)}\n.mat-calendar-table-header-divider::after{background:rgba(0,0,0,.12)}\n.mat-calendar-body-label{color:rgba(0,0,0,.54)}\n.mat-calendar-body-cell-content{color:rgba(0,0,0,.87);border-color:transparent}\n.mat-calendar-body-disabled>.mat-calendar-body-cell-content:not(.mat-calendar-body-selected){color:rgba(0,0,0,.38)}\n.cdk-keyboard-focused .mat-calendar-body-active>.mat-calendar-body-cell-content:not(.mat-calendar-body-selected),.cdk-program-focused .mat-calendar-body-active>.mat-calendar-body-cell-content:not(.mat-calendar-body-selected),.mat-calendar-body-cell:not(.mat-calendar-body-disabled):hover>.mat-calendar-body-cell-content:not(.mat-calendar-body-selected){background-color:rgba(0,0,0,.04)}\n.mat-calendar-body-today:not(.mat-calendar-body-selected){border-color:rgba(0,0,0,.38)}\n.mat-calendar-body-disabled>.mat-calendar-body-today:not(.mat-calendar-body-selected){border-color:rgba(0,0,0,.18)}\n.mat-calendar-body-selected{background-color:#3f51b5;color:#fff}\n.mat-calendar-body-disabled>.mat-calendar-body-selected{background-color:rgba(63,81,181,.4)}\n.mat-calendar-body-today.mat-calendar-body-selected{box-shadow:inset 0 0 0 1px #fff}\n.mat-datepicker-content{box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12);background-color:#fff;color:rgba(0,0,0,.87)}\n.mat-datepicker-content.mat-accent .mat-calendar-body-selected{background-color:#ff4081;color:#fff}\n.mat-datepicker-content.mat-accent .mat-calendar-body-disabled>.mat-calendar-body-selected{background-color:rgba(255,64,129,.4)}\n.mat-datepicker-content.mat-accent .mat-calendar-body-today.mat-calendar-body-selected{box-shadow:inset 0 0 0 1px #fff}\n.mat-datepicker-content.mat-warn .mat-calendar-body-selected{background-color:#f44336;color:#fff}\n.mat-datepicker-content.mat-warn .mat-calendar-body-disabled>.mat-calendar-body-selected{background-color:rgba(244,67,54,.4)}\n.mat-datepicker-content.mat-warn .mat-calendar-body-today.mat-calendar-body-selected{box-shadow:inset 0 0 0 1px #fff}\n.mat-datepicker-content-touch{box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-datepicker-toggle-active{color:#3f51b5}\n.mat-datepicker-toggle-active.mat-accent{color:#ff4081}\n.mat-datepicker-toggle-active.mat-warn{color:#f44336}\n.mat-dialog-container{box-shadow:0 11px 15px -7px rgba(0,0,0,.2),0 24px 38px 3px rgba(0,0,0,.14),0 9px 46px 8px rgba(0,0,0,.12);background:#fff;color:rgba(0,0,0,.87)}\n.mat-divider{border-top-color:rgba(0,0,0,.12)}\n.mat-divider-vertical{border-right-color:rgba(0,0,0,.12)}\n.mat-expansion-panel{background:#fff;color:rgba(0,0,0,.87)}\n.mat-expansion-panel:not([class*=mat-elevation-z]){box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}\n.mat-action-row{border-top-color:rgba(0,0,0,.12)}\n.mat-expansion-panel:not(.mat-expanded) .mat-expansion-panel-header:not([aria-disabled=true]).cdk-keyboard-focused,.mat-expansion-panel:not(.mat-expanded) .mat-expansion-panel-header:not([aria-disabled=true]).cdk-program-focused,.mat-expansion-panel:not(.mat-expanded) .mat-expansion-panel-header:not([aria-disabled=true]):hover{background:rgba(0,0,0,.04)}\n@media (hover:none){.mat-expansion-panel:not(.mat-expanded):not([aria-disabled=true]) .mat-expansion-panel-header:hover{background:#fff}}\n.mat-expansion-panel-header-title{color:rgba(0,0,0,.87)}\n.mat-expansion-indicator::after,.mat-expansion-panel-header-description{color:rgba(0,0,0,.54)}\n.mat-expansion-panel-header[aria-disabled=true]{color:rgba(0,0,0,.26)}\n.mat-expansion-panel-header[aria-disabled=true] .mat-expansion-panel-header-description,.mat-expansion-panel-header[aria-disabled=true] .mat-expansion-panel-header-title{color:inherit}\n.mat-form-field-label{color:rgba(0,0,0,.6)}\n.mat-hint{color:rgba(0,0,0,.6)}\n.mat-form-field.mat-focused .mat-form-field-label{color:#3f51b5}\n.mat-form-field.mat-focused .mat-form-field-label.mat-accent{color:#ff4081}\n.mat-form-field.mat-focused .mat-form-field-label.mat-warn{color:#f44336}\n.mat-focused .mat-form-field-required-marker{color:#ff4081}\n.mat-form-field-ripple{background-color:rgba(0,0,0,.87)}\n.mat-form-field.mat-focused .mat-form-field-ripple{background-color:#3f51b5}\n.mat-form-field.mat-focused .mat-form-field-ripple.mat-accent{background-color:#ff4081}\n.mat-form-field.mat-focused .mat-form-field-ripple.mat-warn{background-color:#f44336}\n.mat-form-field-type-mat-native-select.mat-focused:not(.mat-form-field-invalid) .mat-form-field-infix::after{color:#3f51b5}\n.mat-form-field-type-mat-native-select.mat-focused:not(.mat-form-field-invalid).mat-accent .mat-form-field-infix::after{color:#ff4081}\n.mat-form-field-type-mat-native-select.mat-focused:not(.mat-form-field-invalid).mat-warn .mat-form-field-infix::after{color:#f44336}\n.mat-form-field.mat-form-field-invalid .mat-form-field-label{color:#f44336}\n.mat-form-field.mat-form-field-invalid .mat-form-field-label .mat-form-field-required-marker,.mat-form-field.mat-form-field-invalid .mat-form-field-label.mat-accent{color:#f44336}\n.mat-form-field.mat-form-field-invalid .mat-form-field-ripple,.mat-form-field.mat-form-field-invalid .mat-form-field-ripple.mat-accent{background-color:#f44336}\n.mat-error{color:#f44336}\n.mat-form-field-appearance-legacy .mat-form-field-label{color:rgba(0,0,0,.54)}\n.mat-form-field-appearance-legacy .mat-hint{color:rgba(0,0,0,.54)}\n.mat-form-field-appearance-legacy .mat-form-field-underline{background-color:rgba(0,0,0,.42)}\n.mat-form-field-appearance-legacy.mat-form-field-disabled .mat-form-field-underline{background-image:linear-gradient(to right,rgba(0,0,0,.42) 0,rgba(0,0,0,.42) 33%,transparent 0);background-size:4px 100%;background-repeat:repeat-x}\n.mat-form-field-appearance-standard .mat-form-field-underline{background-color:rgba(0,0,0,.42)}\n.mat-form-field-appearance-standard.mat-form-field-disabled .mat-form-field-underline{background-image:linear-gradient(to right,rgba(0,0,0,.42) 0,rgba(0,0,0,.42) 33%,transparent 0);background-size:4px 100%;background-repeat:repeat-x}\n.mat-form-field-appearance-fill .mat-form-field-flex{background-color:rgba(0,0,0,.04)}\n.mat-form-field-appearance-fill.mat-form-field-disabled .mat-form-field-flex{background-color:rgba(0,0,0,.02)}\n.mat-form-field-appearance-fill .mat-form-field-underline::before{background-color:rgba(0,0,0,.42)}\n.mat-form-field-appearance-fill.mat-form-field-disabled .mat-form-field-label{color:rgba(0,0,0,.38)}\n.mat-form-field-appearance-fill.mat-form-field-disabled .mat-form-field-underline::before{background-color:transparent}\n.mat-form-field-appearance-outline .mat-form-field-outline{color:rgba(0,0,0,.12)}\n.mat-form-field-appearance-outline .mat-form-field-outline-thick{color:rgba(0,0,0,.87)}\n.mat-form-field-appearance-outline.mat-focused .mat-form-field-outline-thick{color:#3f51b5}\n.mat-form-field-appearance-outline.mat-focused.mat-accent .mat-form-field-outline-thick{color:#ff4081}\n.mat-form-field-appearance-outline.mat-focused.mat-warn .mat-form-field-outline-thick{color:#f44336}\n.mat-form-field-appearance-outline.mat-form-field-invalid.mat-form-field-invalid .mat-form-field-outline-thick{color:#f44336}\n.mat-form-field-appearance-outline.mat-form-field-disabled .mat-form-field-label{color:rgba(0,0,0,.38)}\n.mat-form-field-appearance-outline.mat-form-field-disabled .mat-form-field-outline{color:rgba(0,0,0,.06)}\n.mat-icon.mat-primary{color:#3f51b5}\n.mat-icon.mat-accent{color:#ff4081}\n.mat-icon.mat-warn{color:#f44336}\n.mat-form-field-type-mat-native-select .mat-form-field-infix::after{color:rgba(0,0,0,.54)}\n.mat-form-field-type-mat-native-select.mat-form-field-disabled .mat-form-field-infix::after,.mat-input-element:disabled{color:rgba(0,0,0,.38)}\n.mat-input-element{caret-color:#3f51b5}\n.mat-input-element::-webkit-input-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element::-moz-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element:-ms-input-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element::-ms-input-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element::placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element::-moz-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element::-webkit-input-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element:-ms-input-placeholder{color:rgba(0,0,0,.42)}\n.mat-accent .mat-input-element{caret-color:#ff4081}\n.mat-form-field-invalid .mat-input-element,.mat-warn .mat-input-element{caret-color:#f44336}\n.mat-form-field-type-mat-native-select.mat-form-field-invalid .mat-form-field-infix::after{color:#f44336}\n.mat-list-base .mat-list-item{color:rgba(0,0,0,.87)}\n.mat-list-base .mat-list-option{color:rgba(0,0,0,.87)}\n.mat-list-base .mat-subheader{color:rgba(0,0,0,.54)}\n.mat-list-item-disabled{background-color:#eee}\n.mat-action-list .mat-list-item:focus,.mat-action-list .mat-list-item:hover,.mat-list-option:focus,.mat-list-option:hover,.mat-nav-list .mat-list-item:focus,.mat-nav-list .mat-list-item:hover{background:rgba(0,0,0,.04)}\n.mat-menu-panel{background:#fff}\n.mat-menu-panel:not([class*=mat-elevation-z]){box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12)}\n.mat-menu-item{background:0 0;color:rgba(0,0,0,.87)}\n.mat-menu-item[disabled],.mat-menu-item[disabled]::after{color:rgba(0,0,0,.38)}\n.mat-menu-item .mat-icon-no-color,.mat-menu-item-submenu-trigger::after{color:rgba(0,0,0,.54)}\n.mat-menu-item-highlighted:not([disabled]),.mat-menu-item.cdk-keyboard-focused:not([disabled]),.mat-menu-item.cdk-program-focused:not([disabled]),.mat-menu-item:hover:not([disabled]){background:rgba(0,0,0,.04)}\n.mat-paginator{background:#fff}\n.mat-paginator,.mat-paginator-page-size .mat-select-trigger{color:rgba(0,0,0,.54)}\n.mat-paginator-decrement,.mat-paginator-increment{border-top:2px solid rgba(0,0,0,.54);border-right:2px solid rgba(0,0,0,.54)}\n.mat-paginator-first,.mat-paginator-last{border-top:2px solid rgba(0,0,0,.54)}\n.mat-icon-button[disabled] .mat-paginator-decrement,.mat-icon-button[disabled] .mat-paginator-first,.mat-icon-button[disabled] .mat-paginator-increment,.mat-icon-button[disabled] .mat-paginator-last{border-color:rgba(0,0,0,.38)}\n.mat-progress-bar-background{fill:#c5cae9}\n.mat-progress-bar-buffer{background-color:#c5cae9}\n.mat-progress-bar-fill::after{background-color:#3f51b5}\n.mat-progress-bar.mat-accent .mat-progress-bar-background{fill:#ff80ab}\n.mat-progress-bar.mat-accent .mat-progress-bar-buffer{background-color:#ff80ab}\n.mat-progress-bar.mat-accent .mat-progress-bar-fill::after{background-color:#ff4081}\n.mat-progress-bar.mat-warn .mat-progress-bar-background{fill:#ffcdd2}\n.mat-progress-bar.mat-warn .mat-progress-bar-buffer{background-color:#ffcdd2}\n.mat-progress-bar.mat-warn .mat-progress-bar-fill::after{background-color:#f44336}\n.mat-progress-spinner circle,.mat-spinner circle{stroke:#3f51b5}\n.mat-progress-spinner.mat-accent circle,.mat-spinner.mat-accent circle{stroke:#ff4081}\n.mat-progress-spinner.mat-warn circle,.mat-spinner.mat-warn circle{stroke:#f44336}\n.mat-radio-outer-circle{border-color:rgba(0,0,0,.54)}\n.mat-radio-button.mat-primary.mat-radio-checked .mat-radio-outer-circle{border-color:#3f51b5}\n.mat-radio-button.mat-primary .mat-radio-inner-circle,.mat-radio-button.mat-primary .mat-radio-ripple .mat-ripple-element:not(.mat-radio-persistent-ripple),.mat-radio-button.mat-primary.mat-radio-checked .mat-radio-persistent-ripple,.mat-radio-button.mat-primary:active .mat-radio-persistent-ripple{background-color:#3f51b5}\n.mat-radio-button.mat-accent.mat-radio-checked .mat-radio-outer-circle{border-color:#ff4081}\n.mat-radio-button.mat-accent .mat-radio-inner-circle,.mat-radio-button.mat-accent .mat-radio-ripple .mat-ripple-element:not(.mat-radio-persistent-ripple),.mat-radio-button.mat-accent.mat-radio-checked .mat-radio-persistent-ripple,.mat-radio-button.mat-accent:active .mat-radio-persistent-ripple{background-color:#ff4081}\n.mat-radio-button.mat-warn.mat-radio-checked .mat-radio-outer-circle{border-color:#f44336}\n.mat-radio-button.mat-warn .mat-radio-inner-circle,.mat-radio-button.mat-warn .mat-radio-ripple .mat-ripple-element:not(.mat-radio-persistent-ripple),.mat-radio-button.mat-warn.mat-radio-checked .mat-radio-persistent-ripple,.mat-radio-button.mat-warn:active .mat-radio-persistent-ripple{background-color:#f44336}\n.mat-radio-button.mat-radio-disabled .mat-radio-outer-circle,.mat-radio-button.mat-radio-disabled.mat-radio-checked .mat-radio-outer-circle{border-color:rgba(0,0,0,.38)}\n.mat-radio-button.mat-radio-disabled .mat-radio-inner-circle,.mat-radio-button.mat-radio-disabled .mat-radio-ripple .mat-ripple-element{background-color:rgba(0,0,0,.38)}\n.mat-radio-button.mat-radio-disabled .mat-radio-label-content{color:rgba(0,0,0,.38)}\n.mat-radio-button .mat-ripple-element{background-color:#000}\n.mat-select-value{color:rgba(0,0,0,.87)}\n.mat-select-placeholder{color:rgba(0,0,0,.42)}\n.mat-select-disabled .mat-select-value{color:rgba(0,0,0,.38)}\n.mat-select-arrow{color:rgba(0,0,0,.54)}\n.mat-select-panel{background:#fff}\n.mat-select-panel:not([class*=mat-elevation-z]){box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12)}\n.mat-select-panel .mat-option.mat-selected:not(.mat-option-multiple){background:rgba(0,0,0,.12)}\n.mat-form-field.mat-focused.mat-primary .mat-select-arrow{color:#3f51b5}\n.mat-form-field.mat-focused.mat-accent .mat-select-arrow{color:#ff4081}\n.mat-form-field.mat-focused.mat-warn .mat-select-arrow{color:#f44336}\n.mat-form-field .mat-select.mat-select-invalid .mat-select-arrow{color:#f44336}\n.mat-form-field .mat-select.mat-select-disabled .mat-select-arrow{color:rgba(0,0,0,.38)}\n.mat-drawer-container{background-color:#fafafa;color:rgba(0,0,0,.87)}\n.mat-drawer{background-color:#fff;color:rgba(0,0,0,.87)}\n.mat-drawer.mat-drawer-push{background-color:#fff}\n.mat-drawer:not(.mat-drawer-side){box-shadow:0 8px 10px -5px rgba(0,0,0,.2),0 16px 24px 2px rgba(0,0,0,.14),0 6px 30px 5px rgba(0,0,0,.12)}\n.mat-drawer-side{border-right:solid 1px rgba(0,0,0,.12)}\n.mat-drawer-side.mat-drawer-end{border-left:solid 1px rgba(0,0,0,.12);border-right:none}\n[dir=rtl] .mat-drawer-side{border-left:solid 1px rgba(0,0,0,.12);border-right:none}\n[dir=rtl] .mat-drawer-side.mat-drawer-end{border-left:none;border-right:solid 1px rgba(0,0,0,.12)}\n.mat-drawer-backdrop.mat-drawer-shown{background-color:rgba(0,0,0,.6)}\n.mat-slide-toggle.mat-checked .mat-slide-toggle-thumb{background-color:#ff4081}\n.mat-slide-toggle.mat-checked .mat-slide-toggle-bar{background-color:rgba(255,64,129,.54)}\n.mat-slide-toggle.mat-checked .mat-ripple-element{background-color:#ff4081}\n.mat-slide-toggle.mat-primary.mat-checked .mat-slide-toggle-thumb{background-color:#3f51b5}\n.mat-slide-toggle.mat-primary.mat-checked .mat-slide-toggle-bar{background-color:rgba(63,81,181,.54)}\n.mat-slide-toggle.mat-primary.mat-checked .mat-ripple-element{background-color:#3f51b5}\n.mat-slide-toggle.mat-warn.mat-checked .mat-slide-toggle-thumb{background-color:#f44336}\n.mat-slide-toggle.mat-warn.mat-checked .mat-slide-toggle-bar{background-color:rgba(244,67,54,.54)}\n.mat-slide-toggle.mat-warn.mat-checked .mat-ripple-element{background-color:#f44336}\n.mat-slide-toggle:not(.mat-checked) .mat-ripple-element{background-color:#000}\n.mat-slide-toggle-thumb{box-shadow:0 2px 1px -1px rgba(0,0,0,.2),0 1px 1px 0 rgba(0,0,0,.14),0 1px 3px 0 rgba(0,0,0,.12);background-color:#fafafa}\n.mat-slide-toggle-bar{background-color:rgba(0,0,0,.38)}\n.mat-slider-track-background{background-color:rgba(0,0,0,.26)}\n.mat-primary .mat-slider-thumb,.mat-primary .mat-slider-thumb-label,.mat-primary .mat-slider-track-fill{background-color:#3f51b5}\n.mat-primary .mat-slider-thumb-label-text{color:#fff}\n.mat-accent .mat-slider-thumb,.mat-accent .mat-slider-thumb-label,.mat-accent .mat-slider-track-fill{background-color:#ff4081}\n.mat-accent .mat-slider-thumb-label-text{color:#fff}\n.mat-warn .mat-slider-thumb,.mat-warn .mat-slider-thumb-label,.mat-warn .mat-slider-track-fill{background-color:#f44336}\n.mat-warn .mat-slider-thumb-label-text{color:#fff}\n.mat-slider-focus-ring{background-color:rgba(255,64,129,.2)}\n.cdk-focused .mat-slider-track-background,.mat-slider:hover .mat-slider-track-background{background-color:rgba(0,0,0,.38)}\n.mat-slider-disabled .mat-slider-thumb,.mat-slider-disabled .mat-slider-track-background,.mat-slider-disabled .mat-slider-track-fill{background-color:rgba(0,0,0,.26)}\n.mat-slider-disabled:hover .mat-slider-track-background{background-color:rgba(0,0,0,.26)}\n.mat-slider-min-value .mat-slider-focus-ring{background-color:rgba(0,0,0,.12)}\n.mat-slider-min-value.mat-slider-thumb-label-showing .mat-slider-thumb,.mat-slider-min-value.mat-slider-thumb-label-showing .mat-slider-thumb-label{background-color:rgba(0,0,0,.87)}\n.mat-slider-min-value.mat-slider-thumb-label-showing.cdk-focused .mat-slider-thumb,.mat-slider-min-value.mat-slider-thumb-label-showing.cdk-focused .mat-slider-thumb-label{background-color:rgba(0,0,0,.26)}\n.mat-slider-min-value:not(.mat-slider-thumb-label-showing) .mat-slider-thumb{border-color:rgba(0,0,0,.26);background-color:transparent}\n.mat-slider-min-value:not(.mat-slider-thumb-label-showing).cdk-focused .mat-slider-thumb,.mat-slider-min-value:not(.mat-slider-thumb-label-showing):hover .mat-slider-thumb{border-color:rgba(0,0,0,.38)}\n.mat-slider-min-value:not(.mat-slider-thumb-label-showing).cdk-focused.mat-slider-disabled .mat-slider-thumb,.mat-slider-min-value:not(.mat-slider-thumb-label-showing):hover.mat-slider-disabled .mat-slider-thumb{border-color:rgba(0,0,0,.26)}\n.mat-slider-has-ticks .mat-slider-wrapper::after{border-color:rgba(0,0,0,.7)}\n.mat-slider-horizontal .mat-slider-ticks{background-image:repeating-linear-gradient(to right,rgba(0,0,0,.7),rgba(0,0,0,.7) 2px,transparent 0,transparent);background-image:-moz-repeating-linear-gradient(.0001deg,rgba(0,0,0,.7),rgba(0,0,0,.7) 2px,transparent 0,transparent)}\n.mat-slider-vertical .mat-slider-ticks{background-image:repeating-linear-gradient(to bottom,rgba(0,0,0,.7),rgba(0,0,0,.7) 2px,transparent 0,transparent)}\n.mat-step-header.cdk-keyboard-focused,.mat-step-header.cdk-program-focused,.mat-step-header:hover{background-color:rgba(0,0,0,.04)}\n@media (hover:none){.mat-step-header:hover{background:0 0}}\n.mat-step-header .mat-step-label,.mat-step-header .mat-step-optional{color:rgba(0,0,0,.54)}\n.mat-step-header .mat-step-icon{background-color:rgba(0,0,0,.54);color:#fff}\n.mat-step-header .mat-step-icon-selected,.mat-step-header .mat-step-icon-state-done,.mat-step-header .mat-step-icon-state-edit{background-color:#3f51b5;color:#fff}\n.mat-step-header .mat-step-icon-state-error{background-color:transparent;color:#f44336}\n.mat-step-header .mat-step-label.mat-step-label-active{color:rgba(0,0,0,.87)}\n.mat-step-header .mat-step-label.mat-step-label-error{color:#f44336}\n.mat-stepper-horizontal,.mat-stepper-vertical{background-color:#fff}\n.mat-stepper-vertical-line::before{border-left-color:rgba(0,0,0,.12)}\n.mat-horizontal-stepper-header::after,.mat-horizontal-stepper-header::before,.mat-stepper-horizontal-line{border-top-color:rgba(0,0,0,.12)}\n.mat-sort-header-arrow{color:#757575}\n.mat-tab-header,.mat-tab-nav-bar{border-bottom:1px solid rgba(0,0,0,.12)}\n.mat-tab-group-inverted-header .mat-tab-header,.mat-tab-group-inverted-header .mat-tab-nav-bar{border-top:1px solid rgba(0,0,0,.12);border-bottom:none}\n.mat-tab-label,.mat-tab-link{color:rgba(0,0,0,.87)}\n.mat-tab-label.mat-tab-disabled,.mat-tab-link.mat-tab-disabled{color:rgba(0,0,0,.38)}\n.mat-tab-header-pagination-chevron{border-color:rgba(0,0,0,.87)}\n.mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron{border-color:rgba(0,0,0,.38)}\n.mat-tab-group[class*=mat-background-] .mat-tab-header,.mat-tab-nav-bar[class*=mat-background-]{border-bottom:none;border-top:none}\n.mat-tab-group.mat-primary .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-primary .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-primary .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-primary .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-primary .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-primary .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-primary .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-primary .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(197,202,233,.3)}\n.mat-tab-group.mat-primary .mat-ink-bar,.mat-tab-nav-bar.mat-primary .mat-ink-bar{background-color:#3f51b5}\n.mat-tab-group.mat-primary.mat-background-primary .mat-ink-bar,.mat-tab-nav-bar.mat-primary.mat-background-primary .mat-ink-bar{background-color:#fff}\n.mat-tab-group.mat-accent .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-accent .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-accent .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-accent .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-accent .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-accent .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-accent .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-accent .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(255,128,171,.3)}\n.mat-tab-group.mat-accent .mat-ink-bar,.mat-tab-nav-bar.mat-accent .mat-ink-bar{background-color:#ff4081}\n.mat-tab-group.mat-accent.mat-background-accent .mat-ink-bar,.mat-tab-nav-bar.mat-accent.mat-background-accent .mat-ink-bar{background-color:#fff}\n.mat-tab-group.mat-warn .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-warn .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-warn .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-warn .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-warn .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-warn .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-warn .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-warn .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(255,205,210,.3)}\n.mat-tab-group.mat-warn .mat-ink-bar,.mat-tab-nav-bar.mat-warn .mat-ink-bar{background-color:#f44336}\n.mat-tab-group.mat-warn.mat-background-warn .mat-ink-bar,.mat-tab-nav-bar.mat-warn.mat-background-warn .mat-ink-bar{background-color:#fff}\n.mat-tab-group.mat-background-primary .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-primary .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-primary .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-primary .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-primary .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-primary .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-primary .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-primary .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(197,202,233,.3)}\n.mat-tab-group.mat-background-primary .mat-tab-header,.mat-tab-group.mat-background-primary .mat-tab-links,.mat-tab-nav-bar.mat-background-primary .mat-tab-header,.mat-tab-nav-bar.mat-background-primary .mat-tab-links{background-color:#3f51b5}\n.mat-tab-group.mat-background-primary .mat-tab-label,.mat-tab-group.mat-background-primary .mat-tab-link,.mat-tab-nav-bar.mat-background-primary .mat-tab-label,.mat-tab-nav-bar.mat-background-primary .mat-tab-link{color:#fff}\n.mat-tab-group.mat-background-primary .mat-tab-label.mat-tab-disabled,.mat-tab-group.mat-background-primary .mat-tab-link.mat-tab-disabled,.mat-tab-nav-bar.mat-background-primary .mat-tab-label.mat-tab-disabled,.mat-tab-nav-bar.mat-background-primary .mat-tab-link.mat-tab-disabled{color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-primary .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-primary .mat-tab-header-pagination-chevron{border-color:#fff}\n.mat-tab-group.mat-background-primary .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-primary .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron{border-color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-primary .mat-ripple-element,.mat-tab-nav-bar.mat-background-primary .mat-ripple-element{background-color:rgba(255,255,255,.12)}\n.mat-tab-group.mat-background-accent .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-accent .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-accent .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-accent .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-accent .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-accent .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-accent .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-accent .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(255,128,171,.3)}\n.mat-tab-group.mat-background-accent .mat-tab-header,.mat-tab-group.mat-background-accent .mat-tab-links,.mat-tab-nav-bar.mat-background-accent .mat-tab-header,.mat-tab-nav-bar.mat-background-accent .mat-tab-links{background-color:#ff4081}\n.mat-tab-group.mat-background-accent .mat-tab-label,.mat-tab-group.mat-background-accent .mat-tab-link,.mat-tab-nav-bar.mat-background-accent .mat-tab-label,.mat-tab-nav-bar.mat-background-accent .mat-tab-link{color:#fff}\n.mat-tab-group.mat-background-accent .mat-tab-label.mat-tab-disabled,.mat-tab-group.mat-background-accent .mat-tab-link.mat-tab-disabled,.mat-tab-nav-bar.mat-background-accent .mat-tab-label.mat-tab-disabled,.mat-tab-nav-bar.mat-background-accent .mat-tab-link.mat-tab-disabled{color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-accent .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-accent .mat-tab-header-pagination-chevron{border-color:#fff}\n.mat-tab-group.mat-background-accent .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-accent .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron{border-color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-accent .mat-ripple-element,.mat-tab-nav-bar.mat-background-accent .mat-ripple-element{background-color:rgba(255,255,255,.12)}\n.mat-tab-group.mat-background-warn .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-warn .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-warn .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-warn .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-warn .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-warn .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-warn .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-warn .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(255,205,210,.3)}\n.mat-tab-group.mat-background-warn .mat-tab-header,.mat-tab-group.mat-background-warn .mat-tab-links,.mat-tab-nav-bar.mat-background-warn .mat-tab-header,.mat-tab-nav-bar.mat-background-warn .mat-tab-links{background-color:#f44336}\n.mat-tab-group.mat-background-warn .mat-tab-label,.mat-tab-group.mat-background-warn .mat-tab-link,.mat-tab-nav-bar.mat-background-warn .mat-tab-label,.mat-tab-nav-bar.mat-background-warn .mat-tab-link{color:#fff}\n.mat-tab-group.mat-background-warn .mat-tab-label.mat-tab-disabled,.mat-tab-group.mat-background-warn .mat-tab-link.mat-tab-disabled,.mat-tab-nav-bar.mat-background-warn .mat-tab-label.mat-tab-disabled,.mat-tab-nav-bar.mat-background-warn .mat-tab-link.mat-tab-disabled{color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-warn .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-warn .mat-tab-header-pagination-chevron{border-color:#fff}\n.mat-tab-group.mat-background-warn .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-warn .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron{border-color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-warn .mat-ripple-element,.mat-tab-nav-bar.mat-background-warn .mat-ripple-element{background-color:rgba(255,255,255,.12)}\n.mat-toolbar{background:#f5f5f5;color:rgba(0,0,0,.87)}\n.mat-toolbar.mat-primary{background:#3f51b5;color:#fff}\n.mat-toolbar.mat-accent{background:#ff4081;color:#fff}\n.mat-toolbar.mat-warn{background:#f44336;color:#fff}\n.mat-toolbar .mat-focused .mat-form-field-ripple,.mat-toolbar .mat-form-field-ripple,.mat-toolbar .mat-form-field-underline{background-color:currentColor}\n.mat-toolbar .mat-focused .mat-form-field-label,.mat-toolbar .mat-form-field-label,.mat-toolbar .mat-form-field.mat-focused .mat-select-arrow,.mat-toolbar .mat-select-arrow,.mat-toolbar .mat-select-value{color:inherit}\n.mat-toolbar .mat-input-element{caret-color:currentColor}\n.mat-tooltip{background:rgba(97,97,97,.9)}\n.mat-tree{background:#fff}\n.mat-nested-tree-node,.mat-tree-node{color:rgba(0,0,0,.87)}\n.mat-snack-bar-container{color:rgba(255,255,255,.7);background:#323232;box-shadow:0 3px 5px -1px rgba(0,0,0,.2),0 6px 10px 0 rgba(0,0,0,.14),0 1px 18px 0 rgba(0,0,0,.12)}\n.mat-simple-snackbar-action{color:#ff4081}\nbody {\n  padding: 0 15px 15px 15px;\n  margin-top: 0;\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif;\n}\n.noselect {\n  -webkit-touch-callout: none;\n  /* iOS Safari */\n  -webkit-user-select: none;\n  /* Safari */\n  /* Konqueror HTML */\n  -moz-user-select: none;\n  /* Firefox */\n  -ms-user-select: none;\n  /* Internet Explorer/Edge */\n  user-select: none;\n  /* Non-prefixed version, currently\n     supported by Chrome and Opera */\n}\n.controlsContainer {\n  background-color: #ddd;\n  text-align: right;\n  display: block;\n}\n.controlsContainer ul {\n  margin: 0;\n}\n.controlsContainer .control-sections > li {\n  list-style: none;\n  display: inline-block;\n  border-left: 1px solid #c9c9c9;\n  padding: 0 5px 0 5px;\n  position: relative;\n}\n.controlsContainer .control-sections > li .section-label {\n  font-size: 8pt;\n  top: -13px;\n  position: absolute;\n  border-color: white;\n  border-style: solid;\n  border-width: 1px 1px 0 1px;\n  padding: 0 5px;\n  background-color: #ddd;\n  border-radius: 2px 2px 0 0;\n  text-align: center;\n  color: #555;\n  cursor: default;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  white-space: nowrap;\n}\n.controlsContainer .control-sections > li .control-row-item {\n  display: inline-block;\n  position: relative;\n  height: 34px;\n}\n.controlsContainer .control-sections > li .control-row-item .control-row-button {\n  border-radius: 3px;\n  padding: 5px;\n  height: 24px;\n  cursor: pointer;\n}\n.controlsContainer .control-sections > li .control-row-item .control-row-button:hover {\n  background-color: #d0d0d0;\n}\n.controlsContainer .control-sections > li .control-row-item .control-row-button.dropdown::after {\n  font-size: 5pt;\n  content: \"▼\";\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container {\n  border: 1px solid black;\n  background-color: white;\n  box-shadow: 10px 10px 5px rgba(0, 0, 0, 0.5);\n  position: absolute;\n  z-index: 100;\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.left {\n  right: 0;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.inputfield {\n  width: 150px;\n  padding: 0px 10px;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.inputfield mat-form-field {\n  width: 100%;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.inputfield mat-form-field:first-child {\n  padding-top: 5px;\n}\n.checkbox-custom {\n  opacity: 0;\n  position: absolute;\n}\n.checkbox-custom, .checkbox-custom-label {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 5px;\n  cursor: pointer;\n}\n.checkbox-custom-label {\n  position: relative;\n}\n.checkbox-custom-label.disabled {\n  color: rgba(0, 0, 0, 0.46);\n}\n.checkbox-custom + .checkbox-custom-label:before {\n  content: \"\";\n  background: #fff;\n  border: 3px solid #ddd;\n  display: inline-block;\n  vertical-align: middle;\n  width: 10px;\n  height: 10px;\n  padding: 2px;\n  margin-right: 5px;\n  text-align: center;\n}\n.checkbox-custom:checked + .checkbox-custom-label:before {\n  background: #60c5ff;\n  box-shadow: inset 0px 0px 0px 1px #60c5ff;\n}\n.checkbox-custom:checked:disabled + .checkbox-custom-label:before {\n  background: #b0b0b0;\n  box-shadow: inset 0px 0px 0px 1px #b0b0b0;\n}\n/* You can add global styles to this file, and also import other style files */\nbody {\n  padding: 0 15px 15px 15px;\n  margin-top: 0;\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif;\n}\n.noselect {\n  -webkit-touch-callout: none;\n  /* iOS Safari */\n  -webkit-user-select: none;\n  /* Safari */\n  /* Konqueror HTML */\n  -moz-user-select: none;\n  /* Firefox */\n  -ms-user-select: none;\n  /* Internet Explorer/Edge */\n  user-select: none;\n  /* Non-prefixed version, currently\n     supported by Chrome and Opera */\n}\n.controlsContainer {\n  background-color: #ddd;\n  text-align: right;\n  display: block;\n}\n.controlsContainer ul {\n  margin: 0;\n}\n.controlsContainer .control-sections > li {\n  list-style: none;\n  display: inline-block;\n  border-left: 1px solid #c9c9c9;\n  padding: 0 5px 0 5px;\n  position: relative;\n}\n.controlsContainer .control-sections > li .section-label {\n  font-size: 8pt;\n  top: -13px;\n  position: absolute;\n  border-color: white;\n  border-style: solid;\n  border-width: 1px 1px 0 1px;\n  padding: 0 5px;\n  background-color: #ddd;\n  border-radius: 2px 2px 0 0;\n  text-align: center;\n  color: #555;\n  cursor: default;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  white-space: nowrap;\n}\n.controlsContainer .control-sections > li .control-row-item {\n  display: inline-block;\n  position: relative;\n  height: 34px;\n}\n.controlsContainer .control-sections > li .control-row-item .control-row-button {\n  border-radius: 3px;\n  padding: 5px;\n  height: 24px;\n  cursor: pointer;\n}\n.controlsContainer .control-sections > li .control-row-item .control-row-button:hover {\n  background-color: #d0d0d0;\n}\n.controlsContainer .control-sections > li .control-row-item .control-row-button.dropdown::after {\n  font-size: 5pt;\n  content: \"▼\";\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container {\n  border: 1px solid black;\n  background-color: white;\n  box-shadow: 10px 10px 5px rgba(0, 0, 0, 0.5);\n  position: absolute;\n  z-index: 100;\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.left {\n  right: 0;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.inputfield {\n  width: 150px;\n  padding: 0px 10px;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.inputfield mat-form-field {\n  width: 100%;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.inputfield mat-form-field:first-child {\n  padding-top: 5px;\n}\n.checkbox-custom {\n  opacity: 0;\n  position: absolute;\n}\n.checkbox-custom, .checkbox-custom-label {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 5px;\n  cursor: pointer;\n}\n.checkbox-custom-label {\n  position: relative;\n}\n.checkbox-custom-label.disabled {\n  color: rgba(0, 0, 0, 0.46);\n}\n.checkbox-custom + .checkbox-custom-label:before {\n  content: \"\";\n  background: #fff;\n  border: 3px solid #ddd;\n  display: inline-block;\n  vertical-align: middle;\n  width: 10px;\n  height: 10px;\n  padding: 2px;\n  margin-right: 5px;\n  text-align: center;\n}\n.checkbox-custom:checked + .checkbox-custom-label:before {\n  background: #60c5ff;\n  box-shadow: inset 0px 0px 0px 1px #60c5ff;\n}\n.checkbox-custom:checked:disabled + .checkbox-custom-label:before {\n  background: #b0b0b0;\n  box-shadow: inset 0px 0px 0px 1px #b0b0b0;\n}\n.cell {\n  width: 100%;\n  display: inline-block;\n  margin-top: -2px;\n  font-size: 12px;\n  box-sizing: border-box;\n  border: 1px solid rgba(0, 0, 0, 0.05);\n}\n.cell:not(.mini) {\n  padding: 6.5px 2px;\n  line-height: 13px;\n}\n.cell.mini {\n  width: 8px;\n  height: 8px;\n  margin-right: 2px;\n  margin-top: 2px;\n  border-color: #b8b8b8;\n}\n.cell.has-background:not(.highlight) {\n  border-color: white;\n}\n.cell.editing {\n  border-color: black;\n}\n.cell.header {\n  font-weight: bold;\n}\n.cell.header:hover {\n  color: #60c5ff;\n}\n.cell.header.mini {\n  background-color: black;\n  border-color: black;\n}\n.cell.highlight {\n  background: #60c5ff;\n}\n.cell.highlight span {\n  color: black;\n}\n.cell.itemcount {\n  border: 1px solid;\n  border-color: rgba(255, 255, 255, 0) rgba(255, 255, 255, 0) black rgba(255, 255, 255, 0);\n}\n.cell.disabled:not(.highlight) span {\n  color: #b8b8b8;\n}\n.cell.disabled:not(.highlight).compact {\n  background: url(\"data:image/svg+xml;utf8, <svg xmlns='http://www.w3.org/2000/svg' version='1.1' preserveAspectRatio='none' viewBox='0 0 10 10'><path d='M 10 0 L 0 10' fill='none' stroke='#cccccc' stroke-width='1' /></svg>\");\n}\n.cell.disabled:not(.highlight).mini {\n  background: url(\"data:image/svg+xml;utf8, <svg xmlns='http://www.w3.org/2000/svg' version='1.1' preserveAspectRatio='none' viewBox='0 0 10 10'><path d='M 10 0 L 0 10' fill='none' stroke='#b8b8b8' stroke-width='1' /></svg>\");\n}\n.cell.has-comment:not(.disabled) span {\n  border-bottom: 2px solid transparent;\n}\n.link {\n  cursor: pointer;\n}\n.dataTable {\n  overflow-x: scroll;\n  overflow-y: hidden;\n  font-size: 9pt;\n}\n.dataTable table {\n  table-layout: fixed;\n  border-collapse: collapse;\n}\n.dataTable.compact {\n  text-align: center;\n}\n.dataTable td {\n  vertical-align: top;\n}\n.dataTable .column {\n  padding: 2px 1px 0 1px;\n  width: 1%;\n}\n.dataTable .column.mini {\n  line-height: 3px;\n}\n.dataTable .techniques:hover {\n  background: #ebebeb;\n}\n.dataTable technique-cell.editing + technique-cell > .cell.highlight {\n  border-top: 1px solid black;\n}\n.tableContainer {\n  border: 1px solid #ddd;\n  padding: 10px;\n}\n.multiselect-dropdown {\n  display: inline-block;\n}\n.colorpicker {\n  width: 88px !important;\n  align-items: center;\n  text-align: center;\n}\n.colorpicker .color-block {\n  cursor: pointer;\n  border: 1px solid black;\n  margin: 2.5px;\n}\n.colorpicker .color-block.square {\n  display: inline-block;\n  width: 15px;\n  height: 15px;\n}\n.colorpicker .color-block.wide {\n  display: block;\n  height: 15px;\n  font-size: 10pt;\n  color: gray;\n}\n.colorSetup {\n  font-size: 8pt;\n}\n.colorSetup .colorpicker {\n  width: 10ex;\n}\n.colorSetup .gradient-section-label {\n  font-weight: bold;\n  padding: 4px;\n  text-align: center;\n}\n.colorSetup .gradient-section-content {\n  border-top: 1px solid black;\n  border-bottom: 1px solid black;\n  text-align: left;\n}\n.colorSetup .display-buttons {\n  text-align: center;\n}\n.colorSetup .display-buttons .squarebutton {\n  border: 1px solid #ddd;\n  padding: 4px 0;\n  cursor: pointer;\n}\n.colorSetup .display-buttons .squarebutton:hover {\n  background: #f1f1f1;\n}\n.colorSetup .display-buttons .squarebutton.gradient:hover {\n  text-decoration: underline;\n}\n.colorSetup .display-buttons .presetsmenu {\n  width: 90%;\n  display: inline-block;\n}\n.colorSetup .gradient-controls table {\n  padding: 0;\n  margin: 0;\n  border-collapse: collapse;\n}\n.colorSetup .gradient-controls table td.buttons > div {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.colorSetup .gradient-controls table td .left, .colorSetup .gradient-controls table td .right {\n  display: inline-block;\n}\n.colorSetup .gradient-controls table td .left {\n  float: left;\n}\n.colorSetup .gradient-controls table td .right {\n  text-align: left;\n}\n.colorSetup .gradient-controls table td .right select {\n  width: 80px;\n}\n.colorSetup .gradient-controls table td.col2 {\n  width: 45px;\n}\n.colorSetup .gradient-controls table td.col2 input[type=number] {\n  width: 40px;\n}\n.colorSetup .gradient-controls table .minmax {\n  text-align: center;\n  background-color: #f1f1f1;\n}\n.colorSetup .gradient-controls .addcolor {\n  width: 100%;\n}\n.contextMenu-cover {\n  position: fixed;\n  left: 0;\n  top: 0;\n  width: 100vw;\n  height: 100vh;\n}\n.contextMenu-box {\n  position: absolute;\n  border: 1px solid black;\n  background-color: white;\n  box-shadow: 10px 10px 5px rgba(0, 0, 0, 0.5);\n  position: absolute;\n  z-index: 100;\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n}\n.contextMenu-box.left {\n  right: 0;\n}\n.contextMenu-box .contextMenu-section:not(:first-child) {\n  border-top: 1px solid #ddd;\n  margin-top: 2px;\n  padding-top: 2px;\n}\n.contextMenu-box .contextMenu-section .contextMenu-button {\n  padding: 3px;\n  cursor: pointer;\n}\n.contextMenu-box .contextMenu-section .contextMenu-button:hover {\n  background: #60c5ff;\n}\n.tooltip {\n  position: absolute;\n  z-index: 100;\n  padding: 6px;\n  border-radius: 3px;\n  background: rgba(80, 80, 80, 0.75);\n  font-size: 8pt;\n  color: white;\n  max-width: 150px;\n  overflow-x: hidden;\n}\n.tooltip .comment {\n  max-height: 300px;\n  overflow-y: hidden;\n}\n.tooltip .metadatalist {\n  margin: 0;\n  margin-top: 1px;\n  padding-left: 6px;\n  list-style: none;\n}\n.mat-select :focus {\n  color: #63961C;\n}\n.filters {\n  padding: 4px;\n}\n.filters .filter {\n  text-align: left;\n}\n.filters .filter:not(:first-child) {\n  margin-top: 4px;\n}\n.filters .filter .filter-option:hover {\n  background: #60c5ff;\n}\n.multiselect {\n  text-align: center;\n}\n.multiselect .multiselect-grouping .multiselect-grouping-label {\n  padding: 4px;\n  font-weight: bold;\n}\n.multiselect .multiselect-grouping .multiselect-list {\n  text-align: left;\n  border-top: 1px solid black;\n  border-bottom: 1px solid black;\n  height: 200px;\n  overflow-y: scroll;\n}\n.multiselect .multiselect-grouping .multiselect-list table {\n  border-collapse: collapse;\n}\n.multiselect .multiselect-grouping .multiselect-list .multiselect-list-item:hover {\n  background: #60c5ff;\n}\n.multiselect .multiselect-grouping .multiselect-list .multiselect-list-item .multiselect-list-item-label {\n  width: 25ex;\n}\n.multiselect .multiselect-grouping .multiselect-list .multiselect-list-item.selected:not(:hover) {\n  background: #ddd;\n}\n.search {\n  text-align: center;\n}\n.search .search-list {\n  margin-top: 2px;\n  text-align: left;\n  border-top: 1px solid black;\n  border-bottom: 1px solid black;\n  height: 300px;\n  overflow-y: scroll;\n}\n.search .search-list table {\n  border-collapse: collapse;\n  width: 325px;\n}\n.search .search-list .search-list-item:hover {\n  background: #60c5ff;\n}\n.search .search-list .search-list-item .search-list-item-label {\n  width: 25ex;\n}\n.search .search-list .search-list-item.selected:not(:hover) {\n  background: #ddd;\n}\n.search-button:hover {\n  background: #60c5ff;\n}\n.button {\n  background-color: #ddd;\n  border: none;\n  padding: 4px 10px;\n  text-align: center;\n  margin: 2px 1px;\n  transition: 0.3s;\n  display: inline-block;\n  text-decoration: none;\n  cursor: pointer;\n}\n.button:hover {\n  background-color: #b8b8b8;\n}\n.deselectNumber {\n  font-size: 5pt;\n  bottom: 2px;\n  right: 4px;\n  position: absolute;\n  text-align: right;\n}\n.legend {\n  position: fixed;\n  bottom: 0;\n  right: 0;\n  width: 300px;\n  height: 300px;\n  background-color: white;\n  border-left: 1px solid #ddd;\n}\n.legend .itemArea {\n  position: static;\n  overflow-y: scroll;\n  margin-top: 30px;\n  height: 270px;\n  width: 100%;\n  overflow-x: hidden;\n}\n.legend .itemArea .item {\n  width: 100%;\n  height: 40px;\n  padding-left: 5px;\n}\n.legend .itemArea .item .label {\n  margin-left: 10px;\n  width: 150px;\n}\n.legend .itemArea .even {\n  background-color: #f1f1f1;\n  width: 100%;\n  height: 40px;\n}\n.legend .itemArea .even .label {\n  margin-left: 10px;\n  width: 150px;\n}\n.legendBar {\n  position: fixed;\n  bottom: 0;\n  right: 0;\n  width: 300px;\n  height: 30px;\n  background-color: #ddd;\n  transition: 0.3s;\n}\n.legendBar:hover {\n  background: #60c5ff;\n  cursor: pointer;\n}\n.layer_info {\n  padding: 0 !important;\n  box-sizing: border-box !important;\n  width: 250px !important;\n}\n.layer_info .name_desc {\n  padding: 0 10px;\n}\n.layer_info .metadata_input {\n  padding-left: 10px;\n  margin-bottom: 2px;\n  max-height: 50vh;\n  overflow-y: auto;\n  text-align: left;\n}\n.layer_info .metadata_input table {\n  border-spacing: 5px 15px;\n}\n.layer_info .metadata_input table .formfield-group td:first-child {\n  border-width: 1px 0 1px 1px;\n  border-color: black;\n  border-style: solid;\n  width: 5px;\n}\n.layer_info .metadata_input table .formfield-group button {\n  margin-bottom: 4px;\n}"

/***/ }),

/***/ "./src/app/datatable/data-table.component.ts":
/*!***************************************************!*\
  !*** ./src/app/datatable/data-table.component.ts ***!
  \***************************************************/
/*! exports provided: DataTableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataTableComponent", function() { return DataTableComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../config.service */ "./src/app/config.service.ts");
/* harmony import */ var _exporter_exporter_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../exporter/exporter.component */ "./src/app/exporter/exporter.component.ts");
/* harmony import */ var _tabs_tabs_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../tabs/tabs.component */ "./src/app/tabs/tabs.component.ts");
/* harmony import */ var _viewmodels_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../viewmodels.service */ "./src/app/viewmodels.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var exceljs_dist_es5_exceljs_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! exceljs/dist/es5/exceljs.browser */ "./node_modules/exceljs/dist/es5/exceljs.browser.js");
/* harmony import */ var exceljs_dist_es5_exceljs_browser__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(exceljs_dist_es5_exceljs_browser__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var is_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! is_js */ "./node_modules/is_js/is.js");
/* harmony import */ var is_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(is_js__WEBPACK_IMPORTED_MODULE_8__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var DataTableComponent = /** @class */ (function () {
    //////////////////////////////////////////////////////////////////////////
    // RETRIEVES THE TECHNIQUES, TACTICS, AND THREAT DATA FROM DATA SERVICE //
    //     Calls functions to format the data                               //
    //////////////////////////////////////////////////////////////////////////
    function DataTableComponent(dataService, tabs, sanitizer, viewModelsService, configService) {
        var _this = this;
        this.dataService = dataService;
        this.tabs = tabs;
        this.sanitizer = sanitizer;
        this.viewModelsService = viewModelsService;
        this.configService = configService;
        ////////////////
        // DATA TABLE //
        // VARIABLES  //
        ////////////////
        // Stores the techniques and tacticsdisplayed in the dataTable
        this.actTechniques = [];
        this.prepareTechniques = [];
        this.techniques = [];
        this.tactics = {};
        this.tacticStages = {};
        // The techniques and tactics being displayed after filters are applied
        this.filteredTechniques = [];
        this.filteredTactics = {};
        // Stores properly formated tactic names to use in data-table headers
        this.tacticDisplayNames = {};
        // Stores properly formated names for the malware, tools, and threat groups
        this.threatGroupList = [];
        this.softwareGroupList = [];
        this.selectedTechniques = new Set();
        this.searchString = "";
        this.searchResults = [];
        this.searchingName = true;
        this.searchingID = true;
        this.searchingDescription = true;
        this.customContextMenuItems = [];
        this.showingLegend = false;
        this.currentDropdown = ""; //current dropdown menu
        // The data service that delivers the technique/tactic data
        this.ds = null;
        // edit field bindings
        this.commentEditField = "";
        this.scoreEditField = "";
        this.contextMenuVisible = false;
        this.contextMenuSelectedTechnique = null;
        this.contextMenuSelectedTactic = null;
        //tooltip facing, true for right align, false for left align
        // tooltipDirectionHorizontal: boolean = false;
        // tooltipDirectionVertical: boolean = false;
        this.toolTipOverflows = false;
        this.ds = dataService;
        this.ds.getConfig().subscribe(function (config) {
            _this.ds.setUpURLs(config["enterprise_attack_url"], config["pre_attack_url"], config["mobile_data_url"], config["taxii_server"]["enabled"], config["taxii_server"]["url"], config["taxii_server"]["collections"]);
            var domain = config["domain"];
            _this.customContextMenuItems = config["custom_context_menu_items"];
            if (domain === "mitre-enterprise") {
                dataService.getEnterpriseData(false, config["taxii_server"]["enabled"]).subscribe(function (enterpriseData) {
                    // let bundle = enterpriseData[1]["objects"].concat(enterpriseData[0]["objects"]);
                    _this.parseBundle(enterpriseData);
                });
            }
            else if (domain === "mitre-mobile") {
                dataService.getMobileData(false, config["taxii_server"]["enabled"]).subscribe(function (mobileData) {
                    // let bundle = mobileData[1]["objects"].concat(mobileData[0]["objects"]);
                    _this.parseBundle(mobileData);
                });
            }
        });
    }
    DataTableComponent.prototype.clickTactic = function (tacticName) {
        // console.log(tacticName, this.viewModel.highlightedTactic)
        if (this.viewModel.highlightedTactic == tacticName)
            this.viewModel.highlightedTactic = null;
        else
            this.viewModel.highlightedTactic = tacticName;
    };
    DataTableComponent.prototype.containsActiveTechnique = function (tacticName) {
        if (this.viewModel.highlightedTechnique == null || this.viewModel.highlightedTactic == null)
            return false;
        for (var i = 0; i < this.techniques.length; i++) {
            if (this.techniques[i].technique_id === this.viewModel.highlightedTechnique.technique_id)
                return this.techniques[i].tactic === tacticName;
        }
    };
    DataTableComponent.prototype.toggleLegend = function () {
        this.showingLegend = !this.showingLegend;
    };
    ////////////////////////////////////////////////////////////////////
    // Updates the search list interface based on the search string.  //
    // Called whenever the input is updated.                          //
    ////////////////////////////////////////////////////////////////////
    DataTableComponent.prototype.updateSearchDropdown = function () {
        // Clear the previous results and initialize result holders
        this.searchResults = [];
        var nameResults = [], idResults = [], descriptionResults = [];
        var techniqueResultIDs = [];
        if (this.searchString === null || this.searchString === "") {
            return;
        }
        // Create a regular expression to search for
        var formattedInput = this.searchString.toLowerCase();
        var re = new RegExp(formattedInput, "g");
        for (var i = 0; i < this.filteredTechniques.length; i++) {
            if (this.searchingName) {
                var name = this.filteredTechniques[i].name.toLowerCase();
                var nameResult = name.search(re);
                if (nameResult !== -1 && !techniqueResultIDs.includes(this.filteredTechniques[i].technique_id)) {
                    nameResults.push(this.filteredTechniques[i]);
                    techniqueResultIDs.push(this.filteredTechniques[i].technique_id);
                }
            }
            if (this.searchingID) {
                var id = this.filteredTechniques[i].technique_id.toLowerCase();
                var idResult = id.search(re);
                if (idResult !== -1 && !techniqueResultIDs.includes(this.filteredTechniques[i].technique_id)) {
                    idResults.push(this.filteredTechniques[i]);
                    techniqueResultIDs.push(this.filteredTechniques[i].technique_id);
                }
            }
            if (this.searchingDescription) {
                var description = this.filteredTechniques[i].description.toLowerCase();
                var descriptionResult = description.search(re);
                if (descriptionResult !== -1 && !techniqueResultIDs.includes(this.filteredTechniques[i].technique_id)) {
                    descriptionResults.push(this.filteredTechniques[i]);
                    techniqueResultIDs.push(this.filteredTechniques[i].technique_id);
                }
            }
        }
        // Add the results in order of name, ID, and description
        var searchSet = new Set(nameResults.concat(idResults, descriptionResults));
        this.searchResults = Array.from(searchSet);
    };
    DataTableComponent.prototype.selectAllInSearch = function () {
        for (var i = 0; i < this.searchResults.length; i++) {
            this.viewModel.addToTechniqueSelection(this.searchResults[i]);
        }
    };
    DataTableComponent.prototype.deselectAllInSearch = function () {
        for (var i = 0; i < this.searchResults.length; i++) {
            this.viewModel.removeFromTechniqueSelection(this.searchResults[i]);
        }
    };
    ///////////////////////////////////////////////////////////
    // FILTERS THE TECHNIQUES TO SHOW WHAT THE USER REQUESTS //
    //   Filters the stages, then platforms, and finally     //
    //   sorts the techniques by name.                       //
    ///////////////////////////////////////////////////////////
    DataTableComponent.prototype.filterTechniques = function () {
        // copies the list of techniques
        var filteredTechniques = this.techniques;
        // filters out using the stages and platforms dropdowns
        filteredTechniques = this.filterStages(filteredTechniques);
        filteredTechniques = this.filterPlatforms(filteredTechniques);
        if (this.viewModel.hideDisabled)
            filteredTechniques = this.removeDisabled(filteredTechniques);
        // sort
        var self = this;
        filteredTechniques.sort(function (t1, t2) {
            var t1vm = self.viewModel.getTechniqueVM(t1.technique_tactic_union_id);
            var t2vm = self.viewModel.getTechniqueVM(t2.technique_tactic_union_id);
            var c1 = String(t1vm.score).length > 0 ? Number(t1vm.score) : 0;
            var c2 = String(t2vm.score).length > 0 ? Number(t2vm.score) : 0;
            switch (self.viewModel.sorting) {
                case 0:
                    return t1.name.localeCompare(t2.name);
                case 1:
                    return t2.name.localeCompare(t1.name);
                case 2:
                    if (c1 === c2)
                        return t1.name.localeCompare(t2.name);
                    else
                        return c1 - c2;
                case 3:
                    if (c1 === c2)
                        return t1.name.localeCompare(t2.name);
                    else
                        return c2 - c1;
                default:
                    return t1.name.localeCompare(t2.name);
            }
        });
        // sets the displayed filteredTechniques to the newly filtered ones
        this.filteredTechniques = filteredTechniques;
        this.tactics = this.ds.techniquesToTactics(filteredTechniques);
    };
    ///////////////////////////////////////////////////////////
    // FILTERS THE TECHNIQUES USING THE VALUES SET BY THE    //
    // STAGES FILTER DROPDOWN                                //
    //     Returns an array of the newly filtered techniques //
    ///////////////////////////////////////////////////////////
    DataTableComponent.prototype.filterStages = function (preFilteredTechniques) {
        var filteredTechniques = [];
        var stagesSelected = this.viewModel.filters.stages.selection;
        var addPrepare = false;
        var addAct = false;
        if (stagesSelected.length === 1) {
            if (stagesSelected[0].localeCompare("act") === 0) {
                addAct = true;
            }
            else {
                addPrepare = true;
            }
        }
        else if (stagesSelected.length > 1) {
            addPrepare = true;
            addAct = true;
        }
        // based on the platforms set, use the preset technique arrays to make a final
        //    filtered array
        if (addPrepare) {
            filteredTechniques = filteredTechniques.concat(this.prepareTechniques);
        }
        if (addAct) {
            filteredTechniques = filteredTechniques.concat(this.actTechniques);
        }
        return filteredTechniques;
    };
    //////////////////////////////////////////////////////////////////////////////////
    // FILTERS THE TECHNIQUES USING THE VALUES SET BY THE PLATFORMS FILTER DROPDOWN //
    //     Returns an array of the newly filtered techniques                        //
    //////////////////////////////////////////////////////////////////////////////////
    DataTableComponent.prototype.filterPlatforms = function (preFilteredTechniques) {
        var selectedPlatforms = this.viewModel.filters.platforms.selection;
        if (selectedPlatforms.length === 0) {
            return [];
        }
        else if (selectedPlatforms.length === this.viewModel.filters.platforms.options.length) {
            return preFilteredTechniques;
        }
        else {
            var currentPlatformsSet = new Set(selectedPlatforms.map(function (platform) { return platform.toLowerCase(); }));
            var filteredTechniques = [];
            // For each technique
            for (var i = 0; i < preFilteredTechniques.length; i++) {
                var technique = preFilteredTechniques[i];
                var techniquePlatforms = technique.platforms;
                if (techniquePlatforms === null || techniquePlatforms === undefined) {
                    filteredTechniques.push(technique);
                }
                else {
                    // check if the technique has a platform in the current set
                    for (var _i = 0, techniquePlatforms_1 = techniquePlatforms; _i < techniquePlatforms_1.length; _i++) {
                        var platform = techniquePlatforms_1[_i];
                        if (currentPlatformsSet.has(platform.toLowerCase())) {
                            filteredTechniques.push(technique);
                            break;
                        }
                    }
                }
            }
            return filteredTechniques;
        }
    };
    DataTableComponent.prototype.removeDisabled = function (techniques) {
        var filtered = [];
        var self = this;
        techniques.forEach(function (technique) {
            // TODO other filters
            if (!(!self.viewModel.getTechniqueVM(technique.technique_tactic_union_id).enabled && self.viewModel.hideDisabled))
                filtered.push(technique);
        });
        return filtered;
    };
    //////////////////////////////////////////////////////////
    // Stringifies the current view model into a json string//
    // stores the string as a blob                          //
    // and then saves the blob as a json file               //
    //////////////////////////////////////////////////////////
    DataTableComponent.prototype.saveLayerLocally = function () {
        var json = this.viewModel.serialize(); //JSON.stringify(this.viewModel.serialize(), null, "\t");
        var blob = new Blob([json], { type: "text/json" });
        var filename = this.viewModel.name.replace(/ /g, "_") + ".json";
        // FileSaver.saveAs(blob, this.viewModel.name.replace(/ /g, "_") + ".json");
        this.saveBlob(blob, filename);
    };
    DataTableComponent.prototype.saveLayerGlobally = function () {
        var json = this.viewModel.serialize();
        var filename = this.viewModel.name.replace(/ /g, "_") + ".json";
        this.dataService.saveFile(filename, json);
    };
    DataTableComponent.prototype.deleteLayerGlobally = function () {
        var filename = this.viewModel.name.replace(/ /g, "_") + ".json";
        this.dataService.deleteFile(filename);
        this.tabs.closeActiveTab();
    };
    DataTableComponent.prototype.saveBlob = function (blob, filename) {
        if (is_js__WEBPACK_IMPORTED_MODULE_8__["ie"]()) { //internet explorer
            window.navigator.msSaveBlob(blob, filename);
        }
        else {
            var svgUrl = URL.createObjectURL(blob);
            var downloadLink = document.createElement("a");
            downloadLink.href = svgUrl;
            downloadLink.download = filename;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }
    };
    /////////////////////////////
    //     EXPORT TO EXCEL     //
    /////////////////////////////
    DataTableComponent.prototype.saveLayerLocallyExcel = function () {
        var _this = this;
        var self = this;
        var workbook = new exceljs_dist_es5_exceljs_browser__WEBPACK_IMPORTED_MODULE_7__["Workbook"]();
        var worksheet = workbook.addWorksheet('layer');
        // CREATE COLS
        worksheet.columns = this.dataService.tacticNames(this.filteredTechniques).map(function (tacticname) {
            return { header: tacticname, key: tacticname };
        });
        var _loop_1 = function (tacticName) {
            var col = worksheet.getColumn(tacticName);
            var techniques = this_1.tactics[tacticName.toString()];
            var cells = techniques.map(function (technique) {
                return technique.name;
                // return this.viewModel.getTechniqueVM(technique.technique_tactic_union_id).;
            });
            //toString because String != string
            col.values = [this_1.tacticDisplayNames[tacticName.toString()]].concat(cells); //insert header cell at top of col
            col.eachCell(function (cell, rowNumber) {
                if (rowNumber > 1) { //skip tactic header
                    var index = rowNumber - 2; //skip header, and exceljs indexes starting at 1 
                    if (cell.value && cell.value != "") { // handle jagged cols
                        // console.log(cell.value);
                        var tvm = _this.viewModel.getTechniqueVM(techniques[index].technique_tactic_union_id);
                        if (tvm.enabled) {
                            if (tvm.color) { //manually assigned
                                cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF' + tvm.color.substring(1) } };
                                cell.font = { color: { 'argb': 'FF' + tinycolor.mostReadable(tvm.color, ["white", "black"]).toHex() } };
                            }
                            else if (tvm.score) { //score assigned
                                cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF' + tvm.scoreColor.toHex() } };
                                cell.font = { color: { 'argb': 'FF' + tinycolor.mostReadable(tvm.scoreColor, ["white", "black"]).toHex() } };
                            }
                            if (tvm.comment) { //comment present on technique
                                cell.note = tvm.comment;
                            }
                        }
                        else { //disabled
                            cell.font = { color: { 'argb': 'FFBCBCBC' } };
                        }
                    }
                }
            });
        };
        var this_1 = this;
        // CREATE CELLS
        for (var _i = 0, _a = this.dataService.tacticNames(this.filteredTechniques); _i < _a.length; _i++) {
            var tacticName = _a[_i];
            _loop_1(tacticName);
        }
        // STYLE      
        // width of cols
        worksheet.columns.forEach(function (column) { column.width = column.header.length < 20 ? 20 : column.header.length; });
        //tactic background
        if (this.viewModel.showTacticRowBackground) {
            worksheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { 'argb': 'FF' + this.viewModel.tacticRowBackground.substring(1) } };
            worksheet.getRow(1).font = { bold: true, color: { "argb": 'FF' + tinycolor.mostReadable(this.viewModel.tacticRowBackground, ["white", "black"]).toHex() } };
        }
        else {
            worksheet.getRow(1).font = { bold: true }; //bold header
        }
        // Save the workbook
        workbook.xlsx.writeBuffer().then(function (data) {
            var blob = new Blob([data], { type: "application/octet-stream" });
            var filename = _this.viewModel.name.replace(/ /g, "_") + ".xlsx";
            _this.saveBlob(blob, filename);
        });
    };
    /**
     * Angular lifecycle hook
     */
    DataTableComponent.prototype.ngAfterViewInit = function () {
        var element = document.getElementById("tooltip" + this.viewModel.uid);
        element.style.left = -10000 + "px";
    };
    ////////////////////////////////////////////////////
    // Creates a mapping of each tactic and its phase //
    ////////////////////////////////////////////////////
    DataTableComponent.prototype.setTacticPhases = function (tactics) {
        this.tacticStages = {};
        for (var i = 0; i < tactics.length; i++) {
            var tactic = tactics[i];
            this.tacticStages[tactic.tactic] = tactic.phase;
        }
    };
    //////////////////////////////////////////////////////////////////////
    // Does preliminary sorting before establishing the data structures //
    //////////////////////////////////////////////////////////////////////
    DataTableComponent.prototype.parseBundle = function (bundle) {
        var techniques = {}, threatGroups = {}, software = {}, relationships = {};
        var tactics = []; //list of ordered tactics
        // ! the phases array defines the order of phases in the table; prepare comes before act
        var phases = [
            { name: "prepare", objects: bundle[1]["objects"] },
            { name: "act", objects: bundle[0]["objects"] }
        ];
        var _loop_2 = function (phase) {
            // tactic info for this phase
            var tacOrders = {};
            var tacticIDToDef = {};
            //for objects in this phase bundle
            var objects = phase.objects;
            for (var i = 0; i < objects.length; i++) {
                object = objects[i];
                if (object.x_mitre_deprecated !== true && object.revoked !== true) {
                    if (object.type === "attack-pattern") {
                        techniques[object.id] = object;
                    }
                    else if (object.type === "intrusion-set") {
                        threatGroups[object.id] = object;
                    }
                    else if (object.type === "malware" || object.type === "tool") {
                        software[object.id] = object;
                    }
                    else if (object.type === "relationship") {
                        relationships[object.id] = object;
                    }
                    else if (object.type === "x-mitre-tactic") {
                        //store tactic info by their IDs, since we don't yet have order
                        tacticIDToDef[object.id] = {
                            "tactic": object.x_mitre_shortname,
                            "description": object.description,
                            "phase": phase.name,
                            "url": object["external_references"][0]["url"]
                        };
                    }
                    else if (object.type === "x-mitre-matrix") {
                        //matrix defines the order of tactics in this phase
                        tacOrders[object.name] = object.tactic_refs;
                    }
                }
            }
            if (Object.keys(tacOrders).length > 1) {
                // multiple matrixes for this phase: mobile attack handling of multiple matrixes
                // ! the order of this array determines the order of the matrixes
                var orderedMatrixes = ["Device Access", "Network-Based Effects"].map(function (name) { return tacOrders[name]; });
                for (var _i = 0, orderedMatrixes_1 = orderedMatrixes; _i < orderedMatrixes_1.length; _i++) {
                    var tacOrder = orderedMatrixes_1[_i];
                    tactics = tactics.concat(tacOrder.map(function (tacID) { return tacticIDToDef[tacID]; }));
                }
            }
            else {
                //only one matrix object for this phase
                var tacOrder = tacOrders[Object.keys(tacOrders)[0]];
                tactics = tactics.concat(tacOrder.map(function (tacID) { return tacticIDToDef[tacID]; }));
            }
        };
        var object;
        for (var _i = 0, phases_1 = phases; _i < phases_1.length; _i++) {
            var phase = phases_1[_i];
            _loop_2(phase);
        }
        this.ds.setTacticOrder(tactics);
        this.setTacticPhases(tactics);
        this.establishTechniques(techniques);
        this.setTacticDisplayNames();
        // this.loadFilters();
        this.filterTechniques();
        this.establishThreatDataHolders(threatGroups, software);
        this.establishThreatData(techniques, relationships);
        this.searchResults = [];
        if (this.viewModel.needsToConstructTechniqueVMs) {
            this.viewModel.constructLegacyVMs();
            this.filterTechniques();
        }
    };
    ////////////////////////////////////////////////////////////////////////////////////////
    // Creates the arrays of Technique objects to be handled elsewhere in the application //
    ////////////////////////////////////////////////////////////////////////////////////////
    DataTableComponent.prototype.establishTechniques = function (techniques) {
        var prepareTechniquesParsed = [], actTechniquesParsed = [];
        var techniqueIDToUIDMap = new Map();
        var techniqueUIDToIDMap = new Map();
        var techIDtoUIDMap = {};
        var techUIDtoIDMap = {};
        for (var techniqueID in techniques) {
            var t = techniques[techniqueID];
            // console.log(t)
            var tacticObject = t["kill_chain_phases"];
            var tacticFinal = [];
            if (tacticObject !== undefined) {
                tacticObject.forEach(function (tactic) { tacticFinal.push(tactic.phase_name); });
            }
            var url = "none", tid = "blank";
            if (t.external_references !== undefined) {
                url = t.external_references[0].url;
                tid = t.external_references[0].external_id;
            }
            var stageString = this.tacticStages[tacticObject[0]["phase_name"]];
            for (var i = 0; i < tacticFinal.length; i++) {
                var formattedTechnique = new _data_service__WEBPACK_IMPORTED_MODULE_1__["Technique"](t.name, t.description, tacticFinal[i], url, t.x_mitre_platforms, t.id, tid);
                if (!techniqueIDToUIDMap.has(tid)) {
                    //techniqueIDToUIDMap[tid] = [formattedTechnique.technique_tactic_union_id];
                    techniqueIDToUIDMap.set(tid, [formattedTechnique.technique_tactic_union_id]);
                }
                else {
                    var arr = techniqueIDToUIDMap.get(tid);
                    arr.push(formattedTechnique.technique_tactic_union_id);
                    techniqueIDToUIDMap.set(tid, arr);
                }
                if (techIDtoUIDMap[tid] === null || techIDtoUIDMap[tid] === undefined) {
                    techIDtoUIDMap[tid] = [formattedTechnique.technique_tactic_union_id];
                }
                else {
                    var arr_1 = techIDtoUIDMap[tid];
                    arr_1.push(formattedTechnique.technique_tactic_union_id);
                    techIDtoUIDMap[tid] = arr_1;
                }
                techUIDtoIDMap[formattedTechnique.technique_tactic_union_id] = tid;
                // techniqueUIDToIDMap[formattedTechnique.technique_tactic_union_id] = tid;
                techniqueUIDToIDMap.set(formattedTechnique.technique_tactic_union_id, tid);
                if (stageString === "act") {
                    actTechniquesParsed.push(formattedTechnique);
                }
                else {
                    prepareTechniquesParsed.push(formattedTechnique);
                }
            }
        }
        ;
        this.viewModel.setTechniqueMaps(techIDtoUIDMap, techUIDtoIDMap);
        // Stores techniques in arrays according to phase
        prepareTechniquesParsed.sort(function (a, b) { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0); });
        actTechniquesParsed.sort(function (a, b) { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0); });
        this.actTechniques = actTechniquesParsed, this.prepareTechniques = prepareTechniquesParsed;
        this.techniques = this.actTechniques.concat(this.prepareTechniques);
        this.filteredTechniques = this.techniques;
        this.tactics = this.dataService.techniquesToTactics(this.techniques);
        if (this.viewModel) {
            for (var i_1 = 0; i_1 < this.techniques.length; i_1++) {
                // console.log("initializing VM", this.techniques[i].name)
                if (!this.viewModel.hasTechniqueVM(this.techniques[i_1].technique_tactic_union_id)) {
                    var tvm = new _viewmodels_service__WEBPACK_IMPORTED_MODULE_5__["TechniqueVM"](this.techniques[i_1].technique_tactic_union_id);
                    tvm.score = this.viewModel.initializeScoresTo;
                    this.viewModel.setTechniqueVM(tvm);
                } // don't initialize vms we already have -- from loading or whatever
            }
            this.viewModel.updateGradient();
            this.populateEditFields();
        }
        else {
            console.error("no viewmodel to initialize data for!");
        }
    };
    // Sets a map of properly formated tactic names to display in the data table
    DataTableComponent.prototype.setTacticDisplayNames = function () {
        this.tacticDisplayNames = {};
        for (var tactic in this.tactics) {
            var displayString = tactic.replace(new RegExp("-", 'g'), " ");
            displayString = this.toUpperCase(displayString);
            this.tacticDisplayNames[tactic] = displayString;
        }
    };
    DataTableComponent.prototype.establishThreatDataHolders = function (threatGroups, software) {
        for (var threatGroupID in threatGroups) {
            var threatGroupRawData = threatGroups[threatGroupID];
            // get url from mitre attack
            var url_1 = "";
            for (var i = 0; i < threatGroupRawData.external_references.length; i++) {
                if (threatGroupRawData.external_references[i].source_name === "mitre-attack") {
                    url_1 = threatGroupRawData.external_references[i].url;
                    break;
                }
            }
            var threatGroup = new SecurityInstance(threatGroupRawData.name, "threat-group", threatGroupID, url_1);
            this.threatGroupList.push(threatGroup);
        }
        for (var softwareID in software) {
            var softwareRawData = software[softwareID];
            // get url from mitre attack
            var url = "";
            for (var i = 0; i < softwareRawData.external_references.length; i++) {
                if (softwareRawData.external_references[i].source_name.startsWith("mitre-attack")) {
                    url = softwareRawData.external_references[i].url;
                    break;
                }
            }
            var soft = new SecurityInstance(softwareRawData.name, "software", softwareID, url);
            this.softwareGroupList.push(soft);
        }
        this.threatGroupList.sort(function (a, b) { return (a.name.toLowerCase() > b.name.toLowerCase()) ? 1 : ((b.name.toLowerCase() > a.name.toLowerCase()) ? -1 : 0); });
        this.softwareGroupList.sort(function (a, b) { return (a.name.toLowerCase() > b.name.toLowerCase()) ? 1 : ((b.name.toLowerCase() > a.name.toLowerCase()) ? -1 : 0); });
    };
    /**
     * Add all techniques in the given security instance to the technique selection
     * @param si SecurityInstance object
     */
    DataTableComponent.prototype.selectSecurityInstance = function (si) {
        var self = this;
        si.techniques.forEach(function (technique_id) {
            // console.log(technique_id);
            self.viewModel.addToTechniqueSelection_technique_id(technique_id);
        });
    };
    /**
     *  Remove all techniques in the given security instance from the technique selection
     * @param si SecurityInstance object
     */
    DataTableComponent.prototype.deselectSecurityInstance = function (si) {
        var self = this;
        si.techniques.forEach(function (technique_id) {
            self.viewModel.removeFromTechniqueSelection_technique_id(technique_id);
        });
    };
    /**
     * Populate SecurityInstance objects' techniques array with relevant techniques
     * @param  techniques    technique list
     * @param  relationships relationship list
     */
    DataTableComponent.prototype.establishThreatData = function (techniques, relationships) {
        // console.log(relationships)
        for (var relationship_id in relationships) {
            var relationship = relationships[relationship_id];
            var targetRef = relationship.target_ref;
            var sourceRef = relationship.source_ref;
            // determine what softwares or threat groups this pertains to
            var relevantSI = null;
            var relevantTechnique = null;
            // find relevant security instance
            var groupList = [this.softwareGroupList, this.threatGroupList];
            for (var i = 0; i < groupList.length && !relevantSI; i++) {
                var groupSecurityInstances = groupList[i];
                for (var j = 0; j < groupSecurityInstances.length && !relevantSI; j++) {
                    var securityInstance = groupSecurityInstances[j];
                    if (securityInstance.id === sourceRef) {
                        relevantSI = securityInstance;
                    }
                }
            }
            // find relevant technique
            for (var i = 0; i < this.techniques.length && !relevantTechnique; i++) {
                if (this.techniques[i].id == targetRef) {
                    relevantTechnique = this.techniques[i];
                }
            }
            if (relevantSI && relevantTechnique) {
                // console.log(relationship, relevantSI, relevantTechnique);
                relevantSI.techniques.push(relevantTechnique.technique_id);
            }
        }
        // cull threat groups and software with no associated techniques
        var culledSoftware = [];
        var culledThreatGroups = [];
        this.softwareGroupList.forEach(function (si) {
            if (si.techniques.length > 0)
                culledSoftware.push(si);
        });
        this.threatGroupList.forEach(function (si) {
            if (si.techniques.length > 0)
                culledThreatGroups.push(si);
        });
        this.softwareGroupList = culledSoftware;
        this.threatGroupList = culledThreatGroups;
        // console.log(this.softwareGroupList, this.threatGroupList);
    };
    // open a url in a new tab
    DataTableComponent.prototype.openURL = function (event, technique) {
        var win = window.open(technique.external_references_url);
        if (win) {
            win.focus();
        }
        else {
            alert('Please allow popups for this website');
        }
    };
    // open custom url in a new tab
    DataTableComponent.prototype.openCustomURL = function (event, technique, url) {
        var formattedTechniqueName = this.contextMenuSelectedTechnique.name.replace(/ /g, "_");
        var formattedURL = url.replace(/~Technique_ID~/g, this.contextMenuSelectedTechnique.technique_id);
        formattedURL = formattedURL.replace(/~Technique_Name~/g, formattedTechniqueName);
        formattedURL = formattedURL.replace(/~Tactic_Name~/g, this.contextMenuSelectedTactic);
        var win = window.open(formattedURL);
        if (win) {
            win.focus();
        }
        else {
            alert('Please allow popups for this website');
        }
    };
    // Capitalizes the first letter of each word in a string
    DataTableComponent.prototype.toUpperCase = function (str) {
        return str.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
    };
    /**
     * triggered on left click of technique
     * @param  technique      technique which was left clicked
     * @param  addToSelection add to the technique selection (shift key) or replace selection?
     */
    DataTableComponent.prototype.onTechniqueSelect = function (technique, addToSelection, eventX, eventY) {
        if (!this.configService.getFeature('selecting_techniques')) {
            this.onTechniqueContextMenu(technique, eventX, eventY);
            return;
        }
        //console.log(technique);
        if (addToSelection) {
            // TODO add/remove from selection
            if (this.viewModel.isTechniqueSelected(technique))
                this.viewModel.removeFromTechniqueSelection(technique);
            else
                this.viewModel.addToTechniqueSelection(technique);
        }
        else {
            if (this.viewModel.getSelectedTechniqueCount() > 1)
                this.viewModel.replaceTechniqueSelection(technique);
            else if (this.viewModel.isTechniqueSelected(technique))
                this.viewModel.clearTechniqueSelection();
            else
                this.viewModel.replaceTechniqueSelection(technique);
        }
        //don't do any control population if nothing is being edited
        if (!this.viewModel.isCurrentlyEditing()) {
            if (["comment", "score", "colorpicker"].includes(this.currentDropdown))
                this.currentDropdown = ""; //remove technique control dropdowns, because everything was deselected
            return;
        }
        //else populate editing controls
        this.populateEditFields();
    };
    /**
     * populate edit fields. Gets common values if common values exist for all editing values
     */
    DataTableComponent.prototype.populateEditFields = function () {
        this.commentEditField = this.viewModel.getEditingCommonValue("comment");
        this.scoreEditField = this.viewModel.getEditingCommonValue("score");
    };
    /**
     * called on right clicking a technique in the view, handles context menu stuff
     * @param  technique technique that was clicked
     * @param  event     click event
     * @return           false to suppress normal context menu
     */
    DataTableComponent.prototype.onTechniqueContextMenu = function (technique, eventX, eventY) {
        this.contextMenuVisible = true;
        this.contextMenuSelectedTechnique = technique;
        this.contextMenuSelectedTactic = this.tacticDisplayNames[technique.tactic].replace(" ", "_");
        var self = this;
        window.setTimeout(function () {
            // console.log(event, technique)
            var element = document.getElementById("contextMenu" + self.viewModel.uid);
            var directionHorizontal = document.body.clientWidth - eventX < element.clientWidth; //determine facing
            var directionVertical = document.body.clientHeight - eventY < element.clientHeight; //determine facing
            element.style.left = directionHorizontal ? (eventX - element.clientWidth) + "px" : eventX + "px";
            element.style.top = directionVertical ? (eventY - element.clientHeight) + "px" : eventY + "px";
        }, 0);
        return false;
    };
    /**
     * On mouse move, move the tooltip to the mouse location
     * @param event teh mouse move event
     */
    DataTableComponent.prototype.onMouseMove = function (event) {
        var element = document.getElementById("tooltip" + this.viewModel.uid);
        var tooltipDirectionHorizontal = document.body.clientWidth - event.pageX < 150; //determine facing of tooltip
        var tooltipDirectionVertical = document.body.clientHeight - event.pageY < 350; //determine facing of tooltip
        if (this.viewModel.highlightedTechnique !== null && event.type == "mousemove") {
            element.style.left = tooltipDirectionHorizontal ? (event.pageX - 20 - element.clientWidth) + "px" : (event.pageX + 20) + "px";
            element.style.top = tooltipDirectionVertical ? (event.pageY - element.clientHeight) + "px" : event.pageY + "px";
        }
        else {
            element.style.left = -10000 + "px";
        }
        if (this.viewModel.highlightedTechnique && this.viewModel.getTechniqueVM(this.viewModel.highlightedTechnique.technique_tactic_union_id).comment) {
            var commentdiv = document.getElementById("comment" + this.viewModel.uid);
            this.toolTipOverflows = commentdiv.clientHeight >= 300;
        }
    };
    /**
     * Set the state (enabled/disabled) of the selected features
     */
    DataTableComponent.prototype.setSelectedState = function () {
        var currentState = this.viewModel.getEditingCommonValue('enabled');
        // console.log(currentState)
        if (currentState === '')
            this.viewModel.editSelectedTechniques('enabled', false);
        else
            this.viewModel.editSelectedTechniques('enabled', !currentState);
        this.filterTechniques();
    };
    //sanitize the given css so that it can be displayed without error
    DataTableComponent.prototype.sanitize = function (css) {
        return this.sanitizer.bypassSecurityTrustStyle(css);
    };
    DataTableComponent.prototype.getTacticRowTextColor = function () {
        if (!this.viewModel.showTacticRowBackground)
            return 'black';
        else
            return tinycolor.mostReadable(this.viewModel.tacticRowBackground, ['white', 'black']);
    };
    /**
     * Is score input valid number
     * @param  event keypress event just in case we need it
     * @return       true if valid number
     */
    DataTableComponent.prototype.validateScoreInput = function (event) {
        // console.log(event)
        var result = isNaN(Number(this.scoreEditField));
        // console.log(result)
        return result;
    };
    /**
     * Return whether all techniques in the security instance are currently selected
     * @param  si SecurityInstance object
     * @return    true if all techniques of the instance are selected, false otherwise
     */
    DataTableComponent.prototype.isSecurityInstanceSelected = function (si) {
        for (var i = 0; i < si.techniques.length; i++) {
            var techniqueID = si.techniques[i];
            if (!this.viewModel.isTechniqueSelected_id(techniqueID))
                return false;
        }
        return true;
    };
    /**
     * Return whether the given dropdown element would overflow the side of the page if aligned to the right of its anchor
     * @param  dropdown the DOM node of the panel
     * @return          true if it would overflow
     */
    DataTableComponent.prototype.checkalign = function (dropdown) {
        // console.log(anchor)
        var anchor = dropdown.parentNode;
        return anchor.getBoundingClientRect().left + dropdown.getBoundingClientRect().width > document.body.clientWidth;
    };
    /**
     * open an export layer render tab for the current layer
     */
    DataTableComponent.prototype.exportRender = function () {
        var viewModelCopy = new _viewmodels_service__WEBPACK_IMPORTED_MODULE_5__["ViewModel"](this.viewModel.name, this.viewModel.domain, "vm" + this.viewModelsService.getNonce());
        viewModelCopy.deSerialize(this.viewModel.serialize());
        var exportData = new _exporter_exporter_component__WEBPACK_IMPORTED_MODULE_3__["ExportData"](viewModelCopy, JSON.parse(JSON.stringify(this.tactics)), this.dataService.tacticNames(this.filteredTechniques), JSON.parse(JSON.stringify(this.filteredTechniques)));
        this.tabs.newExporterTab(exportData);
    };
    DataTableComponent.prototype.noncetest = function () {
        console.log(this.viewModelsService.getNonce());
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _viewmodels_service__WEBPACK_IMPORTED_MODULE_5__["ViewModel"])
    ], DataTableComponent.prototype, "viewModel", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('mousemove', ['$event']),
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"])('mouseout', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [MouseEvent]),
        __metadata("design:returntype", void 0)
    ], DataTableComponent.prototype, "onMouseMove", null);
    DataTableComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'DataTable',
            template: __webpack_require__(/*! raw-loader!./data-table.component.html */ "./node_modules/raw-loader/index.js!./src/app/datatable/data-table.component.html"),
            providers: [_data_service__WEBPACK_IMPORTED_MODULE_1__["DataService"], _config_service__WEBPACK_IMPORTED_MODULE_2__["ConfigService"]],
            encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewEncapsulation"].None,
            styles: [__webpack_require__(/*! ./data-table.component.scss */ "./src/app/datatable/data-table.component.scss")]
        }),
        __metadata("design:paramtypes", [_data_service__WEBPACK_IMPORTED_MODULE_1__["DataService"], _tabs_tabs_component__WEBPACK_IMPORTED_MODULE_4__["TabsComponent"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"], _viewmodels_service__WEBPACK_IMPORTED_MODULE_5__["ViewModelsService"], _config_service__WEBPACK_IMPORTED_MODULE_2__["ConfigService"]])
    ], DataTableComponent);
    return DataTableComponent;
}());

var SecurityInstance = /** @class */ (function () {
    function SecurityInstance(name, type, id, url) {
        this.name = name;
        this.type = type;
        this.id = id;
        this.techniques = [];
        this.url = url;
    }
    return SecurityInstance;
}());


/***/ }),

/***/ "./src/app/datatable/technique-cell/technique-cell.component.scss":
/*!************************************************************************!*\
  !*** ./src/app/datatable/technique-cell/technique-cell.component.scss ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n/* You can add global styles to this file, and also import other style files */\n.mat-badge-content{font-weight:600;font-size:12px;font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-badge-small .mat-badge-content{font-size:9px}\n.mat-badge-large .mat-badge-content{font-size:24px}\n.mat-h1,.mat-headline,.mat-typography h1{font:400 24px/32px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 16px}\n.mat-h2,.mat-title,.mat-typography h2{font:500 20px/32px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 16px}\n.mat-h3,.mat-subheading-2,.mat-typography h3{font:400 16px/28px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 16px}\n.mat-h4,.mat-subheading-1,.mat-typography h4{font:400 15px/24px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 16px}\n.mat-h5,.mat-typography h5{font:400 11.62px/20px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 12px}\n.mat-h6,.mat-typography h6{font:400 9.38px/20px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 12px}\n.mat-body-2,.mat-body-strong{font:500 14px/24px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-body,.mat-body-1,.mat-typography{font:400 14px/20px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-body p,.mat-body-1 p,.mat-typography p{margin:0 0 12px}\n.mat-caption,.mat-small{font:400 12px/20px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-display-4,.mat-typography .mat-display-4{font:300 112px/112px Roboto,\"Helvetica Neue\",sans-serif;letter-spacing:-.05em;margin:0 0 56px}\n.mat-display-3,.mat-typography .mat-display-3{font:400 56px/56px Roboto,\"Helvetica Neue\",sans-serif;letter-spacing:-.02em;margin:0 0 64px}\n.mat-display-2,.mat-typography .mat-display-2{font:400 45px/48px Roboto,\"Helvetica Neue\",sans-serif;letter-spacing:-.005em;margin:0 0 64px}\n.mat-display-1,.mat-typography .mat-display-1{font:400 34px/40px Roboto,\"Helvetica Neue\",sans-serif;margin:0 0 64px}\n.mat-bottom-sheet-container{font:400 14px/20px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-button,.mat-fab,.mat-flat-button,.mat-icon-button,.mat-mini-fab,.mat-raised-button,.mat-stroked-button{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:14px;font-weight:500}\n.mat-button-toggle{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-card{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-card-title{font-size:24px;font-weight:500}\n.mat-card-header .mat-card-title{font-size:20px}\n.mat-card-content,.mat-card-subtitle{font-size:14px}\n.mat-checkbox{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-checkbox-layout .mat-checkbox-label{line-height:24px}\n.mat-chip{font-size:14px;font-weight:500}\n.mat-chip .mat-chip-remove.mat-icon,.mat-chip .mat-chip-trailing-icon.mat-icon{font-size:18px}\n.mat-table{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-header-cell{font-size:12px;font-weight:500}\n.mat-cell,.mat-footer-cell{font-size:14px}\n.mat-calendar{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-calendar-body{font-size:13px}\n.mat-calendar-body-label,.mat-calendar-period-button{font-size:14px;font-weight:500}\n.mat-calendar-table-header th{font-size:11px;font-weight:400}\n.mat-dialog-title{font:500 20px/32px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-expansion-panel-header{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:15px;font-weight:400}\n.mat-expansion-panel-content{font:400 14px/20px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-form-field{font-size:inherit;font-weight:400;line-height:1.125;font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-form-field-wrapper{padding-bottom:1.34375em}\n.mat-form-field-prefix .mat-icon,.mat-form-field-suffix .mat-icon{font-size:150%;line-height:1.125}\n.mat-form-field-prefix .mat-icon-button,.mat-form-field-suffix .mat-icon-button{height:1.5em;width:1.5em}\n.mat-form-field-prefix .mat-icon-button .mat-icon,.mat-form-field-suffix .mat-icon-button .mat-icon{height:1.125em;line-height:1.125}\n.mat-form-field-infix{padding:.5em 0;border-top:.84375em solid transparent}\n.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{-webkit-transform:translateY(-1.34375em) scale(.75);transform:translateY(-1.34375em) scale(.75);width:133.33333%}\n.mat-form-field-can-float .mat-input-server[label]:not(:label-shown)+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.34374em) scale(.75);transform:translateY(-1.34374em) scale(.75);width:133.33334%}\n.mat-form-field-label-wrapper{top:-.84375em;padding-top:.84375em}\n.mat-form-field-label{top:1.34375em}\n.mat-form-field-underline{bottom:1.34375em}\n.mat-form-field-subscript-wrapper{font-size:75%;margin-top:.66667em;top:calc(100% - 1.79167em)}\n.mat-form-field-appearance-legacy .mat-form-field-wrapper{padding-bottom:1.25em}\n.mat-form-field-appearance-legacy .mat-form-field-infix{padding:.4375em 0}\n.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-appearance-legacy.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{-webkit-transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.001px);transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.001px);-ms-transform:translateY(-1.28125em) scale(.75);width:133.33333%}\n.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.00101px);transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.00101px);-ms-transform:translateY(-1.28124em) scale(.75);width:133.33334%}\n.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-input-server[label]:not(:label-shown)+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.00102px);transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.00102px);-ms-transform:translateY(-1.28123em) scale(.75);width:133.33335%}\n.mat-form-field-appearance-legacy .mat-form-field-label{top:1.28125em}\n.mat-form-field-appearance-legacy .mat-form-field-underline{bottom:1.25em}\n.mat-form-field-appearance-legacy .mat-form-field-subscript-wrapper{margin-top:.54167em;top:calc(100% - 1.66667em)}\n@media print{.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-appearance-legacy.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{-webkit-transform:translateY(-1.28122em) scale(.75);transform:translateY(-1.28122em) scale(.75)}.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.28121em) scale(.75);transform:translateY(-1.28121em) scale(.75)}.mat-form-field-appearance-legacy.mat-form-field-can-float .mat-input-server[label]:not(:label-shown)+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.2812em) scale(.75);transform:translateY(-1.2812em) scale(.75)}}\n.mat-form-field-appearance-fill .mat-form-field-infix{padding:.25em 0 .75em 0}\n.mat-form-field-appearance-fill .mat-form-field-label{top:1.09375em;margin-top:-.5em}\n.mat-form-field-appearance-fill.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-appearance-fill.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{-webkit-transform:translateY(-.59375em) scale(.75);transform:translateY(-.59375em) scale(.75);width:133.33333%}\n.mat-form-field-appearance-fill.mat-form-field-can-float .mat-input-server[label]:not(:label-shown)+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-.59374em) scale(.75);transform:translateY(-.59374em) scale(.75);width:133.33334%}\n.mat-form-field-appearance-outline .mat-form-field-infix{padding:1em 0 1em 0}\n.mat-form-field-appearance-outline .mat-form-field-label{top:1.84375em;margin-top:-.25em}\n.mat-form-field-appearance-outline.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-appearance-outline.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label{-webkit-transform:translateY(-1.59375em) scale(.75);transform:translateY(-1.59375em) scale(.75);width:133.33333%}\n.mat-form-field-appearance-outline.mat-form-field-can-float .mat-input-server[label]:not(:label-shown)+.mat-form-field-label-wrapper .mat-form-field-label{-webkit-transform:translateY(-1.59374em) scale(.75);transform:translateY(-1.59374em) scale(.75);width:133.33334%}\n.mat-grid-tile-footer,.mat-grid-tile-header{font-size:14px}\n.mat-grid-tile-footer .mat-line,.mat-grid-tile-header .mat-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;box-sizing:border-box}\n.mat-grid-tile-footer .mat-line:nth-child(n+2),.mat-grid-tile-header .mat-line:nth-child(n+2){font-size:12px}\ninput.mat-input-element{margin-top:-.0625em}\n.mat-menu-item{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:14px;font-weight:400}\n.mat-paginator,.mat-paginator-page-size .mat-select-trigger{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:12px}\n.mat-radio-button{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-select{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-select-trigger{height:1.125em}\n.mat-slide-toggle-content{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-slider-thumb-label-text{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:12px;font-weight:500}\n.mat-stepper-horizontal,.mat-stepper-vertical{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-step-label{font-size:14px;font-weight:400}\n.mat-step-sub-label-error{font-weight:400}\n.mat-step-label-error{font-size:14px}\n.mat-step-label-selected{font-size:14px;font-weight:500}\n.mat-tab-group{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-tab-label,.mat-tab-link{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:14px;font-weight:500}\n.mat-toolbar,.mat-toolbar h1,.mat-toolbar h2,.mat-toolbar h3,.mat-toolbar h4,.mat-toolbar h5,.mat-toolbar h6{font:500 20px/32px Roboto,\"Helvetica Neue\",sans-serif;margin:0}\n.mat-tooltip{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:10px;padding-top:6px;padding-bottom:6px}\n.mat-tooltip-handset{font-size:14px;padding-top:8px;padding-bottom:8px}\n.mat-list-item{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-list-option{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-list-base .mat-list-item{font-size:16px}\n.mat-list-base .mat-list-item .mat-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;box-sizing:border-box}\n.mat-list-base .mat-list-item .mat-line:nth-child(n+2){font-size:14px}\n.mat-list-base .mat-list-option{font-size:16px}\n.mat-list-base .mat-list-option .mat-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;box-sizing:border-box}\n.mat-list-base .mat-list-option .mat-line:nth-child(n+2){font-size:14px}\n.mat-list-base .mat-subheader{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:14px;font-weight:500}\n.mat-list-base[dense] .mat-list-item{font-size:12px}\n.mat-list-base[dense] .mat-list-item .mat-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;box-sizing:border-box}\n.mat-list-base[dense] .mat-list-item .mat-line:nth-child(n+2){font-size:12px}\n.mat-list-base[dense] .mat-list-option{font-size:12px}\n.mat-list-base[dense] .mat-list-option .mat-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;box-sizing:border-box}\n.mat-list-base[dense] .mat-list-option .mat-line:nth-child(n+2){font-size:12px}\n.mat-list-base[dense] .mat-subheader{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:12px;font-weight:500}\n.mat-option{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:16px}\n.mat-optgroup-label{font:500 14px/24px Roboto,\"Helvetica Neue\",sans-serif}\n.mat-simple-snackbar{font-family:Roboto,\"Helvetica Neue\",sans-serif;font-size:14px}\n.mat-simple-snackbar-action{line-height:1;font-family:inherit;font-size:inherit;font-weight:500}\n.mat-tree{font-family:Roboto,\"Helvetica Neue\",sans-serif}\n.mat-nested-tree-node,.mat-tree-node{font-weight:400;font-size:14px}\n.mat-ripple{overflow:hidden;position:relative}\n.mat-ripple.mat-ripple-unbounded{overflow:visible}\n.mat-ripple-element{position:absolute;border-radius:50%;pointer-events:none;transition:opacity,-webkit-transform 0s cubic-bezier(0,0,.2,1);transition:opacity,transform 0s cubic-bezier(0,0,.2,1);transition:opacity,transform 0s cubic-bezier(0,0,.2,1),-webkit-transform 0s cubic-bezier(0,0,.2,1);-webkit-transform:scale(0);transform:scale(0)}\n@media (-ms-high-contrast:active){.mat-ripple-element{display:none}}\n.cdk-visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;outline:0;-webkit-appearance:none;-moz-appearance:none}\n.cdk-global-overlay-wrapper,.cdk-overlay-container{pointer-events:none;top:0;left:0;height:100%;width:100%}\n.cdk-overlay-container{position:fixed;z-index:1000}\n.cdk-overlay-container:empty{display:none}\n.cdk-global-overlay-wrapper{display:flex;position:absolute;z-index:1000}\n.cdk-overlay-pane{position:absolute;pointer-events:auto;box-sizing:border-box;z-index:1000;display:flex;max-width:100%;max-height:100%}\n.cdk-overlay-backdrop{position:absolute;top:0;bottom:0;left:0;right:0;z-index:1000;pointer-events:auto;-webkit-tap-highlight-color:transparent;transition:opacity .4s cubic-bezier(.25,.8,.25,1);opacity:0}\n.cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:1}\n@media screen and (-ms-high-contrast:active){.cdk-overlay-backdrop.cdk-overlay-backdrop-showing{opacity:.6}}\n.cdk-overlay-dark-backdrop{background:rgba(0,0,0,.32)}\n.cdk-overlay-transparent-backdrop,.cdk-overlay-transparent-backdrop.cdk-overlay-backdrop-showing{opacity:0}\n.cdk-overlay-connected-position-bounding-box{position:absolute;z-index:1000;display:flex;flex-direction:column;min-width:1px;min-height:1px}\n.cdk-global-scrollblock{position:fixed;width:100%;overflow-y:scroll}\n@-webkit-keyframes cdk-text-field-autofill-start{/*!*/}\n@keyframes cdk-text-field-autofill-start{/*!*/}\n@-webkit-keyframes cdk-text-field-autofill-end{/*!*/}\n@keyframes cdk-text-field-autofill-end{/*!*/}\n.cdk-text-field-autofill-monitored:-webkit-autofill{-webkit-animation-name:cdk-text-field-autofill-start;animation-name:cdk-text-field-autofill-start}\n.cdk-text-field-autofill-monitored:not(:-webkit-autofill){-webkit-animation-name:cdk-text-field-autofill-end;animation-name:cdk-text-field-autofill-end}\ntextarea.cdk-textarea-autosize{resize:none}\ntextarea.cdk-textarea-autosize-measuring{height:auto!important;overflow:hidden!important;padding:2px 0!important;box-sizing:content-box!important}\n.mat-ripple-element{background-color:rgba(0,0,0,.1)}\n.mat-option{color:rgba(0,0,0,.87)}\n.mat-option:focus:not(.mat-option-disabled),.mat-option:hover:not(.mat-option-disabled){background:rgba(0,0,0,.04)}\n.mat-option.mat-selected:not(.mat-option-multiple):not(.mat-option-disabled){background:rgba(0,0,0,.04)}\n.mat-option.mat-active{background:rgba(0,0,0,.04);color:rgba(0,0,0,.87)}\n.mat-option.mat-option-disabled{color:rgba(0,0,0,.38)}\n.mat-primary .mat-option.mat-selected:not(.mat-option-disabled){color:#3f51b5}\n.mat-accent .mat-option.mat-selected:not(.mat-option-disabled){color:#ff4081}\n.mat-warn .mat-option.mat-selected:not(.mat-option-disabled){color:#f44336}\n.mat-optgroup-label{color:rgba(0,0,0,.54)}\n.mat-optgroup-disabled .mat-optgroup-label{color:rgba(0,0,0,.38)}\n.mat-pseudo-checkbox{color:rgba(0,0,0,.54)}\n.mat-pseudo-checkbox::after{color:#fafafa}\n.mat-pseudo-checkbox-disabled{color:#b0b0b0}\n.mat-accent .mat-pseudo-checkbox-checked,.mat-accent .mat-pseudo-checkbox-indeterminate,.mat-pseudo-checkbox-checked,.mat-pseudo-checkbox-indeterminate{background:#ff4081}\n.mat-primary .mat-pseudo-checkbox-checked,.mat-primary .mat-pseudo-checkbox-indeterminate{background:#3f51b5}\n.mat-warn .mat-pseudo-checkbox-checked,.mat-warn .mat-pseudo-checkbox-indeterminate{background:#f44336}\n.mat-pseudo-checkbox-checked.mat-pseudo-checkbox-disabled,.mat-pseudo-checkbox-indeterminate.mat-pseudo-checkbox-disabled{background:#b0b0b0}\n.mat-elevation-z0{box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-elevation-z1{box-shadow:0 2px 1px -1px rgba(0,0,0,.2),0 1px 1px 0 rgba(0,0,0,.14),0 1px 3px 0 rgba(0,0,0,.12)}\n.mat-elevation-z2{box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}\n.mat-elevation-z3{box-shadow:0 3px 3px -2px rgba(0,0,0,.2),0 3px 4px 0 rgba(0,0,0,.14),0 1px 8px 0 rgba(0,0,0,.12)}\n.mat-elevation-z4{box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12)}\n.mat-elevation-z5{box-shadow:0 3px 5px -1px rgba(0,0,0,.2),0 5px 8px 0 rgba(0,0,0,.14),0 1px 14px 0 rgba(0,0,0,.12)}\n.mat-elevation-z6{box-shadow:0 3px 5px -1px rgba(0,0,0,.2),0 6px 10px 0 rgba(0,0,0,.14),0 1px 18px 0 rgba(0,0,0,.12)}\n.mat-elevation-z7{box-shadow:0 4px 5px -2px rgba(0,0,0,.2),0 7px 10px 1px rgba(0,0,0,.14),0 2px 16px 1px rgba(0,0,0,.12)}\n.mat-elevation-z8{box-shadow:0 5px 5px -3px rgba(0,0,0,.2),0 8px 10px 1px rgba(0,0,0,.14),0 3px 14px 2px rgba(0,0,0,.12)}\n.mat-elevation-z9{box-shadow:0 5px 6px -3px rgba(0,0,0,.2),0 9px 12px 1px rgba(0,0,0,.14),0 3px 16px 2px rgba(0,0,0,.12)}\n.mat-elevation-z10{box-shadow:0 6px 6px -3px rgba(0,0,0,.2),0 10px 14px 1px rgba(0,0,0,.14),0 4px 18px 3px rgba(0,0,0,.12)}\n.mat-elevation-z11{box-shadow:0 6px 7px -4px rgba(0,0,0,.2),0 11px 15px 1px rgba(0,0,0,.14),0 4px 20px 3px rgba(0,0,0,.12)}\n.mat-elevation-z12{box-shadow:0 7px 8px -4px rgba(0,0,0,.2),0 12px 17px 2px rgba(0,0,0,.14),0 5px 22px 4px rgba(0,0,0,.12)}\n.mat-elevation-z13{box-shadow:0 7px 8px -4px rgba(0,0,0,.2),0 13px 19px 2px rgba(0,0,0,.14),0 5px 24px 4px rgba(0,0,0,.12)}\n.mat-elevation-z14{box-shadow:0 7px 9px -4px rgba(0,0,0,.2),0 14px 21px 2px rgba(0,0,0,.14),0 5px 26px 4px rgba(0,0,0,.12)}\n.mat-elevation-z15{box-shadow:0 8px 9px -5px rgba(0,0,0,.2),0 15px 22px 2px rgba(0,0,0,.14),0 6px 28px 5px rgba(0,0,0,.12)}\n.mat-elevation-z16{box-shadow:0 8px 10px -5px rgba(0,0,0,.2),0 16px 24px 2px rgba(0,0,0,.14),0 6px 30px 5px rgba(0,0,0,.12)}\n.mat-elevation-z17{box-shadow:0 8px 11px -5px rgba(0,0,0,.2),0 17px 26px 2px rgba(0,0,0,.14),0 6px 32px 5px rgba(0,0,0,.12)}\n.mat-elevation-z18{box-shadow:0 9px 11px -5px rgba(0,0,0,.2),0 18px 28px 2px rgba(0,0,0,.14),0 7px 34px 6px rgba(0,0,0,.12)}\n.mat-elevation-z19{box-shadow:0 9px 12px -6px rgba(0,0,0,.2),0 19px 29px 2px rgba(0,0,0,.14),0 7px 36px 6px rgba(0,0,0,.12)}\n.mat-elevation-z20{box-shadow:0 10px 13px -6px rgba(0,0,0,.2),0 20px 31px 3px rgba(0,0,0,.14),0 8px 38px 7px rgba(0,0,0,.12)}\n.mat-elevation-z21{box-shadow:0 10px 13px -6px rgba(0,0,0,.2),0 21px 33px 3px rgba(0,0,0,.14),0 8px 40px 7px rgba(0,0,0,.12)}\n.mat-elevation-z22{box-shadow:0 10px 14px -6px rgba(0,0,0,.2),0 22px 35px 3px rgba(0,0,0,.14),0 8px 42px 7px rgba(0,0,0,.12)}\n.mat-elevation-z23{box-shadow:0 11px 14px -7px rgba(0,0,0,.2),0 23px 36px 3px rgba(0,0,0,.14),0 9px 44px 8px rgba(0,0,0,.12)}\n.mat-elevation-z24{box-shadow:0 11px 15px -7px rgba(0,0,0,.2),0 24px 38px 3px rgba(0,0,0,.14),0 9px 46px 8px rgba(0,0,0,.12)}\n.mat-app-background{background-color:#fafafa;color:rgba(0,0,0,.87)}\n.mat-theme-loaded-marker{display:none}\n.mat-autocomplete-panel{background:#fff;color:rgba(0,0,0,.87)}\n.mat-autocomplete-panel:not([class*=mat-elevation-z]){box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12)}\n.mat-autocomplete-panel .mat-option.mat-selected:not(.mat-active):not(:hover){background:#fff}\n.mat-autocomplete-panel .mat-option.mat-selected:not(.mat-active):not(:hover):not(.mat-option-disabled){color:rgba(0,0,0,.87)}\n.mat-badge-content{color:#fff;background:#3f51b5}\n@media (-ms-high-contrast:active){.mat-badge-content{outline:solid 1px;border-radius:0}}\n.mat-badge-accent .mat-badge-content{background:#ff4081;color:#fff}\n.mat-badge-warn .mat-badge-content{color:#fff;background:#f44336}\n.mat-badge{position:relative}\n.mat-badge-hidden .mat-badge-content{display:none}\n.mat-badge-disabled .mat-badge-content{background:#b9b9b9;color:rgba(0,0,0,.38)}\n.mat-badge-content{position:absolute;text-align:center;display:inline-block;border-radius:50%;transition:-webkit-transform .2s ease-in-out;transition:transform .2s ease-in-out;transition:transform .2s ease-in-out, -webkit-transform .2s ease-in-out;-webkit-transform:scale(.6);transform:scale(.6);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;pointer-events:none}\n.mat-badge-content._mat-animation-noopable,.ng-animate-disabled .mat-badge-content{transition:none}\n.mat-badge-content.mat-badge-active{-webkit-transform:none;transform:none}\n.mat-badge-small .mat-badge-content{width:16px;height:16px;line-height:16px}\n.mat-badge-small.mat-badge-above .mat-badge-content{top:-8px}\n.mat-badge-small.mat-badge-below .mat-badge-content{bottom:-8px}\n.mat-badge-small.mat-badge-before .mat-badge-content{left:-16px}\n[dir=rtl] .mat-badge-small.mat-badge-before .mat-badge-content{left:auto;right:-16px}\n.mat-badge-small.mat-badge-after .mat-badge-content{right:-16px}\n[dir=rtl] .mat-badge-small.mat-badge-after .mat-badge-content{right:auto;left:-16px}\n.mat-badge-small.mat-badge-overlap.mat-badge-before .mat-badge-content{left:-8px}\n[dir=rtl] .mat-badge-small.mat-badge-overlap.mat-badge-before .mat-badge-content{left:auto;right:-8px}\n.mat-badge-small.mat-badge-overlap.mat-badge-after .mat-badge-content{right:-8px}\n[dir=rtl] .mat-badge-small.mat-badge-overlap.mat-badge-after .mat-badge-content{right:auto;left:-8px}\n.mat-badge-medium .mat-badge-content{width:22px;height:22px;line-height:22px}\n.mat-badge-medium.mat-badge-above .mat-badge-content{top:-11px}\n.mat-badge-medium.mat-badge-below .mat-badge-content{bottom:-11px}\n.mat-badge-medium.mat-badge-before .mat-badge-content{left:-22px}\n[dir=rtl] .mat-badge-medium.mat-badge-before .mat-badge-content{left:auto;right:-22px}\n.mat-badge-medium.mat-badge-after .mat-badge-content{right:-22px}\n[dir=rtl] .mat-badge-medium.mat-badge-after .mat-badge-content{right:auto;left:-22px}\n.mat-badge-medium.mat-badge-overlap.mat-badge-before .mat-badge-content{left:-11px}\n[dir=rtl] .mat-badge-medium.mat-badge-overlap.mat-badge-before .mat-badge-content{left:auto;right:-11px}\n.mat-badge-medium.mat-badge-overlap.mat-badge-after .mat-badge-content{right:-11px}\n[dir=rtl] .mat-badge-medium.mat-badge-overlap.mat-badge-after .mat-badge-content{right:auto;left:-11px}\n.mat-badge-large .mat-badge-content{width:28px;height:28px;line-height:28px}\n.mat-badge-large.mat-badge-above .mat-badge-content{top:-14px}\n.mat-badge-large.mat-badge-below .mat-badge-content{bottom:-14px}\n.mat-badge-large.mat-badge-before .mat-badge-content{left:-28px}\n[dir=rtl] .mat-badge-large.mat-badge-before .mat-badge-content{left:auto;right:-28px}\n.mat-badge-large.mat-badge-after .mat-badge-content{right:-28px}\n[dir=rtl] .mat-badge-large.mat-badge-after .mat-badge-content{right:auto;left:-28px}\n.mat-badge-large.mat-badge-overlap.mat-badge-before .mat-badge-content{left:-14px}\n[dir=rtl] .mat-badge-large.mat-badge-overlap.mat-badge-before .mat-badge-content{left:auto;right:-14px}\n.mat-badge-large.mat-badge-overlap.mat-badge-after .mat-badge-content{right:-14px}\n[dir=rtl] .mat-badge-large.mat-badge-overlap.mat-badge-after .mat-badge-content{right:auto;left:-14px}\n.mat-bottom-sheet-container{box-shadow:0 8px 10px -5px rgba(0,0,0,.2),0 16px 24px 2px rgba(0,0,0,.14),0 6px 30px 5px rgba(0,0,0,.12);background:#fff;color:rgba(0,0,0,.87)}\n.mat-button,.mat-icon-button,.mat-stroked-button{color:inherit;background:0 0}\n.mat-button.mat-primary,.mat-icon-button.mat-primary,.mat-stroked-button.mat-primary{color:#3f51b5}\n.mat-button.mat-accent,.mat-icon-button.mat-accent,.mat-stroked-button.mat-accent{color:#ff4081}\n.mat-button.mat-warn,.mat-icon-button.mat-warn,.mat-stroked-button.mat-warn{color:#f44336}\n.mat-button.mat-accent[disabled],.mat-button.mat-primary[disabled],.mat-button.mat-warn[disabled],.mat-button[disabled][disabled],.mat-icon-button.mat-accent[disabled],.mat-icon-button.mat-primary[disabled],.mat-icon-button.mat-warn[disabled],.mat-icon-button[disabled][disabled],.mat-stroked-button.mat-accent[disabled],.mat-stroked-button.mat-primary[disabled],.mat-stroked-button.mat-warn[disabled],.mat-stroked-button[disabled][disabled]{color:rgba(0,0,0,.26)}\n.mat-button.mat-primary .mat-button-focus-overlay,.mat-icon-button.mat-primary .mat-button-focus-overlay,.mat-stroked-button.mat-primary .mat-button-focus-overlay{background-color:#3f51b5}\n.mat-button.mat-accent .mat-button-focus-overlay,.mat-icon-button.mat-accent .mat-button-focus-overlay,.mat-stroked-button.mat-accent .mat-button-focus-overlay{background-color:#ff4081}\n.mat-button.mat-warn .mat-button-focus-overlay,.mat-icon-button.mat-warn .mat-button-focus-overlay,.mat-stroked-button.mat-warn .mat-button-focus-overlay{background-color:#f44336}\n.mat-button[disabled] .mat-button-focus-overlay,.mat-icon-button[disabled] .mat-button-focus-overlay,.mat-stroked-button[disabled] .mat-button-focus-overlay{background-color:transparent}\n.mat-button .mat-ripple-element,.mat-icon-button .mat-ripple-element,.mat-stroked-button .mat-ripple-element{opacity:.1;background-color:currentColor}\n.mat-button-focus-overlay{background:#000}\n.mat-stroked-button:not([disabled]){border-color:rgba(0,0,0,.12)}\n.mat-fab,.mat-flat-button,.mat-mini-fab,.mat-raised-button{color:rgba(0,0,0,.87);background-color:#fff}\n.mat-fab.mat-primary,.mat-flat-button.mat-primary,.mat-mini-fab.mat-primary,.mat-raised-button.mat-primary{color:#fff}\n.mat-fab.mat-accent,.mat-flat-button.mat-accent,.mat-mini-fab.mat-accent,.mat-raised-button.mat-accent{color:#fff}\n.mat-fab.mat-warn,.mat-flat-button.mat-warn,.mat-mini-fab.mat-warn,.mat-raised-button.mat-warn{color:#fff}\n.mat-fab.mat-accent[disabled],.mat-fab.mat-primary[disabled],.mat-fab.mat-warn[disabled],.mat-fab[disabled][disabled],.mat-flat-button.mat-accent[disabled],.mat-flat-button.mat-primary[disabled],.mat-flat-button.mat-warn[disabled],.mat-flat-button[disabled][disabled],.mat-mini-fab.mat-accent[disabled],.mat-mini-fab.mat-primary[disabled],.mat-mini-fab.mat-warn[disabled],.mat-mini-fab[disabled][disabled],.mat-raised-button.mat-accent[disabled],.mat-raised-button.mat-primary[disabled],.mat-raised-button.mat-warn[disabled],.mat-raised-button[disabled][disabled]{color:rgba(0,0,0,.26)}\n.mat-fab.mat-primary,.mat-flat-button.mat-primary,.mat-mini-fab.mat-primary,.mat-raised-button.mat-primary{background-color:#3f51b5}\n.mat-fab.mat-accent,.mat-flat-button.mat-accent,.mat-mini-fab.mat-accent,.mat-raised-button.mat-accent{background-color:#ff4081}\n.mat-fab.mat-warn,.mat-flat-button.mat-warn,.mat-mini-fab.mat-warn,.mat-raised-button.mat-warn{background-color:#f44336}\n.mat-fab.mat-accent[disabled],.mat-fab.mat-primary[disabled],.mat-fab.mat-warn[disabled],.mat-fab[disabled][disabled],.mat-flat-button.mat-accent[disabled],.mat-flat-button.mat-primary[disabled],.mat-flat-button.mat-warn[disabled],.mat-flat-button[disabled][disabled],.mat-mini-fab.mat-accent[disabled],.mat-mini-fab.mat-primary[disabled],.mat-mini-fab.mat-warn[disabled],.mat-mini-fab[disabled][disabled],.mat-raised-button.mat-accent[disabled],.mat-raised-button.mat-primary[disabled],.mat-raised-button.mat-warn[disabled],.mat-raised-button[disabled][disabled]{background-color:rgba(0,0,0,.12)}\n.mat-fab.mat-primary .mat-ripple-element,.mat-flat-button.mat-primary .mat-ripple-element,.mat-mini-fab.mat-primary .mat-ripple-element,.mat-raised-button.mat-primary .mat-ripple-element{background-color:rgba(255,255,255,.1)}\n.mat-fab.mat-accent .mat-ripple-element,.mat-flat-button.mat-accent .mat-ripple-element,.mat-mini-fab.mat-accent .mat-ripple-element,.mat-raised-button.mat-accent .mat-ripple-element{background-color:rgba(255,255,255,.1)}\n.mat-fab.mat-warn .mat-ripple-element,.mat-flat-button.mat-warn .mat-ripple-element,.mat-mini-fab.mat-warn .mat-ripple-element,.mat-raised-button.mat-warn .mat-ripple-element{background-color:rgba(255,255,255,.1)}\n.mat-flat-button:not([class*=mat-elevation-z]),.mat-stroked-button:not([class*=mat-elevation-z]){box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-raised-button:not([class*=mat-elevation-z]){box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}\n.mat-raised-button:not([disabled]):active:not([class*=mat-elevation-z]){box-shadow:0 5px 5px -3px rgba(0,0,0,.2),0 8px 10px 1px rgba(0,0,0,.14),0 3px 14px 2px rgba(0,0,0,.12)}\n.mat-raised-button[disabled]:not([class*=mat-elevation-z]){box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-fab:not([class*=mat-elevation-z]),.mat-mini-fab:not([class*=mat-elevation-z]){box-shadow:0 3px 5px -1px rgba(0,0,0,.2),0 6px 10px 0 rgba(0,0,0,.14),0 1px 18px 0 rgba(0,0,0,.12)}\n.mat-fab:not([disabled]):active:not([class*=mat-elevation-z]),.mat-mini-fab:not([disabled]):active:not([class*=mat-elevation-z]){box-shadow:0 7px 8px -4px rgba(0,0,0,.2),0 12px 17px 2px rgba(0,0,0,.14),0 5px 22px 4px rgba(0,0,0,.12)}\n.mat-fab[disabled]:not([class*=mat-elevation-z]),.mat-mini-fab[disabled]:not([class*=mat-elevation-z]){box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-button-toggle-group,.mat-button-toggle-standalone{box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}\n.mat-button-toggle-group-appearance-standard,.mat-button-toggle-standalone.mat-button-toggle-appearance-standard{box-shadow:none}\n.mat-button-toggle{color:rgba(0,0,0,.38)}\n.mat-button-toggle .mat-button-toggle-focus-overlay{background-color:rgba(0,0,0,.12)}\n.mat-button-toggle-appearance-standard{color:rgba(0,0,0,.87);background:#fff}\n.mat-button-toggle-appearance-standard .mat-button-toggle-focus-overlay{background-color:#000}\n.mat-button-toggle-group-appearance-standard .mat-button-toggle+.mat-button-toggle{border-left:solid 1px rgba(0,0,0,.12)}\n[dir=rtl] .mat-button-toggle-group-appearance-standard .mat-button-toggle+.mat-button-toggle{border-left:none;border-right:solid 1px rgba(0,0,0,.12)}\n.mat-button-toggle-group-appearance-standard.mat-button-toggle-vertical .mat-button-toggle+.mat-button-toggle{border-left:none;border-right:none;border-top:solid 1px rgba(0,0,0,.12)}\n.mat-button-toggle-checked{background-color:#e0e0e0;color:rgba(0,0,0,.54)}\n.mat-button-toggle-checked.mat-button-toggle-appearance-standard{color:rgba(0,0,0,.87)}\n.mat-button-toggle-disabled{color:rgba(0,0,0,.26);background-color:#eee}\n.mat-button-toggle-disabled.mat-button-toggle-appearance-standard{background:#fff}\n.mat-button-toggle-disabled.mat-button-toggle-checked{background-color:#bdbdbd}\n.mat-button-toggle-group-appearance-standard,.mat-button-toggle-standalone.mat-button-toggle-appearance-standard{border:solid 1px rgba(0,0,0,.12)}\n.mat-card{background:#fff;color:rgba(0,0,0,.87)}\n.mat-card:not([class*=mat-elevation-z]){box-shadow:0 2px 1px -1px rgba(0,0,0,.2),0 1px 1px 0 rgba(0,0,0,.14),0 1px 3px 0 rgba(0,0,0,.12)}\n.mat-card.mat-card-flat:not([class*=mat-elevation-z]){box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-card-subtitle{color:rgba(0,0,0,.54)}\n.mat-checkbox-frame{border-color:rgba(0,0,0,.54)}\n.mat-checkbox-checkmark{fill:#fafafa}\n.mat-checkbox-checkmark-path{stroke:#fafafa!important}\n@media (-ms-high-contrast:black-on-white){.mat-checkbox-checkmark-path{stroke:#000!important}}\n.mat-checkbox-mixedmark{background-color:#fafafa}\n.mat-checkbox-checked.mat-primary .mat-checkbox-background,.mat-checkbox-indeterminate.mat-primary .mat-checkbox-background{background-color:#3f51b5}\n.mat-checkbox-checked.mat-accent .mat-checkbox-background,.mat-checkbox-indeterminate.mat-accent .mat-checkbox-background{background-color:#ff4081}\n.mat-checkbox-checked.mat-warn .mat-checkbox-background,.mat-checkbox-indeterminate.mat-warn .mat-checkbox-background{background-color:#f44336}\n.mat-checkbox-disabled.mat-checkbox-checked .mat-checkbox-background,.mat-checkbox-disabled.mat-checkbox-indeterminate .mat-checkbox-background{background-color:#b0b0b0}\n.mat-checkbox-disabled:not(.mat-checkbox-checked) .mat-checkbox-frame{border-color:#b0b0b0}\n.mat-checkbox-disabled .mat-checkbox-label{color:rgba(0,0,0,.54)}\n@media (-ms-high-contrast:active){.mat-checkbox-disabled{opacity:.5}}\n@media (-ms-high-contrast:active){.mat-checkbox-background{background:0 0}}\n.mat-checkbox .mat-ripple-element{background-color:#000}\n.mat-checkbox-checked:not(.mat-checkbox-disabled).mat-primary .mat-ripple-element,.mat-checkbox:active:not(.mat-checkbox-disabled).mat-primary .mat-ripple-element{background:#3f51b5}\n.mat-checkbox-checked:not(.mat-checkbox-disabled).mat-accent .mat-ripple-element,.mat-checkbox:active:not(.mat-checkbox-disabled).mat-accent .mat-ripple-element{background:#ff4081}\n.mat-checkbox-checked:not(.mat-checkbox-disabled).mat-warn .mat-ripple-element,.mat-checkbox:active:not(.mat-checkbox-disabled).mat-warn .mat-ripple-element{background:#f44336}\n.mat-chip.mat-standard-chip{background-color:#e0e0e0;color:rgba(0,0,0,.87)}\n.mat-chip.mat-standard-chip .mat-chip-remove{color:rgba(0,0,0,.87);opacity:.4}\n.mat-chip.mat-standard-chip:not(.mat-chip-disabled):active{box-shadow:0 3px 3px -2px rgba(0,0,0,.2),0 3px 4px 0 rgba(0,0,0,.14),0 1px 8px 0 rgba(0,0,0,.12)}\n.mat-chip.mat-standard-chip:not(.mat-chip-disabled) .mat-chip-remove:hover{opacity:.54}\n.mat-chip.mat-standard-chip.mat-chip-disabled{opacity:.4}\n.mat-chip.mat-standard-chip::after{background:#000}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-primary{background-color:#3f51b5;color:#fff}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-primary .mat-chip-remove{color:#fff;opacity:.4}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-primary .mat-ripple-element{background:rgba(255,255,255,.1)}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-warn{background-color:#f44336;color:#fff}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-warn .mat-chip-remove{color:#fff;opacity:.4}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-warn .mat-ripple-element{background:rgba(255,255,255,.1)}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-accent{background-color:#ff4081;color:#fff}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-accent .mat-chip-remove{color:#fff;opacity:.4}\n.mat-chip.mat-standard-chip.mat-chip-selected.mat-accent .mat-ripple-element{background:rgba(255,255,255,.1)}\n.mat-table{background:#fff}\n.mat-table tbody,.mat-table tfoot,.mat-table thead,.mat-table-sticky,[mat-footer-row],[mat-header-row],[mat-row],mat-footer-row,mat-header-row,mat-row{background:inherit}\nmat-footer-row,mat-header-row,mat-row,td.mat-cell,td.mat-footer-cell,th.mat-header-cell{border-bottom-color:rgba(0,0,0,.12)}\n.mat-header-cell{color:rgba(0,0,0,.54)}\n.mat-cell,.mat-footer-cell{color:rgba(0,0,0,.87)}\n.mat-calendar-arrow{border-top-color:rgba(0,0,0,.54)}\n.mat-datepicker-content .mat-calendar-next-button,.mat-datepicker-content .mat-calendar-previous-button,.mat-datepicker-toggle{color:rgba(0,0,0,.54)}\n.mat-calendar-table-header{color:rgba(0,0,0,.38)}\n.mat-calendar-table-header-divider::after{background:rgba(0,0,0,.12)}\n.mat-calendar-body-label{color:rgba(0,0,0,.54)}\n.mat-calendar-body-cell-content{color:rgba(0,0,0,.87);border-color:transparent}\n.mat-calendar-body-disabled>.mat-calendar-body-cell-content:not(.mat-calendar-body-selected){color:rgba(0,0,0,.38)}\n.cdk-keyboard-focused .mat-calendar-body-active>.mat-calendar-body-cell-content:not(.mat-calendar-body-selected),.cdk-program-focused .mat-calendar-body-active>.mat-calendar-body-cell-content:not(.mat-calendar-body-selected),.mat-calendar-body-cell:not(.mat-calendar-body-disabled):hover>.mat-calendar-body-cell-content:not(.mat-calendar-body-selected){background-color:rgba(0,0,0,.04)}\n.mat-calendar-body-today:not(.mat-calendar-body-selected){border-color:rgba(0,0,0,.38)}\n.mat-calendar-body-disabled>.mat-calendar-body-today:not(.mat-calendar-body-selected){border-color:rgba(0,0,0,.18)}\n.mat-calendar-body-selected{background-color:#3f51b5;color:#fff}\n.mat-calendar-body-disabled>.mat-calendar-body-selected{background-color:rgba(63,81,181,.4)}\n.mat-calendar-body-today.mat-calendar-body-selected{box-shadow:inset 0 0 0 1px #fff}\n.mat-datepicker-content{box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12);background-color:#fff;color:rgba(0,0,0,.87)}\n.mat-datepicker-content.mat-accent .mat-calendar-body-selected{background-color:#ff4081;color:#fff}\n.mat-datepicker-content.mat-accent .mat-calendar-body-disabled>.mat-calendar-body-selected{background-color:rgba(255,64,129,.4)}\n.mat-datepicker-content.mat-accent .mat-calendar-body-today.mat-calendar-body-selected{box-shadow:inset 0 0 0 1px #fff}\n.mat-datepicker-content.mat-warn .mat-calendar-body-selected{background-color:#f44336;color:#fff}\n.mat-datepicker-content.mat-warn .mat-calendar-body-disabled>.mat-calendar-body-selected{background-color:rgba(244,67,54,.4)}\n.mat-datepicker-content.mat-warn .mat-calendar-body-today.mat-calendar-body-selected{box-shadow:inset 0 0 0 1px #fff}\n.mat-datepicker-content-touch{box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}\n.mat-datepicker-toggle-active{color:#3f51b5}\n.mat-datepicker-toggle-active.mat-accent{color:#ff4081}\n.mat-datepicker-toggle-active.mat-warn{color:#f44336}\n.mat-dialog-container{box-shadow:0 11px 15px -7px rgba(0,0,0,.2),0 24px 38px 3px rgba(0,0,0,.14),0 9px 46px 8px rgba(0,0,0,.12);background:#fff;color:rgba(0,0,0,.87)}\n.mat-divider{border-top-color:rgba(0,0,0,.12)}\n.mat-divider-vertical{border-right-color:rgba(0,0,0,.12)}\n.mat-expansion-panel{background:#fff;color:rgba(0,0,0,.87)}\n.mat-expansion-panel:not([class*=mat-elevation-z]){box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}\n.mat-action-row{border-top-color:rgba(0,0,0,.12)}\n.mat-expansion-panel:not(.mat-expanded) .mat-expansion-panel-header:not([aria-disabled=true]).cdk-keyboard-focused,.mat-expansion-panel:not(.mat-expanded) .mat-expansion-panel-header:not([aria-disabled=true]).cdk-program-focused,.mat-expansion-panel:not(.mat-expanded) .mat-expansion-panel-header:not([aria-disabled=true]):hover{background:rgba(0,0,0,.04)}\n@media (hover:none){.mat-expansion-panel:not(.mat-expanded):not([aria-disabled=true]) .mat-expansion-panel-header:hover{background:#fff}}\n.mat-expansion-panel-header-title{color:rgba(0,0,0,.87)}\n.mat-expansion-indicator::after,.mat-expansion-panel-header-description{color:rgba(0,0,0,.54)}\n.mat-expansion-panel-header[aria-disabled=true]{color:rgba(0,0,0,.26)}\n.mat-expansion-panel-header[aria-disabled=true] .mat-expansion-panel-header-description,.mat-expansion-panel-header[aria-disabled=true] .mat-expansion-panel-header-title{color:inherit}\n.mat-form-field-label{color:rgba(0,0,0,.6)}\n.mat-hint{color:rgba(0,0,0,.6)}\n.mat-form-field.mat-focused .mat-form-field-label{color:#3f51b5}\n.mat-form-field.mat-focused .mat-form-field-label.mat-accent{color:#ff4081}\n.mat-form-field.mat-focused .mat-form-field-label.mat-warn{color:#f44336}\n.mat-focused .mat-form-field-required-marker{color:#ff4081}\n.mat-form-field-ripple{background-color:rgba(0,0,0,.87)}\n.mat-form-field.mat-focused .mat-form-field-ripple{background-color:#3f51b5}\n.mat-form-field.mat-focused .mat-form-field-ripple.mat-accent{background-color:#ff4081}\n.mat-form-field.mat-focused .mat-form-field-ripple.mat-warn{background-color:#f44336}\n.mat-form-field-type-mat-native-select.mat-focused:not(.mat-form-field-invalid) .mat-form-field-infix::after{color:#3f51b5}\n.mat-form-field-type-mat-native-select.mat-focused:not(.mat-form-field-invalid).mat-accent .mat-form-field-infix::after{color:#ff4081}\n.mat-form-field-type-mat-native-select.mat-focused:not(.mat-form-field-invalid).mat-warn .mat-form-field-infix::after{color:#f44336}\n.mat-form-field.mat-form-field-invalid .mat-form-field-label{color:#f44336}\n.mat-form-field.mat-form-field-invalid .mat-form-field-label .mat-form-field-required-marker,.mat-form-field.mat-form-field-invalid .mat-form-field-label.mat-accent{color:#f44336}\n.mat-form-field.mat-form-field-invalid .mat-form-field-ripple,.mat-form-field.mat-form-field-invalid .mat-form-field-ripple.mat-accent{background-color:#f44336}\n.mat-error{color:#f44336}\n.mat-form-field-appearance-legacy .mat-form-field-label{color:rgba(0,0,0,.54)}\n.mat-form-field-appearance-legacy .mat-hint{color:rgba(0,0,0,.54)}\n.mat-form-field-appearance-legacy .mat-form-field-underline{background-color:rgba(0,0,0,.42)}\n.mat-form-field-appearance-legacy.mat-form-field-disabled .mat-form-field-underline{background-image:linear-gradient(to right,rgba(0,0,0,.42) 0,rgba(0,0,0,.42) 33%,transparent 0);background-size:4px 100%;background-repeat:repeat-x}\n.mat-form-field-appearance-standard .mat-form-field-underline{background-color:rgba(0,0,0,.42)}\n.mat-form-field-appearance-standard.mat-form-field-disabled .mat-form-field-underline{background-image:linear-gradient(to right,rgba(0,0,0,.42) 0,rgba(0,0,0,.42) 33%,transparent 0);background-size:4px 100%;background-repeat:repeat-x}\n.mat-form-field-appearance-fill .mat-form-field-flex{background-color:rgba(0,0,0,.04)}\n.mat-form-field-appearance-fill.mat-form-field-disabled .mat-form-field-flex{background-color:rgba(0,0,0,.02)}\n.mat-form-field-appearance-fill .mat-form-field-underline::before{background-color:rgba(0,0,0,.42)}\n.mat-form-field-appearance-fill.mat-form-field-disabled .mat-form-field-label{color:rgba(0,0,0,.38)}\n.mat-form-field-appearance-fill.mat-form-field-disabled .mat-form-field-underline::before{background-color:transparent}\n.mat-form-field-appearance-outline .mat-form-field-outline{color:rgba(0,0,0,.12)}\n.mat-form-field-appearance-outline .mat-form-field-outline-thick{color:rgba(0,0,0,.87)}\n.mat-form-field-appearance-outline.mat-focused .mat-form-field-outline-thick{color:#3f51b5}\n.mat-form-field-appearance-outline.mat-focused.mat-accent .mat-form-field-outline-thick{color:#ff4081}\n.mat-form-field-appearance-outline.mat-focused.mat-warn .mat-form-field-outline-thick{color:#f44336}\n.mat-form-field-appearance-outline.mat-form-field-invalid.mat-form-field-invalid .mat-form-field-outline-thick{color:#f44336}\n.mat-form-field-appearance-outline.mat-form-field-disabled .mat-form-field-label{color:rgba(0,0,0,.38)}\n.mat-form-field-appearance-outline.mat-form-field-disabled .mat-form-field-outline{color:rgba(0,0,0,.06)}\n.mat-icon.mat-primary{color:#3f51b5}\n.mat-icon.mat-accent{color:#ff4081}\n.mat-icon.mat-warn{color:#f44336}\n.mat-form-field-type-mat-native-select .mat-form-field-infix::after{color:rgba(0,0,0,.54)}\n.mat-form-field-type-mat-native-select.mat-form-field-disabled .mat-form-field-infix::after,.mat-input-element:disabled{color:rgba(0,0,0,.38)}\n.mat-input-element{caret-color:#3f51b5}\n.mat-input-element::-webkit-input-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element::-moz-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element:-ms-input-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element::-ms-input-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element::placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element::-moz-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element::-webkit-input-placeholder{color:rgba(0,0,0,.42)}\n.mat-input-element:-ms-input-placeholder{color:rgba(0,0,0,.42)}\n.mat-accent .mat-input-element{caret-color:#ff4081}\n.mat-form-field-invalid .mat-input-element,.mat-warn .mat-input-element{caret-color:#f44336}\n.mat-form-field-type-mat-native-select.mat-form-field-invalid .mat-form-field-infix::after{color:#f44336}\n.mat-list-base .mat-list-item{color:rgba(0,0,0,.87)}\n.mat-list-base .mat-list-option{color:rgba(0,0,0,.87)}\n.mat-list-base .mat-subheader{color:rgba(0,0,0,.54)}\n.mat-list-item-disabled{background-color:#eee}\n.mat-action-list .mat-list-item:focus,.mat-action-list .mat-list-item:hover,.mat-list-option:focus,.mat-list-option:hover,.mat-nav-list .mat-list-item:focus,.mat-nav-list .mat-list-item:hover{background:rgba(0,0,0,.04)}\n.mat-menu-panel{background:#fff}\n.mat-menu-panel:not([class*=mat-elevation-z]){box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12)}\n.mat-menu-item{background:0 0;color:rgba(0,0,0,.87)}\n.mat-menu-item[disabled],.mat-menu-item[disabled]::after{color:rgba(0,0,0,.38)}\n.mat-menu-item .mat-icon-no-color,.mat-menu-item-submenu-trigger::after{color:rgba(0,0,0,.54)}\n.mat-menu-item-highlighted:not([disabled]),.mat-menu-item.cdk-keyboard-focused:not([disabled]),.mat-menu-item.cdk-program-focused:not([disabled]),.mat-menu-item:hover:not([disabled]){background:rgba(0,0,0,.04)}\n.mat-paginator{background:#fff}\n.mat-paginator,.mat-paginator-page-size .mat-select-trigger{color:rgba(0,0,0,.54)}\n.mat-paginator-decrement,.mat-paginator-increment{border-top:2px solid rgba(0,0,0,.54);border-right:2px solid rgba(0,0,0,.54)}\n.mat-paginator-first,.mat-paginator-last{border-top:2px solid rgba(0,0,0,.54)}\n.mat-icon-button[disabled] .mat-paginator-decrement,.mat-icon-button[disabled] .mat-paginator-first,.mat-icon-button[disabled] .mat-paginator-increment,.mat-icon-button[disabled] .mat-paginator-last{border-color:rgba(0,0,0,.38)}\n.mat-progress-bar-background{fill:#c5cae9}\n.mat-progress-bar-buffer{background-color:#c5cae9}\n.mat-progress-bar-fill::after{background-color:#3f51b5}\n.mat-progress-bar.mat-accent .mat-progress-bar-background{fill:#ff80ab}\n.mat-progress-bar.mat-accent .mat-progress-bar-buffer{background-color:#ff80ab}\n.mat-progress-bar.mat-accent .mat-progress-bar-fill::after{background-color:#ff4081}\n.mat-progress-bar.mat-warn .mat-progress-bar-background{fill:#ffcdd2}\n.mat-progress-bar.mat-warn .mat-progress-bar-buffer{background-color:#ffcdd2}\n.mat-progress-bar.mat-warn .mat-progress-bar-fill::after{background-color:#f44336}\n.mat-progress-spinner circle,.mat-spinner circle{stroke:#3f51b5}\n.mat-progress-spinner.mat-accent circle,.mat-spinner.mat-accent circle{stroke:#ff4081}\n.mat-progress-spinner.mat-warn circle,.mat-spinner.mat-warn circle{stroke:#f44336}\n.mat-radio-outer-circle{border-color:rgba(0,0,0,.54)}\n.mat-radio-button.mat-primary.mat-radio-checked .mat-radio-outer-circle{border-color:#3f51b5}\n.mat-radio-button.mat-primary .mat-radio-inner-circle,.mat-radio-button.mat-primary .mat-radio-ripple .mat-ripple-element:not(.mat-radio-persistent-ripple),.mat-radio-button.mat-primary.mat-radio-checked .mat-radio-persistent-ripple,.mat-radio-button.mat-primary:active .mat-radio-persistent-ripple{background-color:#3f51b5}\n.mat-radio-button.mat-accent.mat-radio-checked .mat-radio-outer-circle{border-color:#ff4081}\n.mat-radio-button.mat-accent .mat-radio-inner-circle,.mat-radio-button.mat-accent .mat-radio-ripple .mat-ripple-element:not(.mat-radio-persistent-ripple),.mat-radio-button.mat-accent.mat-radio-checked .mat-radio-persistent-ripple,.mat-radio-button.mat-accent:active .mat-radio-persistent-ripple{background-color:#ff4081}\n.mat-radio-button.mat-warn.mat-radio-checked .mat-radio-outer-circle{border-color:#f44336}\n.mat-radio-button.mat-warn .mat-radio-inner-circle,.mat-radio-button.mat-warn .mat-radio-ripple .mat-ripple-element:not(.mat-radio-persistent-ripple),.mat-radio-button.mat-warn.mat-radio-checked .mat-radio-persistent-ripple,.mat-radio-button.mat-warn:active .mat-radio-persistent-ripple{background-color:#f44336}\n.mat-radio-button.mat-radio-disabled .mat-radio-outer-circle,.mat-radio-button.mat-radio-disabled.mat-radio-checked .mat-radio-outer-circle{border-color:rgba(0,0,0,.38)}\n.mat-radio-button.mat-radio-disabled .mat-radio-inner-circle,.mat-radio-button.mat-radio-disabled .mat-radio-ripple .mat-ripple-element{background-color:rgba(0,0,0,.38)}\n.mat-radio-button.mat-radio-disabled .mat-radio-label-content{color:rgba(0,0,0,.38)}\n.mat-radio-button .mat-ripple-element{background-color:#000}\n.mat-select-value{color:rgba(0,0,0,.87)}\n.mat-select-placeholder{color:rgba(0,0,0,.42)}\n.mat-select-disabled .mat-select-value{color:rgba(0,0,0,.38)}\n.mat-select-arrow{color:rgba(0,0,0,.54)}\n.mat-select-panel{background:#fff}\n.mat-select-panel:not([class*=mat-elevation-z]){box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12)}\n.mat-select-panel .mat-option.mat-selected:not(.mat-option-multiple){background:rgba(0,0,0,.12)}\n.mat-form-field.mat-focused.mat-primary .mat-select-arrow{color:#3f51b5}\n.mat-form-field.mat-focused.mat-accent .mat-select-arrow{color:#ff4081}\n.mat-form-field.mat-focused.mat-warn .mat-select-arrow{color:#f44336}\n.mat-form-field .mat-select.mat-select-invalid .mat-select-arrow{color:#f44336}\n.mat-form-field .mat-select.mat-select-disabled .mat-select-arrow{color:rgba(0,0,0,.38)}\n.mat-drawer-container{background-color:#fafafa;color:rgba(0,0,0,.87)}\n.mat-drawer{background-color:#fff;color:rgba(0,0,0,.87)}\n.mat-drawer.mat-drawer-push{background-color:#fff}\n.mat-drawer:not(.mat-drawer-side){box-shadow:0 8px 10px -5px rgba(0,0,0,.2),0 16px 24px 2px rgba(0,0,0,.14),0 6px 30px 5px rgba(0,0,0,.12)}\n.mat-drawer-side{border-right:solid 1px rgba(0,0,0,.12)}\n.mat-drawer-side.mat-drawer-end{border-left:solid 1px rgba(0,0,0,.12);border-right:none}\n[dir=rtl] .mat-drawer-side{border-left:solid 1px rgba(0,0,0,.12);border-right:none}\n[dir=rtl] .mat-drawer-side.mat-drawer-end{border-left:none;border-right:solid 1px rgba(0,0,0,.12)}\n.mat-drawer-backdrop.mat-drawer-shown{background-color:rgba(0,0,0,.6)}\n.mat-slide-toggle.mat-checked .mat-slide-toggle-thumb{background-color:#ff4081}\n.mat-slide-toggle.mat-checked .mat-slide-toggle-bar{background-color:rgba(255,64,129,.54)}\n.mat-slide-toggle.mat-checked .mat-ripple-element{background-color:#ff4081}\n.mat-slide-toggle.mat-primary.mat-checked .mat-slide-toggle-thumb{background-color:#3f51b5}\n.mat-slide-toggle.mat-primary.mat-checked .mat-slide-toggle-bar{background-color:rgba(63,81,181,.54)}\n.mat-slide-toggle.mat-primary.mat-checked .mat-ripple-element{background-color:#3f51b5}\n.mat-slide-toggle.mat-warn.mat-checked .mat-slide-toggle-thumb{background-color:#f44336}\n.mat-slide-toggle.mat-warn.mat-checked .mat-slide-toggle-bar{background-color:rgba(244,67,54,.54)}\n.mat-slide-toggle.mat-warn.mat-checked .mat-ripple-element{background-color:#f44336}\n.mat-slide-toggle:not(.mat-checked) .mat-ripple-element{background-color:#000}\n.mat-slide-toggle-thumb{box-shadow:0 2px 1px -1px rgba(0,0,0,.2),0 1px 1px 0 rgba(0,0,0,.14),0 1px 3px 0 rgba(0,0,0,.12);background-color:#fafafa}\n.mat-slide-toggle-bar{background-color:rgba(0,0,0,.38)}\n.mat-slider-track-background{background-color:rgba(0,0,0,.26)}\n.mat-primary .mat-slider-thumb,.mat-primary .mat-slider-thumb-label,.mat-primary .mat-slider-track-fill{background-color:#3f51b5}\n.mat-primary .mat-slider-thumb-label-text{color:#fff}\n.mat-accent .mat-slider-thumb,.mat-accent .mat-slider-thumb-label,.mat-accent .mat-slider-track-fill{background-color:#ff4081}\n.mat-accent .mat-slider-thumb-label-text{color:#fff}\n.mat-warn .mat-slider-thumb,.mat-warn .mat-slider-thumb-label,.mat-warn .mat-slider-track-fill{background-color:#f44336}\n.mat-warn .mat-slider-thumb-label-text{color:#fff}\n.mat-slider-focus-ring{background-color:rgba(255,64,129,.2)}\n.cdk-focused .mat-slider-track-background,.mat-slider:hover .mat-slider-track-background{background-color:rgba(0,0,0,.38)}\n.mat-slider-disabled .mat-slider-thumb,.mat-slider-disabled .mat-slider-track-background,.mat-slider-disabled .mat-slider-track-fill{background-color:rgba(0,0,0,.26)}\n.mat-slider-disabled:hover .mat-slider-track-background{background-color:rgba(0,0,0,.26)}\n.mat-slider-min-value .mat-slider-focus-ring{background-color:rgba(0,0,0,.12)}\n.mat-slider-min-value.mat-slider-thumb-label-showing .mat-slider-thumb,.mat-slider-min-value.mat-slider-thumb-label-showing .mat-slider-thumb-label{background-color:rgba(0,0,0,.87)}\n.mat-slider-min-value.mat-slider-thumb-label-showing.cdk-focused .mat-slider-thumb,.mat-slider-min-value.mat-slider-thumb-label-showing.cdk-focused .mat-slider-thumb-label{background-color:rgba(0,0,0,.26)}\n.mat-slider-min-value:not(.mat-slider-thumb-label-showing) .mat-slider-thumb{border-color:rgba(0,0,0,.26);background-color:transparent}\n.mat-slider-min-value:not(.mat-slider-thumb-label-showing).cdk-focused .mat-slider-thumb,.mat-slider-min-value:not(.mat-slider-thumb-label-showing):hover .mat-slider-thumb{border-color:rgba(0,0,0,.38)}\n.mat-slider-min-value:not(.mat-slider-thumb-label-showing).cdk-focused.mat-slider-disabled .mat-slider-thumb,.mat-slider-min-value:not(.mat-slider-thumb-label-showing):hover.mat-slider-disabled .mat-slider-thumb{border-color:rgba(0,0,0,.26)}\n.mat-slider-has-ticks .mat-slider-wrapper::after{border-color:rgba(0,0,0,.7)}\n.mat-slider-horizontal .mat-slider-ticks{background-image:repeating-linear-gradient(to right,rgba(0,0,0,.7),rgba(0,0,0,.7) 2px,transparent 0,transparent);background-image:-moz-repeating-linear-gradient(.0001deg,rgba(0,0,0,.7),rgba(0,0,0,.7) 2px,transparent 0,transparent)}\n.mat-slider-vertical .mat-slider-ticks{background-image:repeating-linear-gradient(to bottom,rgba(0,0,0,.7),rgba(0,0,0,.7) 2px,transparent 0,transparent)}\n.mat-step-header.cdk-keyboard-focused,.mat-step-header.cdk-program-focused,.mat-step-header:hover{background-color:rgba(0,0,0,.04)}\n@media (hover:none){.mat-step-header:hover{background:0 0}}\n.mat-step-header .mat-step-label,.mat-step-header .mat-step-optional{color:rgba(0,0,0,.54)}\n.mat-step-header .mat-step-icon{background-color:rgba(0,0,0,.54);color:#fff}\n.mat-step-header .mat-step-icon-selected,.mat-step-header .mat-step-icon-state-done,.mat-step-header .mat-step-icon-state-edit{background-color:#3f51b5;color:#fff}\n.mat-step-header .mat-step-icon-state-error{background-color:transparent;color:#f44336}\n.mat-step-header .mat-step-label.mat-step-label-active{color:rgba(0,0,0,.87)}\n.mat-step-header .mat-step-label.mat-step-label-error{color:#f44336}\n.mat-stepper-horizontal,.mat-stepper-vertical{background-color:#fff}\n.mat-stepper-vertical-line::before{border-left-color:rgba(0,0,0,.12)}\n.mat-horizontal-stepper-header::after,.mat-horizontal-stepper-header::before,.mat-stepper-horizontal-line{border-top-color:rgba(0,0,0,.12)}\n.mat-sort-header-arrow{color:#757575}\n.mat-tab-header,.mat-tab-nav-bar{border-bottom:1px solid rgba(0,0,0,.12)}\n.mat-tab-group-inverted-header .mat-tab-header,.mat-tab-group-inverted-header .mat-tab-nav-bar{border-top:1px solid rgba(0,0,0,.12);border-bottom:none}\n.mat-tab-label,.mat-tab-link{color:rgba(0,0,0,.87)}\n.mat-tab-label.mat-tab-disabled,.mat-tab-link.mat-tab-disabled{color:rgba(0,0,0,.38)}\n.mat-tab-header-pagination-chevron{border-color:rgba(0,0,0,.87)}\n.mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron{border-color:rgba(0,0,0,.38)}\n.mat-tab-group[class*=mat-background-] .mat-tab-header,.mat-tab-nav-bar[class*=mat-background-]{border-bottom:none;border-top:none}\n.mat-tab-group.mat-primary .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-primary .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-primary .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-primary .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-primary .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-primary .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-primary .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-primary .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(197,202,233,.3)}\n.mat-tab-group.mat-primary .mat-ink-bar,.mat-tab-nav-bar.mat-primary .mat-ink-bar{background-color:#3f51b5}\n.mat-tab-group.mat-primary.mat-background-primary .mat-ink-bar,.mat-tab-nav-bar.mat-primary.mat-background-primary .mat-ink-bar{background-color:#fff}\n.mat-tab-group.mat-accent .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-accent .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-accent .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-accent .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-accent .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-accent .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-accent .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-accent .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(255,128,171,.3)}\n.mat-tab-group.mat-accent .mat-ink-bar,.mat-tab-nav-bar.mat-accent .mat-ink-bar{background-color:#ff4081}\n.mat-tab-group.mat-accent.mat-background-accent .mat-ink-bar,.mat-tab-nav-bar.mat-accent.mat-background-accent .mat-ink-bar{background-color:#fff}\n.mat-tab-group.mat-warn .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-warn .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-warn .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-warn .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-warn .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-warn .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-warn .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-warn .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(255,205,210,.3)}\n.mat-tab-group.mat-warn .mat-ink-bar,.mat-tab-nav-bar.mat-warn .mat-ink-bar{background-color:#f44336}\n.mat-tab-group.mat-warn.mat-background-warn .mat-ink-bar,.mat-tab-nav-bar.mat-warn.mat-background-warn .mat-ink-bar{background-color:#fff}\n.mat-tab-group.mat-background-primary .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-primary .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-primary .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-primary .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-primary .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-primary .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-primary .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-primary .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(197,202,233,.3)}\n.mat-tab-group.mat-background-primary .mat-tab-header,.mat-tab-group.mat-background-primary .mat-tab-links,.mat-tab-nav-bar.mat-background-primary .mat-tab-header,.mat-tab-nav-bar.mat-background-primary .mat-tab-links{background-color:#3f51b5}\n.mat-tab-group.mat-background-primary .mat-tab-label,.mat-tab-group.mat-background-primary .mat-tab-link,.mat-tab-nav-bar.mat-background-primary .mat-tab-label,.mat-tab-nav-bar.mat-background-primary .mat-tab-link{color:#fff}\n.mat-tab-group.mat-background-primary .mat-tab-label.mat-tab-disabled,.mat-tab-group.mat-background-primary .mat-tab-link.mat-tab-disabled,.mat-tab-nav-bar.mat-background-primary .mat-tab-label.mat-tab-disabled,.mat-tab-nav-bar.mat-background-primary .mat-tab-link.mat-tab-disabled{color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-primary .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-primary .mat-tab-header-pagination-chevron{border-color:#fff}\n.mat-tab-group.mat-background-primary .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-primary .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron{border-color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-primary .mat-ripple-element,.mat-tab-nav-bar.mat-background-primary .mat-ripple-element{background-color:rgba(255,255,255,.12)}\n.mat-tab-group.mat-background-accent .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-accent .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-accent .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-accent .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-accent .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-accent .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-accent .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-accent .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(255,128,171,.3)}\n.mat-tab-group.mat-background-accent .mat-tab-header,.mat-tab-group.mat-background-accent .mat-tab-links,.mat-tab-nav-bar.mat-background-accent .mat-tab-header,.mat-tab-nav-bar.mat-background-accent .mat-tab-links{background-color:#ff4081}\n.mat-tab-group.mat-background-accent .mat-tab-label,.mat-tab-group.mat-background-accent .mat-tab-link,.mat-tab-nav-bar.mat-background-accent .mat-tab-label,.mat-tab-nav-bar.mat-background-accent .mat-tab-link{color:#fff}\n.mat-tab-group.mat-background-accent .mat-tab-label.mat-tab-disabled,.mat-tab-group.mat-background-accent .mat-tab-link.mat-tab-disabled,.mat-tab-nav-bar.mat-background-accent .mat-tab-label.mat-tab-disabled,.mat-tab-nav-bar.mat-background-accent .mat-tab-link.mat-tab-disabled{color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-accent .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-accent .mat-tab-header-pagination-chevron{border-color:#fff}\n.mat-tab-group.mat-background-accent .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-accent .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron{border-color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-accent .mat-ripple-element,.mat-tab-nav-bar.mat-background-accent .mat-ripple-element{background-color:rgba(255,255,255,.12)}\n.mat-tab-group.mat-background-warn .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-warn .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-warn .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-group.mat-background-warn .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-warn .mat-tab-label.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-warn .mat-tab-label.cdk-program-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-warn .mat-tab-link.cdk-keyboard-focused:not(.mat-tab-disabled),.mat-tab-nav-bar.mat-background-warn .mat-tab-link.cdk-program-focused:not(.mat-tab-disabled){background-color:rgba(255,205,210,.3)}\n.mat-tab-group.mat-background-warn .mat-tab-header,.mat-tab-group.mat-background-warn .mat-tab-links,.mat-tab-nav-bar.mat-background-warn .mat-tab-header,.mat-tab-nav-bar.mat-background-warn .mat-tab-links{background-color:#f44336}\n.mat-tab-group.mat-background-warn .mat-tab-label,.mat-tab-group.mat-background-warn .mat-tab-link,.mat-tab-nav-bar.mat-background-warn .mat-tab-label,.mat-tab-nav-bar.mat-background-warn .mat-tab-link{color:#fff}\n.mat-tab-group.mat-background-warn .mat-tab-label.mat-tab-disabled,.mat-tab-group.mat-background-warn .mat-tab-link.mat-tab-disabled,.mat-tab-nav-bar.mat-background-warn .mat-tab-label.mat-tab-disabled,.mat-tab-nav-bar.mat-background-warn .mat-tab-link.mat-tab-disabled{color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-warn .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-warn .mat-tab-header-pagination-chevron{border-color:#fff}\n.mat-tab-group.mat-background-warn .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron,.mat-tab-nav-bar.mat-background-warn .mat-tab-header-pagination-disabled .mat-tab-header-pagination-chevron{border-color:rgba(255,255,255,.4)}\n.mat-tab-group.mat-background-warn .mat-ripple-element,.mat-tab-nav-bar.mat-background-warn .mat-ripple-element{background-color:rgba(255,255,255,.12)}\n.mat-toolbar{background:#f5f5f5;color:rgba(0,0,0,.87)}\n.mat-toolbar.mat-primary{background:#3f51b5;color:#fff}\n.mat-toolbar.mat-accent{background:#ff4081;color:#fff}\n.mat-toolbar.mat-warn{background:#f44336;color:#fff}\n.mat-toolbar .mat-focused .mat-form-field-ripple,.mat-toolbar .mat-form-field-ripple,.mat-toolbar .mat-form-field-underline{background-color:currentColor}\n.mat-toolbar .mat-focused .mat-form-field-label,.mat-toolbar .mat-form-field-label,.mat-toolbar .mat-form-field.mat-focused .mat-select-arrow,.mat-toolbar .mat-select-arrow,.mat-toolbar .mat-select-value{color:inherit}\n.mat-toolbar .mat-input-element{caret-color:currentColor}\n.mat-tooltip{background:rgba(97,97,97,.9)}\n.mat-tree{background:#fff}\n.mat-nested-tree-node,.mat-tree-node{color:rgba(0,0,0,.87)}\n.mat-snack-bar-container{color:rgba(255,255,255,.7);background:#323232;box-shadow:0 3px 5px -1px rgba(0,0,0,.2),0 6px 10px 0 rgba(0,0,0,.14),0 1px 18px 0 rgba(0,0,0,.12)}\n.mat-simple-snackbar-action{color:#ff4081}\nbody {\n  padding: 0 15px 15px 15px;\n  margin-top: 0;\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif;\n}\n.noselect {\n  -webkit-touch-callout: none;\n  /* iOS Safari */\n  -webkit-user-select: none;\n  /* Safari */\n  /* Konqueror HTML */\n  -moz-user-select: none;\n  /* Firefox */\n  -ms-user-select: none;\n  /* Internet Explorer/Edge */\n  user-select: none;\n  /* Non-prefixed version, currently\n     supported by Chrome and Opera */\n}\n.controlsContainer {\n  background-color: #ddd;\n  text-align: right;\n  display: block;\n}\n.controlsContainer ul {\n  margin: 0;\n}\n.controlsContainer .control-sections > li {\n  list-style: none;\n  display: inline-block;\n  border-left: 1px solid #c9c9c9;\n  padding: 0 5px 0 5px;\n  position: relative;\n}\n.controlsContainer .control-sections > li .section-label {\n  font-size: 8pt;\n  top: -13px;\n  position: absolute;\n  border-color: white;\n  border-style: solid;\n  border-width: 1px 1px 0 1px;\n  padding: 0 5px;\n  background-color: #ddd;\n  border-radius: 2px 2px 0 0;\n  text-align: center;\n  color: #555;\n  cursor: default;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  white-space: nowrap;\n}\n.controlsContainer .control-sections > li .control-row-item {\n  display: inline-block;\n  position: relative;\n  height: 34px;\n}\n.controlsContainer .control-sections > li .control-row-item .control-row-button {\n  border-radius: 3px;\n  padding: 5px;\n  height: 24px;\n  cursor: pointer;\n}\n.controlsContainer .control-sections > li .control-row-item .control-row-button:hover {\n  background-color: #d0d0d0;\n}\n.controlsContainer .control-sections > li .control-row-item .control-row-button.dropdown::after {\n  font-size: 5pt;\n  content: \"▼\";\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container {\n  border: 1px solid black;\n  background-color: white;\n  box-shadow: 10px 10px 5px rgba(0, 0, 0, 0.5);\n  position: absolute;\n  z-index: 100;\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.left {\n  right: 0;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.inputfield {\n  width: 150px;\n  padding: 0px 10px;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.inputfield mat-form-field {\n  width: 100%;\n}\n.controlsContainer .control-sections > li .control-row-item .dropdown-container.inputfield mat-form-field:first-child {\n  padding-top: 5px;\n}\n.checkbox-custom {\n  opacity: 0;\n  position: absolute;\n}\n.checkbox-custom, .checkbox-custom-label {\n  display: inline-block;\n  vertical-align: middle;\n  margin: 5px;\n  cursor: pointer;\n}\n.checkbox-custom-label {\n  position: relative;\n}\n.checkbox-custom-label.disabled {\n  color: rgba(0, 0, 0, 0.46);\n}\n.checkbox-custom + .checkbox-custom-label:before {\n  content: \"\";\n  background: #fff;\n  border: 3px solid #ddd;\n  display: inline-block;\n  vertical-align: middle;\n  width: 10px;\n  height: 10px;\n  padding: 2px;\n  margin-right: 5px;\n  text-align: center;\n}\n.checkbox-custom:checked + .checkbox-custom-label:before {\n  background: #60c5ff;\n  box-shadow: inset 0px 0px 0px 1px #60c5ff;\n}\n.checkbox-custom:checked:disabled + .checkbox-custom-label:before {\n  background: #b0b0b0;\n  box-shadow: inset 0px 0px 0px 1px #b0b0b0;\n}\n.cell {\n  width: 100%;\n  display: inline-block;\n  margin-top: -2px;\n  font-size: 12px;\n  box-sizing: border-box;\n  border: 1px solid rgba(0, 0, 0, 0.05);\n}\n.cell:not(.mini) {\n  padding: 6.5px 2px;\n  line-height: 13px;\n}\n.cell.mini {\n  width: 8px;\n  height: 8px;\n  margin-right: 2px;\n  margin-top: 2px;\n  border-color: #b8b8b8;\n}\n.cell.has-background:not(.highlight) {\n  border-color: white;\n}\n.cell.editing {\n  border-color: black;\n}\n.cell.header {\n  font-weight: bold;\n}\n.cell.header:hover {\n  color: #60c5ff;\n}\n.cell.header.mini {\n  background-color: black;\n  border-color: black;\n}\n.cell.highlight {\n  background: #60c5ff;\n}\n.cell.highlight span {\n  color: black;\n}\n.cell.itemcount {\n  border: 1px solid;\n  border-color: rgba(255, 255, 255, 0) rgba(255, 255, 255, 0) black rgba(255, 255, 255, 0);\n}\n.cell.disabled:not(.highlight) span {\n  color: #b8b8b8;\n}\n.cell.disabled:not(.highlight).compact {\n  background: url(\"data:image/svg+xml;utf8, <svg xmlns='http://www.w3.org/2000/svg' version='1.1' preserveAspectRatio='none' viewBox='0 0 10 10'><path d='M 10 0 L 0 10' fill='none' stroke='#cccccc' stroke-width='1' /></svg>\");\n}\n.cell.disabled:not(.highlight).mini {\n  background: url(\"data:image/svg+xml;utf8, <svg xmlns='http://www.w3.org/2000/svg' version='1.1' preserveAspectRatio='none' viewBox='0 0 10 10'><path d='M 10 0 L 0 10' fill='none' stroke='#b8b8b8' stroke-width='1' /></svg>\");\n}\n.cell.has-comment:not(.disabled) span {\n  border-bottom: 2px solid transparent;\n}\n.link {\n  cursor: pointer;\n}"

/***/ }),

/***/ "./src/app/datatable/technique-cell/technique-cell.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/datatable/technique-cell/technique-cell.component.ts ***!
  \**********************************************************************/
/*! exports provided: TechniqueCellComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TechniqueCellComponent", function() { return TechniqueCellComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _viewmodels_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../viewmodels.service */ "./src/app/viewmodels.service.ts");
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../config.service */ "./src/app/config.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var TechniqueCellComponent = /** @class */ (function () {
    function TechniqueCellComponent(configService) {
        this.configService = configService;
        this.highlight = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"](); // emit with the highlighted technique, or null to unhighlight
        this.leftclick = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"](); // emit with the selected technique and the modifier keys
        this.rightclick = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"](); //emit with the technique which was right-clicked
    }
    TechniqueCellComponent.prototype.ngOnInit = function () {
    };
    // events to pass to parent component
    TechniqueCellComponent.prototype.onHighlight = function () {
        this.highlight.emit(this.technique);
    };
    TechniqueCellComponent.prototype.onUnhighlight = function () {
        this.highlight.emit(null);
    };
    TechniqueCellComponent.prototype.onLeftClick = function (event) {
        this.leftclick.emit({
            "technique": this.technique,
            // modifier keys
            "shift": event.shiftKey,
            "ctrl": event.ctrlKey,
            "meta": event.metaKey,
            // position of event on page
            "x": event.pageX,
            "y": event.pageY
        });
    };
    TechniqueCellComponent.prototype.onRightClick = function (event) {
        this.rightclick.emit({
            "technique": this.technique,
            // modifier keys
            "shift": event.shiftKey,
            "ctrl": event.ctrlKey,
            "meta": event.metaKey,
            // position of event on page
            "x": event.pageX,
            "y": event.pageY
        });
    };
    /**
     * Return css classes for a technique
     * @param  {technique} technique the technique to get the class of
     * @param  {boolean}   mini is it the minitable?
     * @return {string}               the classes the technique should currently have
     */
    TechniqueCellComponent.prototype.getClass = function () {
        var theclass = 'link noselect cell';
        if (!this.viewModel.getTechniqueVM(this.technique.technique_tactic_union_id).enabled)
            theclass += " disabled";
        // else theclass += " " + this.viewModel.getTechniqueVM(technique.technique_tactic_union_id).color
        if (this.viewModel.isTechniqueSelected(this.technique))
            theclass += " editing";
        if (this.viewModel.highlightedTechnique && this.viewModel.highlightedTechnique.technique_id == this.technique.technique_id) {
            if (this.viewModel.selectTechniquesAcrossTactics) {
                theclass += " highlight";
            }
            else if (this.viewModel.hoverTactic == this.technique.tactic) {
                theclass += " highlight";
            }
            //console.log(this.viewModel.hoverTactic);
        }
        theclass += [" full", " compact", " mini"][this.viewModel.viewMode];
        if (this.viewModel.getTechniqueVM(this.technique.technique_tactic_union_id).comment.length > 0)
            theclass += " has-comment";
        if (this.getTechniqueBackground())
            theclass += " has-background";
        return theclass;
    };
    /**
     * get the technique background style for ngstyle
     * @param  technique technique
     * @return           background object
     */
    TechniqueCellComponent.prototype.getTechniqueBackground = function () {
        var tvm = this.viewModel.getTechniqueVM(this.technique.technique_tactic_union_id);
        // don't display if disabled or highlighted
        var highlight = false;
        if (this.viewModel.highlightedTechnique) {
            if (this.viewModel.selectTechniquesAcrossTactics && this.viewModel.highlightedTechnique.technique_id === this.technique.technique_id) {
                highlight = true;
            }
            else if (!this.viewModel.selectTechniquesAcrossTactics && this.viewModel.highlightedTechnique.technique_tactic_union_id === this.technique.technique_tactic_union_id) {
                highlight = true;
            }
        }
        if (!tvm.enabled || highlight)
            return {};
        if (tvm.color)
            return { "background": tvm.color };
        if (tvm.score)
            return { "background": tvm.scoreColor };
        // return tvm.enabled && tvm.score && !tvm.color && !(this.viewModel.highlightedTechnique && this.viewModel.highlightedTechnique.technique_id == technique.technique_id)
    };
    /**
    * Get most readable text color for the given technique
    * @param  technique     the technique to get the text color for
    * @param  antihighlight boolean, true if the column is not selected.
    * @return               black, white, or gray, depending on technique and column state
    */
    TechniqueCellComponent.prototype.getTechniqueTextColor = function () {
        var tvm = this.viewModel.getTechniqueVM(this.technique.technique_tactic_union_id);
        if (!tvm.enabled)
            return "#aaaaaa";
        // don't display if disabled or highlighted
        if (this.viewModel.highlightedTechnique && this.viewModel.highlightedTechnique.technique_tactic_union_id == this.technique.technique_tactic_union_id)
            return "black";
        if (tvm.color)
            return tinycolor.mostReadable(tvm.color, ["white", "black"]);
        if (tvm.score && !isNaN(Number(tvm.score)))
            return tinycolor.mostReadable(tvm.scoreColor, ["white", "black"]);
        if (this.viewModel.highlightedTactic && this.technique.tactic != this.viewModel.highlightedTactic)
            return "#aaaaaa";
        else
            return "black";
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _data_service__WEBPACK_IMPORTED_MODULE_1__["Technique"])
    ], TechniqueCellComponent.prototype, "technique", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _viewmodels_service__WEBPACK_IMPORTED_MODULE_2__["ViewModel"])
    ], TechniqueCellComponent.prototype, "viewModel", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], TechniqueCellComponent.prototype, "highlight", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], TechniqueCellComponent.prototype, "leftclick", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], TechniqueCellComponent.prototype, "rightclick", void 0);
    TechniqueCellComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'technique-cell',
            template: __webpack_require__(/*! raw-loader!./technique-cell.component.html */ "./node_modules/raw-loader/index.js!./src/app/datatable/technique-cell/technique-cell.component.html"),
            styles: [__webpack_require__(/*! ./technique-cell.component.scss */ "./src/app/datatable/technique-cell/technique-cell.component.scss")]
        }),
        __metadata("design:paramtypes", [_config_service__WEBPACK_IMPORTED_MODULE_3__["ConfigService"]])
    ], TechniqueCellComponent);
    return TechniqueCellComponent;
}());



/***/ }),

/***/ "./src/app/exporter/exporter.component.scss":
/*!**************************************************!*\
  !*** ./src/app/exporter/exporter.component.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".svgcontainer {\n  overflow-x: auto;\n}\n\n.dropdown-container {\n  padding: 10px;\n}\n\n.dropdown-container ul {\n  padding-left: 0;\n}\n\n.dropdown-container ul li {\n  list-style: none;\n  text-align: left;\n}\n\n.dropdown-container ul li input.has-suffix {\n  text-align: right;\n  -moz-appearance: textfield;\n}\n\n.dropdown-container ul li input.has-suffix::-webkit-inner-spin-button, .dropdown-container ul li input.has-suffix::-webkit-outer-spin-button {\n  display: none;\n}"

/***/ }),

/***/ "./src/app/exporter/exporter.component.ts":
/*!************************************************!*\
  !*** ./src/app/exporter/exporter.component.ts ***!
  \************************************************/
/*! exports provided: ExporterComponent, ExportData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExporterComponent", function() { return ExporterComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExportData", function() { return ExportData; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../config.service */ "./src/app/config.service.ts");
/* harmony import */ var is_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! is_js */ "./node_modules/is_js/is.js");
/* harmony import */ var is_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(is_js__WEBPACK_IMPORTED_MODULE_2__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ExporterComponent = /** @class */ (function () {
    function ExporterComponent(configService) {
        this.configService = configService;
        this.svgDivName = "svgInsert_tmp";
        this.unitEnum = 0; //counter for unit change ui element
        this.buildSVGDebounce = false;
    }
    ExporterComponent.prototype.ngAfterViewInit = function () {
        this.svgDivName = "svgInsert" + this.exportData.viewModel.uid;
        var self = this;
        this.exportData.filteredTechniques.forEach(function (technique) {
            if (self.exportData.viewModel.hasTechniqueVM(technique.technique_tactic_union_id)) {
                if (self.exportData.viewModel.getTechniqueVM(technique.technique_tactic_union_id).score != "")
                    self.hasScores = true;
            }
        });
        //put at the end of the function queue so that the page can render before building the svg
        window.setTimeout(function () { self.buildSVG(self); }, 0);
    };
    //visibility of SVG parts
    //assess data in viewModel
    ExporterComponent.prototype.hasName = function () { return this.exportData.viewModel.name.length > 0; };
    ExporterComponent.prototype.hasDescription = function () { return this.exportData.viewModel.description.length > 0; };
    ExporterComponent.prototype.hasLegendItems = function () { return this.exportData.viewModel.legendItems.length > 0; };
    //above && user preferences
    ExporterComponent.prototype.showName = function () { return this.exportData.tableConfig.showName && this.hasName() && this.exportData.tableConfig.showHeader; };
    ExporterComponent.prototype.showDescription = function () { return this.exportData.tableConfig.showDescription && this.hasDescription() && this.exportData.tableConfig.showHeader; };
    ExporterComponent.prototype.showLayerInfo = function () { return (this.showName() || this.showDescription()) && this.exportData.tableConfig.showHeader; };
    ExporterComponent.prototype.showFilters = function () { return this.exportData.tableConfig.showFilters && this.exportData.tableConfig.showHeader; };
    ;
    ExporterComponent.prototype.showGradient = function () { return this.exportData.tableConfig.showGradient && this.hasScores && this.exportData.tableConfig.showHeader; };
    ExporterComponent.prototype.showLegend = function () { return this.exportData.tableConfig.showLegend && this.hasLegendItems(); };
    ExporterComponent.prototype.showLegendInHeader = function () { return this.exportData.tableConfig.legendDocked && this.showLegend(); };
    ExporterComponent.prototype.showItemCount = function () { return this.exportData.tableConfig.showTechniqueCount; };
    ExporterComponent.prototype.buildSVG = function (self, bypassDebounce) {
        if (bypassDebounce === void 0) { bypassDebounce = false; }
        if (!self)
            self = this; //in case we were called from somewhere other than ngViewInit
        console.log("settings changed");
        if (self.buildSVGDebounce && !bypassDebounce) {
            // console.log("skipping debounce...")
            return;
        }
        if (!bypassDebounce) {
            // console.log("debouncing...");
            self.buildSVGDebounce = true;
            window.setTimeout(function () { self.buildSVG(self, true); }, 500);
            return;
        }
        self.buildSVGDebounce = false;
        console.log("building SVG");
        //check preconditions, make sure they're in the right range
        var margin = { top: 5, right: 5, bottom: 5, left: 5 };
        var width = Math.max(self.convertToPx(self.exportData.tableConfig.width, self.exportData.tableConfig.unit) - (margin.right + margin.left), 10);
        console.log("width", width);
        var height = Math.max(self.convertToPx(self.exportData.tableConfig.height, self.exportData.tableConfig.unit) - (margin.top + margin.bottom), 10);
        console.log("height", height);
        var headerHeight = Math.max(self.convertToPx(self.exportData.tableConfig.headerHeight, self.exportData.tableConfig.unit), 1);
        console.log("headerHeight", headerHeight);
        var legendX = Math.max(self.convertToPx(self.exportData.tableConfig.legendX, self.exportData.tableConfig.unit), 0);
        var legendY = Math.max(self.convertToPx(self.exportData.tableConfig.legendY, self.exportData.tableConfig.unit), 0);
        var legendWidth = Math.max(self.convertToPx(self.exportData.tableConfig.legendWidth, self.exportData.tableConfig.unit), 10);
        var legendHeight = Math.max(self.convertToPx(self.exportData.tableConfig.legendHeight, self.exportData.tableConfig.unit), 10);
        var tableFontSize = Math.max(self.exportData.tableConfig.tableFontSize, 1);
        console.log('tableFontSize', tableFontSize);
        var tableTextYOffset = ((tableFontSize / 2) - (1 / 2));
        var tableTacticFontSize = Math.max(self.exportData.tableConfig.tableTacticFontSize, 1);
        console.log("tableTacticFontSize", tableTacticFontSize);
        var tableTacticTextYOffset = ((tableTacticFontSize / 2) - (1 / 2));
        var headerFontSize = Math.max(self.exportData.tableConfig.headerFontSize, 1);
        console.log("headerFontSize", headerFontSize);
        var headerTextYOffset = ((headerFontSize / 2) - (1 / 2));
        var headerLayerNameFontSize = Math.max(self.exportData.tableConfig.headerLayerNameFontSize, 1);
        console.log("headerLayerNameFontSize", headerLayerNameFontSize);
        var heafderLayerNameTextYOffset = ((headerLayerNameFontSize / 2) - (1 / 2));
        var fontUnits = self.exportData.tableConfig.fontUnit;
        var headerTextPad = 6;
        var bodyTextPad = 3;
        //remove previous graphic
        var element = document.getElementById(self.svgDivName);
        element.innerHTML = "";
        var svg = d3.select("#" + self.svgDivName).append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .attr("xmlns", "http://www.w3.org/2000/svg")
            .attr("id", "svg" + self.exportData.viewModel.uid) //Tag for downloadSVG
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
            .style("font-family", self.exportData.tableConfig.font);
        var stroke_width = 1;
        //  _  _ ___   _   ___  ___ ___
        // | || | __| /_\ |   \| __| _ \
        // | __ | _| / _ \| |) | _||   /
        // |_||_|___/_/ \_\___/|___|_|_\
        //count columns
        var numSections = 0;
        for (var i = 0; i < 4; i++) {
            var option = [self.showLayerInfo(), self.showFilters(), self.showGradient(), self.showLegendInHeader()][i];
            if (option)
                numSections++;
        }
        var headerSectionWidth = width / numSections;
        // console.log(numSections, headerSectionWidth)
        var header = null;
        var posX = 0; //row in the header
        var headerSectionTitleSep = (2 * (headerFontSize + headerTextPad));
        if (self.exportData.tableConfig.showHeader) {
            header = svg.append("g");
            header.append("rect")
                .attr("width", width)
                .attr("height", headerHeight)
                .style("stroke", "black")
                .style("stroke-width", stroke_width)
                .style("fill", "white");
            // layer name
            if (self.showLayerInfo()) {
                var layerAndDescPresent = (self.showName() && self.showDescription());
                var nameDescHeight = layerAndDescPresent ? headerHeight / 2 : headerHeight;
                var descY = layerAndDescPresent ? headerHeight / 2 : 0;
                if (self.showName()) { //layer name
                    var titleGroup = header.append("g")
                        .attr("transform", "translate(0,0)");
                    titleGroup.append("rect")
                        .attr("width", headerSectionWidth)
                        .attr("height", nameDescHeight)
                        .style("stroke-width", 1)
                        .style("stroke", "black")
                        .style("fill", "white");
                    titleGroup.append("text")
                        .text(self.exportData.viewModel.name)
                        .attr("transform", "translate(" + headerTextPad + ", " + (headerLayerNameFontSize + headerTextPad) + ")")
                        .attr("dx", 0)
                        .attr("dy", 0)
                        .attr("font-size", headerLayerNameFontSize + fontUnits)
                        .attr("fill", "black")
                        .style("font-weight", "bold")
                        .call(self.wrap, (headerSectionWidth) - 4, nameDescHeight, self);
                }
                if (self.showDescription()) { //description
                    var descriptionGroup = header.append("g")
                        .attr("transform", "translate(0," + descY + ")");
                    descriptionGroup.append("rect")
                        .attr("width", headerSectionWidth)
                        .attr("height", nameDescHeight)
                        .style("stroke-width", 1)
                        .style("stroke", "black")
                        .style("fill", "white");
                    descriptionGroup.append("text")
                        .text(self.exportData.viewModel.description)
                        .attr("transform", "translate(" + headerTextPad + ", " + (headerTextPad + headerTextYOffset) + ")")
                        // .attr("dominant-baseline", "middle")
                        .attr("dx", 0)
                        .attr("dy", 0)
                        .attr("font-size", headerFontSize + fontUnits)
                        .attr("fill", "black")
                        .call(self.wrap, (headerSectionWidth) - 4, nameDescHeight, self)
                        .call(self.recenter, nameDescHeight - (2 * headerTextPad), self);
                }
                posX++;
            }
            if (self.showFilters()) {
                //filters
                var filtersGroup = header.append("g")
                    .attr("transform", "translate(" + (headerSectionWidth * posX) + ", 0)");
                filtersGroup.append("rect")
                    .attr("width", headerSectionWidth)
                    .attr("height", headerHeight)
                    .style("stroke-width", 1)
                    .style("stroke", "black")
                    .style("fill", "white");
                filtersGroup.append("text")
                    .text("filters")
                    .attr("transform", "translate(" + headerTextPad + ", " + (headerFontSize + headerTextPad) + ")")
                    .attr("dx", 0)
                    .attr("dy", 0)
                    .attr("font-size", headerFontSize + fontUnits)
                    .attr("fill", "black")
                    .style("font-weight", "bold");
                var filterTextGroup = filtersGroup.append("g")
                    .attr("transform", "translate(" + headerTextPad + "," + (headerSectionTitleSep + 6 + headerTextYOffset) + ")");
                filterTextGroup.append("text")
                    .text(function () {
                    var t = "stages: ";
                    var selection = self.exportData.viewModel.filters.stages.selection;
                    for (var i = 0; i < selection.length; i++) {
                        if (i != 0)
                            t += ", ";
                        t += selection[i];
                    }
                    return t;
                })
                    .attr("font-size", headerFontSize + fontUnits);
                // .attr("dominant-baseline", "middle");
                filterTextGroup.append("text")
                    .text(function () {
                    var t = "platforms: ";
                    var selection = self.exportData.viewModel.filters.platforms.selection;
                    for (var i = 0; i < selection.length; i++) {
                        if (i != 0)
                            t += ", ";
                        t += selection[i];
                    }
                    return t;
                })
                    .attr("font-size", headerFontSize + fontUnits)
                    // .attr("dominant-baseline", "middle")
                    .attr("dy", "1.1em");
                // .attr("transform", "translate(0, " +(headerFontSize + textPad) + ")");
                posX++;
            }
            if (self.showGradient()) {
                //gradient
                var gradientGroup = header.append("g")
                    .attr("transform", "translate(" + (headerSectionWidth * posX) + ",0)");
                gradientGroup.append("rect")
                    .attr("width", headerSectionWidth)
                    .attr("height", headerHeight)
                    .style("stroke-width", 1)
                    .style("stroke", "black")
                    .style("fill", "white");
                gradientGroup.append("text")
                    .text("score gradient")
                    .attr("transform", "translate(" + headerTextPad + ", " + (headerFontSize + headerTextPad) + ")")
                    .attr("dx", 0)
                    .attr("dy", 0)
                    .attr("font-size", headerFontSize + fontUnits)
                    .attr("fill", "black")
                    .style("font-weight", "bold");
                posX++;
                var gradientContentGroup = gradientGroup.append("g")
                    .attr("transform", "translate(" + headerTextPad + "," + headerSectionTitleSep + ")");
                var leftText = gradientContentGroup.append("text")
                    .text(self.exportData.viewModel.gradient.minValue)
                    .attr("transform", "translate(0, " + (6 + headerTextYOffset) + ")")
                    .attr("font-size", headerFontSize + fontUnits);
                // .attr("dominant-baseline", "middle")
                //set up gradient to bind
                var svgDefs = svg.append('defs');
                var gradientElement = svgDefs.append("linearGradient")
                    .attr("id", self.exportData.viewModel.uid + "gradientElement");
                for (var i = 0; i < self.exportData.viewModel.gradient.gradientRGB.length; i++) {
                    var color = self.exportData.viewModel.gradient.gradientRGB[i];
                    gradientElement.append('stop')
                        .attr('offset', i / 100)
                        .attr("stop-color", color.toHexString());
                    // console.log(color)
                }
                // console.log(gradientElement);
                var gradientDisplayLeft = (leftText.node().getComputedTextLength()) + 2;
                var gradientDisplay = gradientContentGroup.append("rect")
                    .attr("transform", "translate(" + gradientDisplayLeft + ", 0)")
                    .attr("width", 50)
                    .attr("height", 10)
                    .style("stroke-width", 1)
                    .style("stroke", "black")
                    .attr("fill", "url(#" + self.exportData.viewModel.uid + "gradientElement)"); //bind gradient
                gradientContentGroup.append("text")
                    .text(self.exportData.viewModel.gradient.maxValue)
                    .attr("transform", "translate(" + (gradientDisplayLeft + 50 + 2) + ", " + (6 + headerTextYOffset) + ")")
                    .attr("font-size", headerFontSize + fontUnits);
                // .attr("dominant-baseline", "middle")
            }
            header.append("line")
                .attr("x1", 0)
                .attr("x2", width)
                .attr("y1", headerHeight)
                .attr("y2", headerHeight)
                .style("stroke", "black")
                .style("stroke-width", 3);
        }
        else { //no header
            headerHeight = 0;
        }
        //  _____ _   ___ _    ___   ___  ___  _____   __
        // |_   _/_\ | _ ) |  | __| | _ )/ _ \|   \ \ / /
        //   | |/ _ \| _ \ |__| _|  | _ \ (_) | |) \ V /
        //   |_/_/ \_\___/____|___| |___/\___/|___/ |_|
        var tablebody = svg.append("g")
            .attr("transform", "translate(0," + (headerHeight + 1) + ")");
        //calculate cell height: the longest column decides the cell height
        var cellHeight = Number.MAX_VALUE; //Number.MAX_VALUE; //(height - margin.bottom - headerHeight)
        Object.keys(self.exportData.tactics).forEach(function (key) {
            var numVCells = (self.exportData.tactics[key].length) + 2; //extra two cells for the header
            var selfCellHeight = (height - (headerHeight + 1)) / numVCells;
            cellHeight = Math.min(cellHeight, selfCellHeight);
        });
        cellHeight = Math.max(cellHeight, 1); //must be positive number
        // columns
        var columnWidth = (width) / (self.exportData.orderedTactics.length);
        var columns = tablebody.selectAll("g")
            .data(self.exportData.orderedTactics).enter()
            .append("g")
            .attr("transform", function (d, i) {
            // console.log(d,i)
            return "translate(" + columnWidth * i + ", 0)";
        });
        // split columns into headers and bodies
        var colHeaderHeight = this.showItemCount() ? 2 * cellHeight : cellHeight;
        var columnHeaders = columns.append("g")
            .attr("transform", "translate(0,0)");
        columnHeaders.append("rect")
            .attr("width", columnWidth)
            .attr("height", colHeaderHeight)
            .style("stroke", self.exportData.tableConfig.tableBorderColor)
            .style("fill", self.exportData.viewModel.showTacticRowBackground ? self.exportData.viewModel.tacticRowBackground : 'white');
        columnHeaders.append("text")
            .text(function (d) { return self.exportData.tableConfig.tableTextDisplay != 2 ? self.toCamelCase(d.replace(/-/g, " ")) : self.exportData.viewModel.acronym(d.replace(/-/g, " ")); })
            .attr("font-size", tableTacticFontSize + fontUnits)
            .attr("transform", "translate(" + bodyTextPad + ", " + ((self.getSpacing(colHeaderHeight, this.showItemCount() ? 2 : 1)[0]) + tableTacticTextYOffset) + ")")
            .style("fill", self.exportData.viewModel.showTacticRowBackground ? tinycolor.mostReadable(self.exportData.viewModel.tacticRowBackground, ['white', 'black']) : 'black')
            .attr("dx", 0)
            .attr("dy", 0)
            .style("font-weight", "bold")
            .call(self.wrap, columnWidth - 2 - bodyTextPad, cellHeight - 2, self);
        if (this.showItemCount())
            columnHeaders.append("text")
                .text(function (d) {
                return self.exportData.tableConfig.tableTextDisplay != 2 ? self.exportData.tactics[d].length + " items" : self.exportData.tactics[d].length;
            })
                .attr("font-size", tableTacticFontSize + fontUnits)
                .attr("transform", "translate(" + bodyTextPad + ", " + ((self.getSpacing(colHeaderHeight, 2)[1]) + tableTacticTextYOffset) + ")")
                .style("fill", self.exportData.viewModel.showTacticRowBackground ? tinycolor.mostReadable(self.exportData.viewModel.tacticRowBackground, ['white', 'black']) : 'black')
                .attr("dx", 0)
                .attr("dy", 0)
                .call(self.wrap, columnWidth - bodyTextPad, cellHeight, self);
        //column body
        var columnBodies = columns.append("g")
            .attr("transform", "translate(0," + colHeaderHeight + ")");
        var techniques = columnBodies.selectAll("g")
            .data(function (d) {
            // console.log(d)
            return self.exportData.tactics[d];
        }).enter().append("g")
            .attr("transform", function (d, i) {
            return "translate(0," + i * cellHeight + ")";
        });
        techniques.append("rect")
            .attr("width", columnWidth)
            .attr("height", cellHeight)
            .style("stroke", self.exportData.tableConfig.tableBorderColor)
            .style("fill", function (d) {
            if (!self.exportData.viewModel.hasTechniqueVM(d.technique_tactic_union_id))
                return "white";
            var tvm = self.exportData.viewModel.getTechniqueVM(d.technique_tactic_union_id);
            if (tvm.color)
                return tvm.color;
            else if (tvm.score)
                return tvm.scoreColor;
            else
                return "white";
        });
        if (self.exportData.tableConfig.tableTextDisplay != "none")
            techniques.append("text")
                .text(function (d) {
                return ['', d.name, self.exportData.viewModel.acronym(d.name), d.technique_id][self.exportData.tableConfig.tableTextDisplay];
            })
                .style("fill", function (d) {
                if (!self.exportData.viewModel.hasTechniqueVM(d.technique_tactic_union_id))
                    return "black";
                var tvm = self.exportData.viewModel.getTechniqueVM(d.technique_tactic_union_id);
                if (tvm.color)
                    return tinycolor.mostReadable(tvm.color, ['white', 'black']);
                if (tvm.score)
                    return tinycolor.mostReadable(tvm.scoreColor, ['white', 'black']);
            })
                .attr("font-size", tableFontSize + fontUnits)
                .attr("transform", "translate(" + bodyTextPad + ", " + tableTextYOffset + ")")
                .attr("dx", 0)
                .attr("dy", 0)
                .call(self.wrap, columnWidth - (2 * bodyTextPad), cellHeight, self) //do this before recenter
                .call(self.recenter, cellHeight, self); //fix the tspan children's y locations. MUST CALL AFTER WRAP
        //  _    ___ ___ ___ _  _ ___
        // | |  | __/ __| __| \| |   \
        // | |__| _| (_ | _|| .` | |) |
        // |____|___\___|___|_|\_|___/
        // console.log(showLegend, showLegendInHeader && self.exportData.tableConfig.legendDocked)
        if (self.showLegend() && !(!self.exportData.tableConfig.showHeader && self.exportData.tableConfig.legendDocked)) {
            console.log("building legend");
            //legend
            var legendGroup = self.showLegendInHeader() ? header.append("g")
                .attr("transform", "translate(" + (headerSectionWidth * posX) + ",0)")
                : svg.append("g")
                    .attr("transform", "translate(" + legendX + "," + legendY + ")");
            legendGroup.append("rect")
                .attr("width", self.showLegendInHeader() ? headerSectionWidth : legendWidth)
                .attr("height", self.showLegendInHeader() ? headerHeight : legendHeight)
                .style("stroke-width", 1)
                .style("stroke", "black")
                .style("fill", "white");
            legendGroup.append("text")
                .text("legend")
                .attr("transform", "translate(" + headerTextPad + ", " + (headerFontSize + headerTextPad) + ")")
                .attr("dx", 0)
                .attr("dy", 0)
                .attr("font-size", headerFontSize + fontUnits)
                .attr("fill", "black")
                .style("font-weight", "bold");
            ;
            var legendItemHeight_1 = self.showLegendInHeader() ? ((headerHeight - headerSectionTitleSep) / self.exportData.viewModel.legendItems.length) : ((legendHeight - headerSectionTitleSep) / self.exportData.viewModel.legendItems.length);
            var legendItemsGroup = legendGroup.selectAll("g")
                .data(self.exportData.viewModel.legendItems)
                .enter().append("g")
                .attr("transform", function (d, i) {
                return "translate(" + headerTextPad + "," + (headerSectionTitleSep + (legendItemHeight_1 * i)) + ")";
            });
            legendItemsGroup.append("text")
                .text(function (d) { return d.label; })
                .attr("transform", "translate(" + (headerTextPad + 10) + "," + (6 + headerTextYOffset) + ")")
                // .attr("dominant-baseline", "middle")
                .attr("font-size", headerFontSize + fontUnits)
                .attr("fill", "black")
                .attr("dx", 0)
                .attr("dy", 0)
                .call(self.wrap, (self.showLegendInHeader() ? headerSectionWidth : legendWidth - 14), 0, self);
            legendItemsGroup.append("rect")
                .attr("width", 10)
                .attr("height", 10)
                .style("stroke-width", 1)
                .style("stroke", "black")
                .style("fill", function (d) { return d.color; });
            // posX++
        }
    };
    ExporterComponent.prototype.downloadSVG = function () {
        var svgEl = document.getElementById("svg" + this.exportData.viewModel.uid);
        svgEl.setAttribute("xmlns", "http://www.w3.org/2000/svg");
        var svgData = new XMLSerializer().serializeToString(svgEl);
        // // var svgData = svgEl.outerHTML;
        // console.log(svgData)
        // let svgData2 = new XMLSerializer().serializeToString(svgEl);
        // console.log(svgData2)
        var filename = this.exportData.viewModel.name.split(' ').join('_');
        filename = filename.replace(/\W/g, "") + ".svg"; // remove all non alphanumeric characters
        var preface = '<?xml version="1.0" standalone="no"?>\r\n';
        var svgBlob = new Blob([preface, svgData], { type: "image/svg+xml;charset=utf-8" });
        if (is_js__WEBPACK_IMPORTED_MODULE_2__["ie"]()) { //internet explorer
            window.navigator.msSaveBlob(svgBlob, filename);
        }
        else {
            var svgUrl = URL.createObjectURL(svgBlob);
            var downloadLink = document.createElement("a");
            downloadLink.href = svgUrl;
            downloadLink.download = filename;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }
    };
    /**
     * Convert any length in various units to pixels
     * @param  quantity what length
     * @param  unit     which unit system (in, cm, px?)
     * @return          that length in pixels
     */
    ExporterComponent.prototype.convertToPx = function (quantity, unit) {
        var factor;
        switch (unit) {
            case "in": {
                factor = 96;
                break;
            }
            case "cm": {
                factor = 3.779375 * 10;
                break;
            }
            case "px": {
                factor = 1;
                break;
            }
            case "em": {
                factor = 16;
                break;
            }
            case "pt": {
                factor = 1.33;
            }
            default: {
                console.error("unknown unit", unit);
                factor = 0;
            }
        }
        return quantity * factor;
    };
    // wrap(text, width, padding) {
    //     var self = d3.select(this),
    //     textLength = self.node().getComputedTextLength(),
    //     text = self.text();
    //     while (textLength > (width - 2 * padding) && text.length > 0) {
    //         text = text.slice(0, -1);
    //         self.text(text + '...');
    //         textLength = self.node().getComputedTextLength();
    //     }
    // }
    /**
     * wrap the given text svg element
     * @param  text       element to wrap
     * @param  width      width to wrap to
     * @param  cellheight stop appending wraps after this height
     * @param  self       reference to self this component because of call context
     */
    ExporterComponent.prototype.wrap = function (text, width, cellheight, self) {
        text.each(function () {
            var text = d3.select(this), words = text.text().split(/\s+/).reverse(), word, line = [], lineHeight = 1.1, // ems
            y = text.attr("y"), dy = parseFloat(text.attr("dy")), tspan = text.text(null).append("tspan").attr("x", 0).attr("y", y).attr("dy", dy + "em");
            while (word = words.pop()) {
                line.push(word);
                tspan.text(line.join(" "));
                if (tspan.node().getComputedTextLength() > width) {
                    line.pop();
                    tspan.text(line.join(" "));
                    line = [word];
                    var thisdy = lineHeight + dy;
                    // if (self.convertToPx(thisdy, "em") > cellheight) return;
                    tspan = text.append("tspan").attr("x", 0).attr("y", y).attr("dy", thisdy + "em").text(word);
                }
            }
            // console.log(text)
            // text.selectAll("tspan").each(function(d, i, j) {
            //     // console.log(this, i, j.length)
            //     console.log(self.getSpacing(cellheight, j.length)[i])
            //     d3.select(this)
            //         .attr("dy", self.getSpacing(cellheight, j.length)[i])
            //         .attr("dominant-baseline", "middle")
            //
            // })
        });
    };
    /**
     * Recenter the selected element's tspan elements
     * @param  height [description]
     * @param  self   [description]
     */
    ExporterComponent.prototype.recenter = function (text, height, self) {
        text.each(function () {
            text.selectAll('tspan').each(function (d, i, els) {
                var numTSpan = els.length;
                var location = self.getSpacing(height, numTSpan)[i];
                var tspan = d3.select(this)
                    .attr("y", (location))
                    .attr("dy", "0");
            });
        });
    };
    // Capitalizes the first letter of each word in a string
    ExporterComponent.prototype.toCamelCase = function (str) {
        return str.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
    };
    //following two functions are only used for iterating over tableconfig options: remove when tableconfig options are hardcoded in html
    ExporterComponent.prototype.getKeys = function (obj) { return Object.keys(obj); };
    ExporterComponent.prototype.type = function (obj) { return typeof (obj); };
    /**
     * Return whether the given dropdown element would overflow the side of the page if aligned to the right of its anchor
     * @param  dropdown the DOM node of the panel
     * @return          true if it would overflow
     */
    ExporterComponent.prototype.checkalign = function (dropdown) {
        // console.log(anchor)
        var anchor = dropdown.parentNode;
        return anchor.getBoundingClientRect().left + dropdown.getBoundingClientRect().width > document.body.clientWidth;
    };
    /**
     * Divide distance into divisions equidestant anchor points S.T they all have equal
     * padding from each other and the beginning and end of the distance
     * @param  distance  distance to divide
     * @param  divisions number of divisions
     * @return           number[] where each number corresponds to a division-center offset
     */
    ExporterComponent.prototype.getSpacing = function (distance, divisions) {
        distance = distance - 1; //1px padding for border
        var spacing = distance / (divisions * 2);
        var res = [];
        for (var i = 1; i <= divisions * 2; i += 2) {
            res.push(1 + (spacing * i));
        }
        return res;
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", ExportData)
    ], ExporterComponent.prototype, "exportData", void 0);
    ExporterComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'exporter',
            template: __webpack_require__(/*! raw-loader!./exporter.component.html */ "./node_modules/raw-loader/index.js!./src/app/exporter/exporter.component.html"),
            styles: [__webpack_require__(/*! ./exporter.component.scss */ "./src/app/exporter/exporter.component.scss")]
        }),
        __metadata("design:paramtypes", [_config_service__WEBPACK_IMPORTED_MODULE_1__["ConfigService"]])
    ], ExporterComponent);
    return ExporterComponent;
}());

var ExportData = /** @class */ (function () {
    function ExportData(viewModel, tactics, orderedTactics, filteredTechniques) {
        this.viewModel = viewModel;
        this.tactics = tactics;
        this.filteredTechniques = filteredTechniques;
        this.orderedTactics = orderedTactics;
        var tableTextDisplay = "0";
        switch (this.viewModel.viewMode) {
            case 0: {
                tableTextDisplay = "1";
                break;
            }
            case 1: {
                tableTextDisplay = "2";
                break;
            }
            case 2: {
                tableTextDisplay = "0";
                break;
            }
            default: {
                tableTextDisplay = "1";
            }
        }
        this.tableConfig = {
            "width": 11,
            "height": 8.5,
            "headerHeight": 1,
            "unit": "in",
            "fontUnit": "pt",
            "font": 'sans-serif',
            "tableFontSize": 5,
            "tableTacticFontSize": 6,
            "tableTextDisplay": tableTextDisplay,
            "tableBorderColor": "#000000",
            "showHeader": true,
            "headerLayerNameFontSize": 18,
            "headerFontSize": 12,
            "legendDocked": true,
            "legendX": 0,
            "legendY": 0,
            "legendWidth": 2,
            "legendHeight": 2,
            "showLegend": true,
            "showGradient": true,
            "showFilters": true,
            "showDescription": true,
            "showName": true,
            "showTechniqueCount": true
        };
    }
    return ExportData;
}());



/***/ }),

/***/ "./src/app/globals.ts":
/*!****************************!*\
  !*** ./src/app/globals.ts ***!
  \****************************/
/*! exports provided: nav_version, layer_version */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "nav_version", function() { return nav_version; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layer_version", function() { return layer_version; });
//   ___ _    ___  ___   _   _     __   ___   ___ ___   _   ___ _    ___ ___
//  / __| |  / _ \| _ ) /_\ | |    \ \ / /_\ | _ \_ _| /_\ | _ ) |  | __/ __|
// | (_ | |_| (_) | _ \/ _ \| |__   \ V / _ \|   /| | / _ \| _ \ |__| _|\__ \
//  \___|____\___/|___/_/ \_\____|   \_/_/ \_\_|_\___/_/ \_\___/____|___|___/
//

var nav_version = "2.3.2";
var layer_version = "2.2";


/***/ }),

/***/ "./src/app/help/help.component.scss":
/*!******************************************!*\
  !*** ./src/app/help/help.component.scss ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".help {\n  font-size: 11pt;\n  padding: 25px 20%;\n}\n.help h1 {\n  text-align: center;\n  border-bottom: 1px solid black;\n}\n.toc {\n  list-style: none;\n}\n.toc ul {\n  list-style: none;\n}\ncode {\n  color: black;\n  border: 1px solid #ddd;\n  padding: 1px 2px;\n}"

/***/ }),

/***/ "./src/app/help/help.component.ts":
/*!****************************************!*\
  !*** ./src/app/help/help.component.ts ***!
  \****************************************/
/*! exports provided: HelpComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelpComponent", function() { return HelpComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/app/globals.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var HelpComponent = /** @class */ (function () {
    function HelpComponent() {
        this.nav_version = _globals__WEBPACK_IMPORTED_MODULE_1__["nav_version"];
    }
    HelpComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'help',
            template: __webpack_require__(/*! raw-loader!./help.component.html */ "./node_modules/raw-loader/index.js!./src/app/help/help.component.html"),
            styles: [__webpack_require__(/*! ./help.component.scss */ "./src/app/help/help.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], HelpComponent);
    return HelpComponent;
}());



/***/ }),

/***/ "./src/app/tab/tab.component.scss":
/*!****************************************!*\
  !*** ./src/app/tab/tab.component.scss ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/tab/tab.component.ts":
/*!**************************************!*\
  !*** ./src/app/tab/tab.component.ts ***!
  \**************************************/
/*! exports provided: TabComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabComponent", function() { return TabComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
// https://embed.plnkr.co/wWKnXzpm8V31wlvu64od/s

var TabComponent = /** @class */ (function () {
    function TabComponent() {
        this.active = false;
        this.isCloseable = false;
        this.showScoreVariables = false;
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('tabTitle'),
        __metadata("design:type", String)
    ], TabComponent.prototype, "title", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], TabComponent.prototype, "active", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], TabComponent.prototype, "isCloseable", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], TabComponent.prototype, "template", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], TabComponent.prototype, "dataContext", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], TabComponent.prototype, "showScoreVariables", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], TabComponent.prototype, "isDataTable", void 0);
    TabComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'tab',
            template: __webpack_require__(/*! raw-loader!./tab.component.html */ "./node_modules/raw-loader/index.js!./src/app/tab/tab.component.html"),
            styles: [__webpack_require__(/*! ./tab.component.scss */ "./src/app/tab/tab.component.scss")]
        })
    ], TabComponent);
    return TabComponent;
}());



/***/ }),

/***/ "./src/app/tabs/dynamic-tabs.directive.ts":
/*!************************************************!*\
  !*** ./src/app/tabs/dynamic-tabs.directive.ts ***!
  \************************************************/
/*! exports provided: DynamicTabsDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DynamicTabsDirective", function() { return DynamicTabsDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/**
 * This directive is used as an anchor to get access
 * to the ViewContainerRef which here is exposed via
 * the public member `viewContainer`
 *
 * Theres an ALTERNATIVE to explicitly using the anchor directive.
 * Read in the blog post
 */
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var DynamicTabsDirective = /** @class */ (function () {
    function DynamicTabsDirective(viewContainer) {
        this.viewContainer = viewContainer;
    }
    DynamicTabsDirective = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"])({
            selector: '[dynamic-tabs]'
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"]])
    ], DynamicTabsDirective);
    return DynamicTabsDirective;
}());



/***/ }),

/***/ "./src/app/tabs/tabs.component.scss":
/*!******************************************!*\
  !*** ./src/app/tabs/tabs.component.scss ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".tabs {\n  padding-left: 0;\n  margin-bottom: 0;\n  list-style: none;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  margin-top: 0;\n}\n.tabs > li {\n  bottom: 0;\n  position: relative;\n  display: block;\n  float: left;\n  margin-bottom: 0;\n  cursor: pointer;\n  height: 23px;\n  position: relative;\n  display: block;\n  padding: 10px 15px;\n  margin-right: 2px;\n  border: 1px solid transparent;\n  border-radius: 4px 4px 0 0;\n}\n.tabs > li a {\n  font-family: \"Roboto Mono\", monospace;\n  font-size: 14px;\n  text-decoration: none;\n  color: black;\n}\n.tabs > li input[type=text] {\n  font-family: \"Roboto Mono\", monospace;\n  font-size: 14px;\n  border: none;\n  background: none;\n}\n.tabs > li input[type=text]:not(:disabled):focus {\n  background: #f1f1f1;\n}\n.tabs > li.addTab {\n  font-size: 12pt;\n  cursor: pointer;\n  color: #aaaaaa;\n}\n.tabs > li.addTab:hover {\n  color: black;\n}\n.tabs > li:hover:not(.active), .tabs > li:focus:not(.active) {\n  text-decoration: none;\n}\n.tabs > li:hover:not(.active):not(.addTab), .tabs > li:focus:not(.active):not(.addTab) {\n  border-color: #ddd #ddd #f1f1f1 #ddd;\n  background-color: #f1f1f1;\n}\n.tabs > li > .tabEnumerator {\n  position: absolute;\n  top: -10px;\n  right: 5px;\n  padding: 2px 4px;\n  background: yellow;\n  border-radius: 5px;\n}\n.tabs > li.active {\n  color: #555;\n  cursor: default;\n  background-color: #ddd;\n  border: 1px solid transparent;\n}\n.tabs:before {\n  display: table;\n  content: \" \";\n}\n.tabs:after {\n  display: table;\n  clear: both;\n  content: \" \";\n}\n.tab-close {\n  margin-left: 10px;\n  color: gray;\n  text-align: right;\n  cursor: pointer;\n}\n.tab-close:hover {\n  color: black;\n}\n.newTab {\n  padding: 5% 20%;\n}\n.border {\n  border: 1px solid #ddd;\n}\n.layerOpTable td {\n  padding: 5px;\n}\n.headers-align .mat-expansion-panel-header-title,\n.headers-align .mat-expansion-panel-header-description {\n  flex-basis: 0;\n}\n.headers-align .mat-expansion-panel-header-description {\n  justify-content: space-between;\n  align-items: center;\n}\ninput[type=file] {\n  padding: 5px;\n  margin: 5px;\n  width: 300px;\n  background-color: #f1f1f1;\n  border-radius: 0px;\n}\ninput[type=file]:hover {\n  background-color: #ddd;\n}\n.helpButtonContainer {\n  text-align: center;\n  margin-top: 20px;\n}\n.header {\n  text-align: right;\n}\n.header div {\n  display: inline-block;\n  cursor: pointer;\n}\n.header .logo {\n  text-align: right;\n  margin-right: 40px;\n  padding: 5px;\n  height: 2ex;\n}\n.header .logo a {\n  text-decoration: none;\n  color: #b01a1a;\n  font-weight: 500;\n}\n.header .helpButton {\n  position: fixed;\n  top: 0;\n  right: 0;\n  background: white;\n  border-style: solid;\n  border-color: #ddd;\n  border-width: 0 0 1px 1px;\n  border-radius: 0 0 0 50%;\n  text-align: center;\n  width: 2ex;\n  height: 2ex;\n  padding: 5px;\n}\n.header .helpButton:hover {\n  background: #f1f1f1;\n}\n.inputTable {\n  width: 100%;\n  border-collapse: collapse;\n}\n.inputTable tr {\n  transition: ease 0.2s;\n  width: 100%;\n  margin-top: 5px;\n  border-radius: 5px;\n}\n.inputTable tr.featureRow:hover {\n  background: #f2f2f2;\n}\n.inputTable tr td {\n  text-align: left;\n  width: 1%;\n  padding: 5px;\n}\n.inputTable tr td.featureRow-button img {\n  vertical-align: middle;\n  margin-bottom: 2px;\n}\n.inputTable tr td.subfeature:first-child {\n  border-left: 1px solid #ddd;\n}\n.inputTable tr td.subfeature.last {\n  border-bottom: 1px solid #ddd;\n}\n#layerlinkfield {\n  color: rgba(0, 0, 0, 0.42);\n}\n#layerlinkfield .mat-form-field-underline {\n  background: none;\n  background-image: linear-gradient(to right, rgba(0, 0, 0, 0.42) 0, rgba(0, 0, 0, 0.42) 33%, transparent 0);\n  background-size: 4px 1px;\n  background-repeat: repeat-x;\n}\n#layerlinkfield #layerLink {\n  cursor: pointer;\n}\n.layerLinks {\n  list-style: none;\n  padding-left: 0;\n  margin: 0;\n}"

/***/ }),

/***/ "./src/app/tabs/tabs.component.ts":
/*!****************************************!*\
  !*** ./src/app/tabs/tabs.component.ts ***!
  \****************************************/
/*! exports provided: TabsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsComponent", function() { return TabsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _dynamic_tabs_directive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dynamic-tabs.directive */ "./src/app/tabs/dynamic-tabs.directive.ts");
/* harmony import */ var _tab_tab_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../tab/tab.component */ "./src/app/tab/tab.component.ts");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config.service */ "./src/app/config.service.ts");
/* harmony import */ var _viewmodels_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../viewmodels.service */ "./src/app/viewmodels.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
// https://embed.plnkr.co/wWKnXzpm8V31wlvu64od/



 //import the DataService component so we can use it



var TabsComponent = /** @class */ (function () {
    function TabsComponent(_componentFactoryResolver, viewModelsService, dataService, http, configService) {
        this._componentFactoryResolver = _componentFactoryResolver;
        this.viewModelsService = viewModelsService;
        this.dataService = dataService;
        this.http = http;
        this.configService = configService;
        this.ds = null;
        this.vms = null;
        this.techniques = [];
        this.dynamicTabs = [];
        this.coloring = null;
        this.comments = null;
        this.enabledness = null;
        this.filters = null;
        this.scoreExpression = "";
        this.legendItems = null;
        this.loadURL = "";
        //   ___ _   _ ___ _____ ___  __  __ ___ _______ ___    _  _   ___   _____ ___   _ _____ ___  ___   ___ _____ _   _ ___ ___
        //  / __| | | / __|_   _/ _ \|  \/  |_ _|_  / __|   \  | \| | /_\ \ / /_ _/ __| /_\_   _/ _ \| _ \ / __|_   _| | | | __| __|
        // | (__| |_| \__ \ | || (_) | |\/| || | / /| _|| |) | | .` |/ _ \ V / | | (_ |/ _ \| || (_) |   / \__ \ | | | |_| | _|| _|
        //  \___|\___/|___/ |_| \___/|_|  |_|___/___|___|___/  |_|\_/_/ \_\_/ |___\___/_/ \_\_| \___/|_|_\ |___/ |_|  \___/|_| |_|
        // layerLinkURL = ""; //the user inputted layer link which will get parsed into a param
        this.layerLinkURLs = [];
        this.customizedConfig = [];
        this.copiedRecently = false; // true if copyLayerLink has been called recently -- reverts to false after 2 seconds
        var self = this;
        this.ds = dataService;
        this.viewModelsService = viewModelsService;
    }
    TabsComponent.prototype.ngAfterContentInit = function () {
        var _this = this;
        this.ds.getConfig().subscribe(function (config) {
            _this.viewModelsService.domain = config["domain"];
            // console.log("INITIALIZING APPLICATION FOR DOMAIN: " + this.viewModelsService.domain);
            var fragment_value = _this.getNamedFragmentValue("layerURL");
            if (fragment_value && fragment_value.length > 0) {
                var replace = true;
                for (var _i = 0, urls_1 = fragment_value; _i < urls_1.length; _i++) {
                    var url = urls_1[_i];
                    console.log("loading initial layer", url);
                    _this.loadLayerFromURL(url, replace);
                    replace = false;
                }
                if (_this.dynamicTabs.length == 0)
                    _this.newLayer(); // failed load from url, so create new blank layer
            }
            else if (config["default_layers"]["enabled"]) {
                var first = true;
                for (var _a = 0, _b = config["default_layers"]["urls"]; _a < _b.length; _a++) {
                    var url_1 = _b[_a];
                    console.log(url_1);
                    _this.loadLayerFromURL(url_1, first);
                    first = false;
                }
                // this.loadURL = config["default_layer"]["location"]
                // console.log(this.loadURL)
                // this.loadLayerFromLocalFile();
                if (_this.dynamicTabs.length == 0)
                    _this.newLayer(); // failed load from url, so create new blank layer
            }
            else {
                _this.newLayer();
            }
            var activeTabs = _this.dynamicTabs.filter(function (tab) { return tab.active; });
            // if there is no active tab set, activate the first
            if (activeTabs.length === 0) {
                _this.selectTab(_this.dynamicTabs[0]);
            }
            _this.customizedConfig = _this.configService.getFeatureList();
            // Load all layers from the global store
            _this.http.get('layers').subscribe(function (res) {
                res.forEach(function (matrix) {
                    _this.loadLayerFromURL('layer/' + matrix, false);
                    setTimeout(function () {
                        _this.dynamicTabs.sort(function (a, b) { return (a.dataContext.name < b.dataContext.name ? -1 : 1); });
                    }, 5000); // wait 5 seconds until we reorder tabs alphabetically
                });
            });
        });
    };
    /**
     * Open a new tab
     * @param  {[type]}  title               title of new tab
     * @param  {[type]}  template            template of content
     * @param  {[type]}  data                data to put in template
     * @param  {Boolean} [isCloseable=false] can this tab be closed?
     * @param  {Boolean} [replace=false]     replace the current tab with the new tab, TODO
     * @param  {Boolean} [forceNew=false]    force open a new tab even if a tab of that name already exists
     * @param  {Boolean} [dataTable=false]   is this a data-table tab? if so tab text should be editable

     */
    TabsComponent.prototype.openTab = function (title, template, data, isCloseable, replace, forceNew, dataTable) {
        if (isCloseable === void 0) { isCloseable = false; }
        if (replace === void 0) { replace = true; }
        if (forceNew === void 0) { forceNew = false; }
        if (dataTable === void 0) { dataTable = false; }
        if (!template) {
            console.error("ERROR: no template defined for tab titled ''", title, "''");
        }
        // determine if tab is already open. If it is, just change to that tab
        if (!forceNew) {
            for (var i = 0; i < this.dynamicTabs.length; i++) {
                if (this.dynamicTabs[i].title === title) {
                    this.selectTab(this.dynamicTabs[i]);
                    return;
                }
            }
        }
        // get a component factory for our TabComponent
        var componentFactory = this._componentFactoryResolver.resolveComponentFactory(_tab_tab_component__WEBPACK_IMPORTED_MODULE_2__["TabComponent"]);
        // fetch the view container reference from our anchor directive
        var viewContainerRef = this.dynamicTabPlaceholder.viewContainer;
        // alternatively...
        // let viewContainerRef = this.dynamicTabPlaceholder;
        // create a component instance
        var componentRef = viewContainerRef.createComponent(componentFactory);
        // set the according properties on our component instance
        var instance = componentRef.instance;
        instance.title = title;
        instance.template = template;
        instance.dataContext = data;
        instance.isCloseable = isCloseable;
        instance.showScoreVariables = false;
        instance.isDataTable = dataTable;
        // remember the dynamic component for rendering the
        // tab navigation headers
        // this.dynamicTabs.push(componentRef.instance as TabComponent); //don't replace
        if (!replace || this.dynamicTabs.length === 0) {
            this.dynamicTabs.push(componentRef.instance); //don't replace
            this.selectTab(this.dynamicTabs[this.dynamicTabs.length - 1]);
        }
        else {
            // find active tab index
            for (var i = 0; i < this.dynamicTabs.length; i++) {
                if (this.dynamicTabs[i].active) {
                    this.closeActiveTab(true); //close current and don't let it create a replacement tab
                    this.dynamicTabs.splice(i, 0, componentRef.instance); //replace
                    this.selectTab(this.dynamicTabs[i]);
                    return;
                }
            }
        }
    };
    /**
     * Select a given tab: deselects other tabs.
     * @param  {TabComponent} tab tab to select
     */
    TabsComponent.prototype.selectTab = function (tab) {
        // deactivate all tabs
        this.dynamicTabs.forEach(function (tab) { return tab.active = false; });
        // activate the tab the user has clicked on.
        tab.active = true;
    };
    /**
     * close a tab
     * @param  {TabComponent} tab              tab to close
     * @param  {[type]}       allowNoTab=false if true, doesn't select another tab, and won't open a new tab if there are none
     */
    TabsComponent.prototype.closeTab = function (tab, allowNoTab) {
        if (allowNoTab === void 0) { allowNoTab = false; }
        var action = 0; //controls post close-tab behavior
        // destroy tab viewmodel
        this.viewModelsService.destroyViewModel(tab.dataContext);
        for (var i = 0; i < this.dynamicTabs.length; i++) {
            if (this.dynamicTabs[i] === tab) { //close this tab
                if (this.dynamicTabs[i].active) { //is the tab we're closing currently open??
                    if (i == 0 && this.dynamicTabs.length > 1) { //closing first tab, first tab is active, and more tabs exist
                        action = 1;
                    }
                    else if (i > 0) { //closing not first tab, implicitly more tabs exist
                        action = 2;
                    }
                    else { //else closing first tab and no other tab exist
                        action = 3;
                    }
                }
                // remove the tab from our array
                this.dynamicTabs.splice(i, 1);
                // destroy our dynamically created component again
                var viewContainerRef = this.dynamicTabPlaceholder.viewContainer;
                // let viewContainerRef = this.dynamicTabPlaceholder;
                viewContainerRef.remove(i);
                break;
            }
        }
        // post close-tab behavior: select new tab?
        if (!allowNoTab) {
            switch (action) {
                case 0: //should only occur if the active tab is not closed: don't select another tab
                    break;
                case 1: //closing the first tab, more exist
                    this.selectTab(this.dynamicTabs[0]); // select first tab
                    break;
                case 2: //closing any tab other than the first
                    this.selectTab(this.dynamicTabs[0]); //select first tab
                    break;
                case 3: //closing first tab and no other tab exist
                    this.newBlankTab(); //make a new blank tab, automatically opens this tab
                    break;
                default: //should never occur
                    console.error("post closetab action not specified (this should never happen)");
            }
        }
    };
    /**
     * Close the currently selected tab
     * @param  {[type]} allowNoTab=false if true, doesn't select another tab, and won't open a new tab if there are none
     */
    TabsComponent.prototype.closeActiveTab = function (allowNoTab) {
        if (allowNoTab === void 0) { allowNoTab = false; }
        var activeTabs = this.dynamicTabs.filter(function (tab) { return tab.active; });
        if (activeTabs.length > 0) {
            // close the 1st active tab (should only be one at a time)
            this.closeTab(activeTabs[0], allowNoTab);
        }
    };
    TabsComponent.prototype.getActiveTab = function () {
        var activeTabs = this.dynamicTabs.filter(function (tab) { return tab.active; });
        return activeTabs[0];
    };
    //  _      ___   _____ ___   ___ _____ _   _ ___ ___
    // | |    /_\ \ / / __| _ \ / __|_   _| | | | __| __|
    // | |__ / _ \ V /| _||   / \__ \ | | | |_| | _|| _|
    // |____/_/ \_\_| |___|_|_\ |___/ |_|  \___/|_| |_|
    /**
     * open a new "blank" tab showing a new layer button and an open layer button
     * @param  {[type]} replace=false replace the current tab with this blank tab?
     */
    TabsComponent.prototype.newBlankTab = function (replace) {
        if (replace === void 0) { replace = false; }
        this.openTab('new tab', this.blankTab, null, true, replace, true, false);
    };
    /**
     * create a new help tab
     * @param replace=false  replace currently open tab?
     * @param forceNew=false if false, select currently open help tab if possible
     */
    TabsComponent.prototype.newHelpTab = function (replace, forceNew) {
        if (replace === void 0) { replace = false; }
        if (forceNew === void 0) { forceNew = false; }
        if (replace)
            this.closeActiveTab();
        this.openTab('help', this.helpTab, null, true, replace, false);
    };
    TabsComponent.prototype.newExporterTab = function (exportData) {
        this.openTab('render: ' + exportData.viewModel.name, this.exporterTab, exportData, true, false, true);
    };
    /**
     * Given a unique root, returns a layer name that does not conflict any existing layers, e.g 'new layer' -> 'new layer 1'
     * @param  {string} root the root string to get the non-conflicting version of
     * @return {string}      non-conflicted version
     */
    TabsComponent.prototype.getUniqueLayerName = function (root) {
        var conflictNumber = 0;
        var viewModels = this.viewModelsService.viewModels;
        function isInteger(str) {
            var n = Math.floor(Number(str));
            return String(n) === str;
        }
        for (var i = 0; i < viewModels.length; i++) {
            if (!viewModels[i].name.startsWith(root))
                continue;
            if (viewModels[i].name === root) { //case where it's "new layer" aka  "new layer 0"
                conflictNumber = Math.max(conflictNumber, 1);
                continue;
            }
            var numberPortion = viewModels[i].name.substring(root.length, viewModels[i].name.length);
            //find lowest number higher than existing number
            if (isInteger(numberPortion)) {
                conflictNumber = Math.max(conflictNumber, Number(numberPortion) + 1);
            }
        }
        // if no layers of this name exist (conflictNumber == 0) just return root
        if (conflictNumber != 0)
            root = root + conflictNumber;
        return root;
    };
    /**
     * Open a new blank layer tab
     */
    TabsComponent.prototype.newLayer = function () {
        // find non conflicting name
        var name = this.getUniqueLayerName("layer");
        // create and open VM
        var vm = this.viewModelsService.newViewModel(name);
        this.openTab(name, this.layerTab, vm, true, true, true, true);
    };
    /**
     * Get a layer score expression variable for a tab
     * @param  index index of tab
     * @return       char expression variable
     */
    TabsComponent.prototype.indexToChar = function (index) {
        var realIndex = 0;
        for (var i = 0; i < index; i++) {
            if (this.dynamicTabs[i].dataContext)
                realIndex++;
        }
        return String.fromCharCode(97 + realIndex);
    };
    /**
     * Inverse of indextoChar, maps char to the tab it corresponds to
     * @param  char score expression variable
     * @return      tab index
     */
    TabsComponent.prototype.charToIndex = function (char) {
        // console.log("searching for char", char)
        var realIndex = 0;
        for (var i = 0; i < this.dynamicTabs.length; i++) {
            if (this.dynamicTabs[i].dataContext) {
                var charHere = String.fromCharCode(97 + realIndex);
                // console.log(charHere, this.dynamicTabs[i].dataContext.name)
                realIndex++;
                if (charHere == char)
                    return i;
            }
        }
    };
    /**
     * layer layer operation
     */
    TabsComponent.prototype.layerByOperation = function () {
        // build score expression map, mapping inline variables to their actual VMs
        var scoreVariables = new Map();
        var regex = /\b[a-z]\b/g; //\b matches word boundary
        var matches = this.scoreExpression.match(regex);
        var self = this;
        if (matches) {
            matches.forEach(function (match) {
                // trim
                var index = self.charToIndex(match);
                // console.log(match, index)
                var vm = self.dynamicTabs[index].dataContext;
                scoreVariables.set(match, vm);
            });
        }
        // console.log(scoreVariables);
        var layerName = this.getUniqueLayerName("layer by operation");
        try {
            var vm = this.viewModelsService.layerLayerOperation(this.scoreExpression, scoreVariables, this.comments, this.coloring, this.enabledness, layerName, this.filters, this.legendItems);
            this.openTab(layerName, this.layerTab, vm, true, true, true, true);
        }
        catch (err) {
            console.error(err);
            alert("Layer Layer operation error: " + err.message);
        }
    };
    /**
     * Check if there's an error in the score expression (syntax, etc)
     * @return error or null if no error
     */
    TabsComponent.prototype.getScoreExpressionError = function () {
        var self = this;
        try {
            // build fake scope
            var regex = /\b[a-z]\b/g; //\b matches word boundary
            var matches = self.scoreExpression.match(regex);
            var scope_1 = {};
            if (matches) {
                var noMatch_1 = "";
                matches.forEach(function (match) {
                    // trim
                    scope_1[match] = 0;
                    // check if letter is too large
                    // console.log("chartoindex["+match+"]", self.charToIndex(match))
                    if (typeof (self.charToIndex(match)) == "undefined") {
                        noMatch_1 = "Variable " + match + " does not match any layers";
                    }
                });
                // console.log(noMatch)
                if (noMatch_1.length > 0)
                    return noMatch_1;
            }
            var result = math.eval(self.scoreExpression, scope_1);
            // console.log(result)
            return null;
        }
        catch (err) {
            // console.log(err.message)
            return err.message;
        }
    };
    /**
     * open upload new layer prompt
     */
    TabsComponent.prototype.openUploadPrompt = function () {
        var input = document.getElementById("uploader");
        input.click();
    };
    /**
     * Loads an existing layer into a tab
     */
    TabsComponent.prototype.loadLayerFromFile = function () {
        var input = document.getElementById("uploader");
        if (input.files.length < 1) {
            alert("You must select a file to upload!");
            return;
        }
        this.readJSONFile(input.files[0]);
    };
    /**
     * Retrieves a file from the input element,
     * reads the json,
     * and adds the properties to a new viewModel, and loads that viewmodel into a new layer.
     */
    TabsComponent.prototype.readJSONFile = function (file) {
        var _this = this;
        // var input = (<HTMLInputElement>document.getElementById("uploader"));
        var reader = new FileReader();
        var viewModel = this.viewModelsService.newViewModel("loading layer...");
        reader.onload = function (e) {
            var string = String(reader.result);
            try {
                viewModel.deSerialize(string);
                _this.openTab("new layer", _this.layerTab, viewModel, true, true, true, true);
            }
            catch (err) {
                console.error("ERROR: Either the file is not JSON formatted, or the file structure is invalid.", err);
                alert("ERROR: Either the file is not JSON formatted, or the file structure is invalid.");
                _this.viewModelsService.destroyViewModel(viewModel);
            }
        };
        reader.readAsText(file);
    };
    /**
     * attempt an HTTP GET to loadURL, and load the response (if it exists) as a layer.
     */
    TabsComponent.prototype.loadLayerFromURL = function (loadURL, replace) {
        var _this = this;
        // if (!loadURL.startsWith("http://") && !loadURL.startsWith("https://") && !loadURL.startsWith("FTP://")) loadURL = "https://" + loadURL;
        this.http.get(loadURL).subscribe(function (res) {
            var viewModel = _this.viewModelsService.newViewModel("loading layer...");
            try {
                viewModel.deSerialize(res);
                console.log("loaded layer from", loadURL);
                _this.openTab("new layer", _this.layerTab, viewModel, true, replace, true, true);
            }
            catch (err) {
                console.error(err);
                alert("ERROR parsing layer from " + loadURL + ", check the javascript console for more information.");
                _this.viewModelsService.destroyViewModel(viewModel);
            }
        }, function (err) {
            console.error(err);
            if (err.status == 0) {
                // no response
                alert("ERROR retrieving layer from " + loadURL + ", check the javascript console for more information.");
            }
            else {
                // response, but not a good one
                alert("ERROR retrieving layer from " + loadURL + ", check the javascript console for more information.");
            }
        });
    };
    /**
     * Add a new empty layer link to the layerLinkURLs array
     */
    TabsComponent.prototype.addLayerLink = function () {
        this.layerLinkURLs.push("");
    };
    /**
     * Remove the given layer link URL from layerLinkURLs
     * @param {number} index the index to remove
     */
    TabsComponent.prototype.removeLayerLink = function (index) {
        console.log("removing index", index);
        console.log(this.layerLinkURLs);
        if (this.layerLinkURLs.length == 1)
            this.layerLinkURLs = [];
        else
            this.layerLinkURLs.splice(index, 1);
        console.log(this.layerLinkURLs);
    };
    /**
     * Convert layerLinkURL to a query string value for layerURL query string
     * @return URL such that when opened will create navigator instance with a query String
     *         specifying layerLinkURL as the URL to fetch the default layer from
     */
    TabsComponent.prototype.getLayerLink = function () {
        // if (!this.layerLinkURL) return "";
        var str = window.location.href.split("#")[0];
        var join = "#"; //hash first, then ampersand
        for (var _a = 0, _b = this.layerLinkURLs; _a < _b.length; _a++) {
            var layerLinkURL = _b[_a];
            str += join + "layerURL=" + encodeURIComponent(layerLinkURL);
            join = "&";
        }
        for (var i = 0; i < this.customizedConfig.length; i++) {
            if (this.customizedConfig[i].subfeatures) {
                for (var j = 0; j < this.customizedConfig[i].subfeatures.length; j++) {
                    if (!this.customizedConfig[i].subfeatures[j].enabled) {
                        str += join + this.customizedConfig[i].subfeatures[j].name + "=false";
                        join = "&";
                    }
                }
            }
            else {
                if (!this.customizedConfig[i].enabled) {
                    str += join + this.customizedConfig[i].name + "=false";
                    join = "&";
                }
            }
        }
        return str;
    };
    /**
     * Select the layer link field text
     */
    TabsComponent.prototype.selectLayerLink = function () {
        var copyText = document.getElementById("layerLink");
        console.log(copyText);
        console.log(copyText.value);
        copyText.select();
    };
    /**
     * copy the created layer link to the user's clipboard
     */
    TabsComponent.prototype.copyLayerLink = function () {
        console.log("attempting copy");
        this.selectLayerLink();
        document.execCommand("Copy");
        this.copiedRecently = true;
        var self = this;
        window.setTimeout(function () { self.copiedRecently = false; }, 2000);
    };
    /**
     * Return true if the text is only letters a-z, false otherwise
     * @param  text text to eval
     * @return      true if a-z, false otherwise
     */
    TabsComponent.prototype.alphabetical = function (text) {
        return /^[a-z]+$/.test(text);
    };
    /**
     * get a key=value fragment value by key
     * @param  {string} name name of param to get the value of
     * @param  {string} url  optional, if unspecified searches in current window location. Otherwise searches this string
     * @return {string}      fragment param value
     */
    TabsComponent.prototype.getNamedFragmentValue = function (name, url) {
        if (!url)
            url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[#&]" + name + "(?:=([^&#]*)|&|#|$)", "g");
        //match as many results as exist under the name
        var results = [];
        var match = regex.exec(url);
        while (match != null) {
            results.push(decodeURIComponent(match[1].replace(/\+/g, " ")));
            match = regex.exec(url);
        }
        return results;
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('blankTab', { static: false }),
        __metadata("design:type", Object)
    ], TabsComponent.prototype, "blankTab", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('layerTab', { static: false }),
        __metadata("design:type", Object)
    ], TabsComponent.prototype, "layerTab", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('helpTab', { static: true }),
        __metadata("design:type", Object)
    ], TabsComponent.prototype, "helpTab", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('exporterTab', { static: false }),
        __metadata("design:type", Object)
    ], TabsComponent.prototype, "exporterTab", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_dynamic_tabs_directive__WEBPACK_IMPORTED_MODULE_1__["DynamicTabsDirective"], { static: false }),
        __metadata("design:type", _dynamic_tabs_directive__WEBPACK_IMPORTED_MODULE_1__["DynamicTabsDirective"])
    ], TabsComponent.prototype, "dynamicTabPlaceholder", void 0);
    TabsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'tabs',
            template: __webpack_require__(/*! raw-loader!./tabs.component.html */ "./node_modules/raw-loader/index.js!./src/app/tabs/tabs.component.html"),
            providers: [_viewmodels_service__WEBPACK_IMPORTED_MODULE_5__["ViewModelsService"], _config_service__WEBPACK_IMPORTED_MODULE_4__["ConfigService"]],
            styles: [__webpack_require__(/*! ./tabs.component.scss */ "./src/app/tabs/tabs.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"], _viewmodels_service__WEBPACK_IMPORTED_MODULE_5__["ViewModelsService"], _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"], _config_service__WEBPACK_IMPORTED_MODULE_4__["ConfigService"]])
    ], TabsComponent);
    return TabsComponent;
}());



/***/ }),

/***/ "./src/app/taxii2lib.ts":
/*!******************************!*\
  !*** ./src/app/taxii2lib.ts ***!
  \******************************/
/*! exports provided: TaxiiConnect, Server, Collections, Collection, Status */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaxiiConnect", function() { return TaxiiConnect; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Server", function() { return Server; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Collections", function() { return Collections; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Collection", function() { return Collection; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Status", function() { return Status; });
/**
 * @file
 * A TAXII 2.0 Javascript client library. Converted to Typescript by Josh Trahan 24 May 2018
 *
 * @see https://oasis-open.github.io/cti-documentation/
 *
 * @author R. Wathelet, September 2017, modified by J Trahan 24 May 2018
 * @version 0.2
 */
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
/**
 * Provide asynchronous network communications to a TAXII 2.0 server.
 *
 */
var TaxiiConnect = /** @class */ (function () {
    /**
     * provide network communication to a Taxii 2.0 server.
     * @param {String} url - the base url of the Taxii2 server, for example https://example.com/
     * @param {String} user - the user name required for authentication.
     * @param {String} password - the user password required for authentication.
     * @param {Integer} timeout - the connection timeout in millisec
     */
    function TaxiiConnect(url, user, password, timeout) {
        this.baseURL = TaxiiConnect.withoutLastSlash(url);
        this.user = user;
        this.password = password;
        this.hash = btoa(this.user + ":" + this.password);
        this.timeout = timeout ? timeout : 10000; // default timeout
        this.version = '2.0';
        // default headers configurations
        this.getConfig = {
            'method': 'get',
            'headers': new Headers({
                'Accept': 'application/vnd.oasis.taxii+json',
                'version': this.version,
                'Authorization': 'Basic ' + this.hash
            })
        };
        this.postConfig = {
            'method': 'post',
            'headers': new Headers({
                'Accept': 'application/vnd.oasis.taxii+json',
                'Content-Type': 'application/vnd.oasis.stix+json',
                'version': this.version,
                'Authorization': 'Basic ' + this.hash
            })
        };
        this.getStixConfig = {
            'method': 'get',
            'headers': new Headers({
                'Accept': 'application/vnd.oasis.stix+json',
                'version': this.version,
                'Authorization': 'Basic ' + this.hash
            })
        };
    }
    // original code from: https://github.com/jkomyno/fetch-timeout
    TaxiiConnect.prototype.timeoutPromise = function (promise, timeout, error) {
        return new Promise(function (resolve, reject) {
            setTimeout(function () { return reject(error); }, timeout);
            promise.then(resolve, reject);
        });
    };
    // original code from: https://github.com/jkomyno/fetch-timeout
    TaxiiConnect.prototype.fetchTimeout = function (url, options, timeout, error) {
        error = error || 'Timeout error';
        options = options || {};
        timeout = timeout || 10000;
        return this.timeoutPromise(fetch(url, options), timeout, error);
    };
    /**
     * send an async request (GET or POST) to the taxii2 server.
     *
     * @param {String} path - the full path to connect to.
     * @param {Object} config - the request configuration, see getConfig and postConfig for examples
     * @param {Object} filter - the filter object describing the filtering requested, this is added to the path as a query string
     * @returns {Promise} the server response in json.
     */
    TaxiiConnect.prototype.asyncFetch = function (path, config, filter) {
        return __awaiter(this, void 0, void 0, function () {
            var fullPath;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        fullPath = (filter === undefined) ? path : path + "?" + TaxiiConnect.asQueryString(filter);
                        return [4 /*yield*/, (this.fetchTimeout(fullPath, config, this.timeout, 'connection timeout')
                                .then(function (res) { return res.json(); })
                                .catch(function (err) { throw new Error("fetch error: " + err); }))];
                    case 1: return [4 /*yield*/, (_a.sent())];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * send a GET async request to the taxii2 server.
     *
     * The server response is assigned to the cache attribute of the options object, and
     * the options flag attribute is set to true if a server request was performed.
     * Otherwise if the options.flag is initially true, the cached response (options.cache) is returned and
     * no server request is performed.
     * To force a server request used invalidate(), for example: server.invalidate()
     *
     * @param {String} path - the path to connect to.
     * @param {Object} options - an option object of the form: { "cache": {}, "flag": false }
     * @param {Object} filter - the filter object describing the filtering requested, this is added to the path as a query string
     * @param {Object} config - the request configuration
     * @returns {Promise} the server response object
     */
    TaxiiConnect.prototype.fetchThis = function (path, options, filter, config) {
        return __awaiter(this, void 0, void 0, function () {
            var conf, _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        conf = config === undefined ? this.getConfig : config;
                        if (!!options.flag) return [3 /*break*/, 2];
                        _a = options;
                        return [4 /*yield*/, (this.asyncFetch(path, conf, filter))];
                    case 1:
                        _a.cache = _b.sent();
                        options.flag = true;
                        _b.label = 2;
                    case 2: return [2 /*return*/, options.cache];
                }
            });
        });
    };
    /**
     * return the url without the last slash.
     * @param {String} url - the URL string to process.
     * @returns {String} the url without the last slash.
     */
    TaxiiConnect.withoutLastSlash = function (url) {
        return (url.substr(-1) === '/') ? url.substr(0, url.length - 1) : url;
    };
    /**
     * return the url with a terminating slash.
     * @param {String} url - the URL string to process.
     * @returns {String} the url with a terminating slash.
     */
    TaxiiConnect.withLastSlash = function (url) {
        return (url.substr(-1) === '/') ? url : url + "/";
    };
    /**
     * convert a filter object into a query string.
     * @param {Object} filter - the filter object to process.
     * @returns {String} the query string corresponding to the filter object.
     */
    TaxiiConnect.asQueryString = function (filter) {
        return Object.keys(filter).map(function (k) {
            var value = (k === "added_after") ? k : "match[" + k + "]";
            return encodeURIComponent(value) + '=' + encodeURIComponent(filter[k]);
        }).join('&');
    };
    return TaxiiConnect;
}());

/**
 * Server encapsulates a discovery and api roots endpoints.
 */
var Server = /** @class */ (function () {
    /**
     * A TAXII Server endpoint representation.
     * @param {String} path - the path to the server discovery endpoint, for example "/taxii/"
     * @param {TaxiiConnect} conn - a TaxiiConnection instance providing network communications.
     */
    function Server(path, conn) {
        this.path = TaxiiConnect.withLastSlash(path);
        this.conn = conn;
        // cache represents the cached results and flag determines if it needs a re-fetch
        this.disOptions = { "cache": {}, "flag": false };
        this.apiOptions = { "cache": [], "flag": false };
    }
    /**
     * determine if the obj is empty, {}
     * @param {Object} obj - the object to test
     * @returns {Boolean} - true if empty else false
     */
    Server.isEmpty = function (obj) {
        return Object.keys(obj).length === 0 && obj.constructor === Object;
    };
    /**
     * reset the internal options flags so that the next method call of this class will
     * send a request to the server rather than retreive the results from cache.
     */
    Server.prototype.invalidate = function () {
        this.disOptions.flag = false;
        this.apiOptions.flag = false;
    };
    /**
     * retrieve the information about a TAXII Server and the list of API Roots.
     * @returns {Promise} the server discovery information object.
     */
    Server.prototype.discovery = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.conn.fetchThis(this.conn.baseURL + this.path, this.disOptions)];
            });
        });
    };
    /**
     * retrieve the api roots information objects.
     * Note: unreachable roots are not part of the results.
     *
     * API Roots are logical groupings of TAXII Channels, Collections, and related functionality.
     * Each API Root contains a set of Endpoints that a TAXII Client contacts in order to interact with the TAXII Server.
     * This returns the api roots information objects from the string urls.
     * @returns {Promise} the Array of api roots information objects
     */
    Server.prototype.api_roots = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                return [2 /*return*/, this.discovery().then(function (discovery) { return _this._getApiRoots(discovery); })];
            });
        });
    };
    /**
     * retrieve a map of key=the api root url and value=the api root object.
     *
     * API Roots are logical groupings of TAXII Channels, Collections, and related functionality.
     * Each API Root contains a set of Endpoints that a TAXII Client contacts in order to interact with the TAXII Server.
     * @returns {Promise} a Map of key=the url and value=the api root object.
     */
    Server.prototype.api_rootsMap = function () {
        return __awaiter(this, void 0, void 0, function () {
            var apiRootMap;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        apiRootMap = new Map();
                        return [4 /*yield*/, this.discovery().then(function (discovery) { return _this._getApiRoots(discovery, apiRootMap); })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, apiRootMap];
                }
            });
        });
    };
    /**
     * private function to retrieve the api roots
     * @param {discovery} discovery - a discovery object
     * @param {Map} apiRootMap - a map of key=url, value=api root object
     * @returns {Promise} the Array of api roots information objects
     */
    Server.prototype._getApiRoots = function (discovery, apiRootMap) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!!this.apiOptions.flag) return [3 /*break*/, 2];
                        // clear the cache
                        this.apiOptions.cache = [];
                        // fetch all the api_roots in parallel
                        return [4 /*yield*/, Promise.all(discovery.api_roots.map(function (url) { return __awaiter(_this, void 0, void 0, function () {
                                var apiroot;
                                return __generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, this.conn.asyncFetch(url, this.conn.getConfig)];
                                        case 1:
                                            apiroot = _a.sent();
                                            // add to the map
                                            if (apiRootMap !== undefined) {
                                                apiRootMap.set(url, apiroot);
                                            }
                                            // add to the array of results
                                            this.apiOptions.cache.push(apiroot);
                                            return [2 /*return*/];
                                    }
                                });
                            }); }))];
                    case 1:
                        // fetch all the api_roots in parallel
                        _a.sent();
                        // remove the undefined and empty elements, that is those we could not connect to.
                        this.apiOptions.cache = this.apiOptions.cache.filter(function (element) { return (element !== undefined && !Server.isEmpty(element)); });
                        this.apiOptions.flag = true;
                        _a.label = 2;
                    case 2: return [2 /*return*/, this.apiOptions.cache];
                }
            });
        });
    };
    return Server;
}());

/**
 * Collections resource endpoint.
 * A TAXII Collections is an interface to a logical repository of CTI objects
 * provided by a TAXII Server and is used by TAXII Clients to send information
 * to the TAXII Server or request information from the TAXII Server.
 * A TAXII Server can host multiple Collections per API Root, and Collections
 * are used to exchange information in a request–response manner.
 */
var Collections = /** @class */ (function () {
    // hash: string;
    /**
     * A TAXII Collections for a specific api root path.
     * The collections resource is a simple wrapper around a list of collection resources.
     * @param {String} api_root_path - the full path to the desired api root endpoint
     * @param {TaxiiConnection} conn a TaxiiConnection class instance.
     */
    function Collections(api_root_path, conn) {
        this.api_root_path = TaxiiConnect.withLastSlash(api_root_path);
        this.conn = conn;
        // cache represents the cached results and flag determines if it needs a re-fetch
        this.options = { "cache": {}, "flag": false };
    }
    /**
     * reset the internal options flags so that the next method call of this class will
     * send a request to the server rather than retreive the results from cache.
     */
    Collections.prototype.invalidate = function () {
        this.options.flag = false;
    };
    /**
     * provide information about a specific Collection hosted under this API Root.
     *
     * @param {Integer} index - the index of the desired collection object.
     * @returns {Object} a specific collection object.
     */
    Collections.prototype.get = function (index) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                if (Number.isInteger(index) && index >= 0) {
                    // return a specific collection info
                    if (!this.collectionsFlag) {
                        return [2 /*return*/, this.collections().then(function (cols) {
                                if (index < _this.options.cache.collections.length) {
                                    return _this.options.cache.collections[index];
                                }
                                else {
                                    console.log("----> in Collections get(index) invalid index value: " + index);
                                }
                            })];
                    }
                    else {
                        if (index < this.options.cache.collections.length) {
                            return [2 /*return*/, this.options.cache.collections[index]];
                        }
                        else {
                            console.log("----> in Collections get(index) invalid index value: " + index);
                        }
                    }
                }
                else {
                    console.log("----> in Collections get(index) invalid index value: " + index);
                }
                return [2 /*return*/];
            });
        });
    };
    /**
     * provide information about the Collections hosted under this API Root.
     *
     * @param {String} range - a pagination range string, for example "0-10"
     * @returns {Array} an array of collection objects
     */
    Collections.prototype.collections = function (range) {
        return __awaiter(this, void 0, void 0, function () {
            var theConfig;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        theConfig = this.conn.getConfig;
                        if (range !== undefined) {
                            theConfig = {
                                'method': 'get',
                                'headers': new Headers({
                                    'Accept': 'application/vnd.oasis.taxii+json',
                                    'version': this.conn.version,
                                    'Authorization': 'Basic ' + this.conn.hash,
                                    'Range': 'items=' + range
                                })
                            };
                        }
                        // return a list of collection info
                        return [4 /*yield*/, this.conn.fetchThis(this.api_root_path + "collections/", this.options, "", theConfig)];
                    case 1:
                        // return a list of collection info
                        _a.sent();
                        return [2 /*return*/, this.options.cache.collections];
                }
            });
        });
    };
    return Collections;
}());

/**
 * A Collection resource endpoint.
 */
var Collection = /** @class */ (function () {
    /**
     * Collection resource endpoint.
     * @param {CollectionInfoObject} collectionInfo - the collection object of this endpoint.
     * @param {String} api_root_path - the full path to the desired api root endpoint.
     * @param {TaxiiConnection} conn - a TaxiiConnection class instance.
     */
    function Collection(collectionInfo, api_root_path, conn) {
        this.collectionInfo = collectionInfo;
        this.api_root_path = TaxiiConnect.withLastSlash(api_root_path);
        this.conn = conn;
        // construct the path
        this.path = this.api_root_path + "collections/" + collectionInfo.id + "/";
        // cache represents the cached results and flag determines if it needs a re-fetch
        this.colOptions = { "cache": {}, "flag": false };
        this.objsOptions = { "cache": {}, "flag": false };
        this.objOptions = { "cache": {}, "flag": false };
        this.manOptions = { "cache": {}, "flag": false };
    }
    /**
     * reset the internal options flags so that the next method call of this class will
     * send a request to the server rather than retreive the results from cache.
     */
    Collection.prototype.invalidate = function () {
        this.colOptions.flag = false;
        this.objsOptions.flag = false;
        this.objOptions.flag = false;
        this.manOptions.flag = false;
    };
    /**
     * check that the collection allows reading, if true then return the function passed in
     * else log an error
     * @param {Function} func - the function to return if the collection allows reading it
     * @returns {Function} the function if this collection allow reading else undefined
     */
    Collection.prototype.ifCanRead = function (func) {
        if (this.collectionInfo.can_read) {
            return func;
        }
        else {
            console.log("this collection does not allow reading: \n" + JSON.stringify(this.collectionInfo));
        }
    };
    /**
     * check that the collection allows writing, if true then return the function passed in else log an error
     * @param {Function} func - the function to return if the collection allows writing it
     * @returns {Function} the function if this collection allow writing else undefined
     */
    Collection.prototype.ifCanWrite = function (func) {
        if (this.collectionInfo.can_write) {
            return func;
        }
        else {
            console.log("this collection does not allow writing: \n" + JSON.stringify(this.collectionInfo));
        }
    };
    /**
     * retrieve this Collection object.
     * @returns {Promise} the Collection object
     */
    Collection.prototype.get = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.ifCanRead(this.conn.fetchThis(this.path, this.colOptions))];
            });
        });
    };
    /**
     * retrieve a STIX-2 bundle from this Collection.
     *
     * @param {Object} filter - the filter object describing the filtering requested, this is added to the path as a query string.
     * For example: {"added_after": "2016-02-01T00:00:01.000Z"}
     *              {"type": ["incident","ttp","actor"]}
     * @param {String} range - a pagination range string, for example "0-10"
     * @returns {Promise} the Bundle with the STIX-2 objects of this collection
     */
    Collection.prototype.getObjects = function (filter, range) {
        return __awaiter(this, void 0, void 0, function () {
            var theConfig;
            return __generator(this, function (_a) {
                theConfig = this.conn.getStixConfig;
                if (range !== undefined) {
                    theConfig = {
                        'method': 'get',
                        'headers': new Headers({
                            'Accept': 'application/vnd.oasis.stix+json',
                            'version': this.conn.version,
                            'Authorization': 'Basic ' + this.conn.hash,
                            'Range': 'items=' + range
                        })
                    };
                }
                return [2 /*return*/, this.ifCanRead(this.conn.fetchThis(this.path + "objects/", this.objsOptions, filter, theConfig))];
            });
        });
    };
    /**
     * retrieve a specific STIX-2 object from this collection objects bundle.
     *
     * @param {String} obj_id - the STIX-2 object id to retrieve
     * @param {Object} filter - the filter object describing the filtering requested, this is added to the path as a query string.
     * For example: {"version": "2016-01-01T01:01:01.000Z"}
     */
    Collection.prototype.getObject = function (obj_id, filter) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, (this.ifCanRead(this.conn.fetchThis(this.path + "objects/" + obj_id + "/", this.objOptions, filter, this.conn.getStixConfig)
                            .then(function (bundle) { return bundle.objects.find(function (obj) { return obj.id === obj_id; }); })))];
                    case 1: return [4 /*yield*/, (_a.sent())];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * add a STIX-2 bundle object to this Collection objects.
     * @param {Bundle} bundle - the STIX-2 bundle object to add
     * @return {Status} a status object
     */
    Collection.prototype.addObject = function (bundle) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.ifCanWrite(this.conn.asyncFetch(this.path + "objects/", this.conn.postConfig))];
            });
        });
    };
    /**
     * retrieve all manifests about objects from this Collection.
     * Manifests are metadata about the objects.
     *
     * @param {Object} filter - the filter object describing the filtering requested, this is added to the path as a query string.
     * @param {String} range - a pagination range string, for example "0-10"
     * @return {Array} an array of manifest entries object
     */
    Collection.prototype.getManifests = function (filter, range) {
        return __awaiter(this, void 0, void 0, function () {
            var theConfig, _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        theConfig = this.conn.getConfig;
                        if (range !== undefined) {
                            theConfig = {
                                'method': 'get',
                                'headers': new Headers({
                                    'Accept': 'application/vnd.oasis.taxii+json',
                                    'version': this.conn.version,
                                    'Authorization': 'Basic ' + this.conn.hash,
                                    'Range': 'items=' + range
                                })
                            };
                        }
                        _a = this.ifCanRead;
                        return [4 /*yield*/, this.conn.fetchThis(this.path + "manifest/", this.manOptions, filter, theConfig)];
                    case 1:
                        _a.apply(this, [_b.sent()]);
                        return [2 /*return*/, this.manOptions.cache.objects];
                }
            });
        });
    };
    /**
     * retrieve the manifest about a specific object (obj_id) from this Collection.
     * Manifests are metadata about the objects.
     *
     * @param {String} obj_id - the STIX-2 object id of the manifest to retrieve.
     * @param {Object} filter - the filter object describing the filtering requested, this is added to the path as a query string.
     * @return {Object} a manifest entry of the desired STIX-2 object.
     */
    Collection.prototype.getManifest = function (obj_id, filter) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, (this.getManifests(filter).then(function (objects) { return objects.find(function (obj) { return obj.id === obj_id; }); }))];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    return Collection;
}());

/**
 * This Endpoint provides information about the status of a previous request.
 * In TAXII 2.0, the only request that can be monitored is one to add objects to a Collection.
 */
var Status = /** @class */ (function () {
    /**
     * provide information about the status of a previous request.
     * @param {String} api_root_path - the full path to the desired api root
     * @param {String} status_id - the identifier of the status message being requested, for STIX objects, their id.
     * @param {TaxiiConnection} conn - a TaxiiConnection class instance.
     */
    function Status(api_root_path, status_id, conn) {
        this.api_root_path = TaxiiConnect.withLastSlash(api_root_path);
        this.status_id = status_id;
        this.conn = conn;
        this.path = this.api_root_path + "status/" + status_id + "/";
    }
    /**
     * retrieve the Status information about a request to add objects to a Collection.
     * @return {Promise} the status object
     */
    Status.prototype.get = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.conn.asyncFetch(this.path, this.conn.getConfig)];
            });
        });
    };
    return Status;
}());



/***/ }),

/***/ "./src/app/viewmodels.service.ts":
/*!***************************************!*\
  !*** ./src/app/viewmodels.service.ts ***!
  \***************************************/
/*! exports provided: ViewModelsService, Gradient, Gcolor, ViewModel, TechniqueVM, Filter, Metadata */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewModelsService", function() { return ViewModelsService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Gradient", function() { return Gradient; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Gcolor", function() { return Gcolor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewModel", function() { return ViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TechniqueVM", function() { return TechniqueVM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Filter", function() { return Filter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Metadata", function() { return Metadata; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./data.service */ "./src/app/data.service.ts");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./globals */ "./src/app/globals.ts");
/* harmony import */ var is_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! is_js */ "./node_modules/is_js/is.js");
/* harmony import */ var is_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(is_js__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


 //global variables

var ViewModelsService = /** @class */ (function () {
    function ViewModelsService(dataService) {
        this.dataService = dataService;
        this.domain = "mitre-mobile";
        this.viewModels = [];
        this.nonce = 0;
        // attempt to restore viewmodels
        // console.log(this.getCookie("viewModels"))
        // this.saveViewModelsCookies()
    }
    /**
     * Create and return a new viewModel
     * @param {string} name the viewmodel name
     * @return {ViewModel} the created ViewModel
     */
    ViewModelsService.prototype.newViewModel = function (name) {
        var vm = new ViewModel(name, this.domain, "vm" + this.getNonce());
        this.viewModels.push(vm);
        // console.log("created new viewModel", this.viewModels)
        // this.saveViewModelsCookies()
        return vm;
    };
    /**
     * Get a nonce.
     * @return a number that will never be regenerated by sequential calls to getNonce.
     *         Note: this applies on a session-by-session basis, nonces are not
     *         unique between app instances.
     */
    ViewModelsService.prototype.getNonce = function () {
        return this.nonce++;
    };
    /**
     * Destroy the viewmodel completely Nessecary if tab is closed!
     * @param vm viewmodel to destroy.
     */
    ViewModelsService.prototype.destroyViewModel = function (vm) {
        for (var i = 0; i < this.viewModels.length; i++) {
            if (this.viewModels[i] == vm) {
                // console.log("destroying viewmodel", vm)
                this.viewModels.splice(i, 1);
                return;
            }
        }
    };
    /**
     * layer combination operation
     * @param  scoreExpression math expression of score expression
     * @param  scoreVariables  variables in math expression, mapping to viewmodel they correspond to
     * @param  comments           what viewmodel to inherit comments from
     * @param  coloring           what viewmodel to inherit manual colors from
     * @param  enabledness        what viewmodel to inherit state from
     * @param  layerName          new layer name
     * @param  filters            viewmodel to inherit filters from
     * @return                    new viewmodel inheriting above properties
     */
    ViewModelsService.prototype.layerLayerOperation = function (scoreExpression, scoreVariables, comments, coloring, enabledness, layerName, filters, legendItems) {
        var result = new ViewModel("layer by operation", this.domain, "vm" + this.getNonce());
        if (scoreExpression) {
            scoreExpression = scoreExpression.toLowerCase(); //should be enforced by input, but just in case
            var score_min_1 = Infinity;
            var score_max_1 = -Infinity;
            //get list of all technique IDs used in the VMs
            var techniqueIDs_1 = new Set();
            scoreVariables.forEach(function (vm, key) {
                vm.techniqueVMs.forEach(function (techniqueVM, techniqueID) {
                    techniqueIDs_1.add(techniqueID);
                });
            });
            //attempt to evaluate without a scope to catch the case of a static assignment
            try {
                // evaluate with an empty scope
                var mathResult = math.eval(scoreExpression, {});
                // if it didn't except after this, it evaluated to a single result.
                console.log("score expression evaluated to single result to be applied to all techniques");
                if (is_js__WEBPACK_IMPORTED_MODULE_3__["boolean"](mathResult)) {
                    mathResult = mathResult ? "1" : "0"; //boolean to binary
                }
                else if (is_js__WEBPACK_IMPORTED_MODULE_3__["not"].number(mathResult)) { //user inputted something weird, complain about it
                    throw { message: "math result ( " + mathResult + " ) is not a number" };
                }
                // if it didn't error, and outputted a single value, apply this to all techniques.
                result.initializeScoresTo = String(mathResult); //initialize scores to this value
                score_min_1 = mathResult;
                score_max_1 = mathResult;
            }
            catch (err) { //couldn't evaluate with empty scope, build scope for each technique
                // compute the score of each techniqueID
                techniqueIDs_1.forEach(function (technique_id) {
                    var new_tvm = new TechniqueVM(technique_id);
                    var scope = {};
                    var misses = 0; //number of times a VM is missing the value
                    scoreVariables.forEach(function (vm, key) {
                        var scoreValue;
                        if (!vm.hasTechniqueVM(technique_id)) { //missing technique
                            scoreValue = 0;
                            misses++;
                        }
                        else { //technique exists
                            var score = vm.getTechniqueVM(technique_id).score;
                            if (score == "") {
                                scoreValue = 0;
                                misses++;
                            }
                            else if (isNaN(Number(score))) {
                                scoreValue = 0;
                                misses++;
                            }
                            else {
                                scoreValue = Number(score);
                            }
                        }
                        scope[key] = scoreValue;
                    });
                    //don't record a result if none of VMs had a score for this technique
                    //did at least one technique have a score for this technique?
                    if (misses < scoreVariables.size) {
                        // console.log(scope);
                        var mathResult = math.eval(scoreExpression, scope);
                        if (is_js__WEBPACK_IMPORTED_MODULE_3__["boolean"](mathResult)) {
                            mathResult = mathResult ? "1" : "0"; //boolean to binary
                        }
                        else if (is_js__WEBPACK_IMPORTED_MODULE_3__["not"].number(mathResult)) { //user inputted something weird, complain about it
                            throw { message: "math result ( " + mathResult + " ) is not a number" };
                        }
                        new_tvm.score = String(mathResult);
                        result.techniqueVMs.set(technique_id, new_tvm);
                        score_min_1 = Math.min(score_min_1, mathResult);
                        score_max_1 = Math.max(score_max_1, mathResult);
                    }
                });
            }
            //don't do gradient if there's no range of values
            if (score_min_1 != score_max_1) {
                // set up gradient according to result range
                if (score_min_1 != Infinity)
                    result.gradient.minValue = score_min_1;
                if (score_max_1 != -Infinity)
                    result.gradient.maxValue = score_max_1;
                // if it's a binary range, set to whiteblue gradient
                if (score_min_1 == 0 && score_max_1 == 1)
                    result.gradient.setGradientPreset("whiteblue");
            }
        }
        /**
         * Inherit a field from a vm
         * @param  {ViewModel} inherit_vm the viewModel to inherit from
         * @param  {string}    fieldname  the field to inherit from the viewmodel
         */
        function inherit(inherit_vm, fieldname) {
            // console.log("inherit", fieldname)
            inherit_vm.techniqueVMs.forEach(function (inherit_TVM) {
                var tvm = result.hasTechniqueVM(inherit_TVM.technique_tactic_union_id) ? result.getTechniqueVM(inherit_TVM.technique_tactic_union_id) : new TechniqueVM(inherit_TVM.technique_tactic_union_id);
                tvm[fieldname] = inherit_TVM[fieldname];
                // console.log(inherit_TVM.techniqueName, "->", tvm)
                result.techniqueVMs.set(inherit_TVM.technique_tactic_union_id, tvm);
            });
        }
        if (comments)
            inherit(comments, "comment");
        if (coloring)
            inherit(coloring, "color");
        if (enabledness)
            inherit(enabledness, "enabled");
        if (filters) { //copy filter settings
            result.filters = JSON.parse(JSON.stringify(filters.filters));
        }
        if (legendItems) {
            result.legendItems = JSON.parse(JSON.stringify(legendItems.legendItems));
        }
        result.name = layerName;
        // console.log(result)
        this.viewModels.push(result);
        result.updateGradient();
        return result;
    }; //end layer layer operation
    ViewModelsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_data_service__WEBPACK_IMPORTED_MODULE_1__["DataService"]])
    ], ViewModelsService);
    return ViewModelsService;
}());

/**
 * Gradient class used by viewmodels
 */
var Gradient = /** @class */ (function () {
    function Gradient() {
        //official colors used in gradients:
        this.colors = [new Gcolor("red"), new Gcolor("green")]; //current colors
        // options: string[] = ["white", "red", "orange", "yellow", "green", "blue", "purple"]; //possible colors
        this.options = ["#ffffff", "#ff6666", "#ffaf66", "#ffe766", "#8ec843", "#66b1ff", "#ff66f4"]; //possible colors
        this.minValue = 0;
        this.maxValue = 100;
        //presets in dropdown menu
        this.presets = {
            redgreen: [new Gcolor("#ff6666"), new Gcolor("#ffe766"), new Gcolor("#8ec843")],
            greenred: [new Gcolor("#8ec843"), new Gcolor("#ffe766"), new Gcolor("#ff6666")],
            bluered: [new Gcolor("#66b1ff"), new Gcolor("#ff66f4"), new Gcolor("#ff6666")],
            redblue: [new Gcolor("#ff6666"), new Gcolor("#ff66f4"), new Gcolor("#66b1ff")],
            whiteblue: [new Gcolor("#ffffff"), new Gcolor("#66b1ff")],
            whitered: [new Gcolor("#ffffff"), new Gcolor("#ff6666")]
        };
        this.setGradientPreset('redgreen');
    }
    /**
     * Create a string version of this gradient
     * @return string version of gradient
     */
    Gradient.prototype.serialize = function () {
        var colorList = [];
        var self = this;
        this.colors.forEach(function (gColor) {
            var hexstring = (tinycolor(gColor.color).toHexString());
            colorList.push(hexstring);
        });
        var rep = {
            "colors": colorList,
            "minValue": this.minValue,
            "maxValue": this.maxValue,
        };
        return JSON.stringify(rep, null, "\t");
    };
    /**
     * Restore this gradient from the given serialized representation
     * @param  rep serialized gradient
     */
    Gradient.prototype.deSerialize = function (rep) {
        var obj = JSON.parse(rep);
        var isColorStringArray = function (check) {
            for (var i = 0; i < check.length; i++) {
                if (typeof (check[i]) !== "string" || !tinycolor(check[i]).isValid()) {
                    console.error("TypeError:", check[i], "(", typeof (check[i]), ")", "is not a color-string");
                    return false;
                }
            }
            return true;
        };
        if (isColorStringArray(obj.colors)) {
            this.colors = [];
            var self_1 = this;
            obj.colors.forEach(function (hex) {
                self_1.colors.push(new Gcolor(hex));
            });
        }
        else
            console.error("TypeError: gradient colors field is not a color-string[]");
        this.minValue = obj.minValue;
        this.maxValue = obj.maxValue;
        this.updateGradient();
    };
    /**
     * Convert a preset to tinycolor array
     * @param  preset preset name from preset array
     * @return        [description]
     */
    Gradient.prototype.presetToTinyColor = function (preset) {
        var colorarray = [];
        var self = this;
        this.presets[preset].forEach(function (gcolor) {
            colorarray.push(gcolor.color);
        });
        return tinygradient(colorarray).css('linear', 'to right');
    };
    /**
     * set this gradient to use the preset
     * @param  preset preset to use
     */
    Gradient.prototype.setGradientPreset = function (preset) {
        this.colors = this.presets[preset];
        this.updateGradient();
    };
    /**
     * recompute gradient
     */
    Gradient.prototype.updateGradient = function () {
        var colorarray = [];
        var self = this;
        this.colors.forEach(function (colorobj) {
            // figure out what kind of color this is
            // let format = tinycolor(colorobj.color).getFormat();
            // if (format == "name" && colorobj.color in self.labelToColor)
            colorarray.push(colorobj.color);
        });
        this.gradient = tinygradient(colorarray);
        this.gradientRGB = this.gradient.rgb(100);
    };
    /**
     * Add a color to the end of the gradient
     */
    Gradient.prototype.addColor = function () {
        this.colors.push(new Gcolor(this.colors[this.colors.length - 1].color));
    };
    /**
     * Remove color at the given index
     * @param index index to remove color at
     */
    Gradient.prototype.removeColor = function (index) {
        this.colors.splice(index, 1);
    };
    // get the gradient color for a given value in the scale. Value is string format number
    Gradient.prototype.getColor = function (valueString) {
        if (!this.gradient)
            this.updateGradient();
        var value;
        if (valueString.length == 0)
            return;
        else
            value = Number(valueString);
        if (value >= this.maxValue) {
            return this.gradientRGB[this.gradientRGB.length - 1];
        }
        if (value <= this.minValue) {
            return this.gradientRGB[0];
        }
        var index = (value - this.minValue) / (this.maxValue - this.minValue) * 100;
        // console.log(value, "->", index)
        return this.gradientRGB[Math.round(index)];
    };
    return Gradient;
}());

//a color in the gradient
var Gcolor = /** @class */ (function () {
    function Gcolor(color) {
        this.color = color;
    }
    return Gcolor;
}());

;
//semi-synonymous with "layer"
var ViewModel = /** @class */ (function () {
    function ViewModel(name, domain, uid) {
        this.description = ""; //layer description
        this.version = "";
        this.metadata = [];
        /*
         * sorting int meanings (see data-table.filterTechniques()):
         * 0: ascending alphabetically
         * 1: descending alphabetically
         * 2: ascending numerically
         * 3: descending numerically
         */
        this.sorting = 0;
        /*
         * viewMode int meanings
         * 0: full table
         * 1: compact table (previosly: minitable)
         * 2: mini table
         */
        this.viewMode = 0;
        this.hideDisabled = false; //are disabled techniques hidden?
        this.highlightedTactic = "";
        this.highlightedTechnique = null;
        this.hoverTactic = "";
        this.gradient = new Gradient(); //gradient for scores
        this.backgroundPresets = ['#e60d0d', '#fc3b3b', '#fc6b6b', '#fca2a2', '#e6550d', '#fd8d3c', '#fdae6b', '#fdd0a2', '#e6d60d', '#fce93b', '#fcf26b', '#fcf3a2', '#31a354', '#74c476', '#a1d99b', '#c7e9c0', '#3182bd', '#6baed6', '#9ecae1', '#c6dbef', '#756bb1', '#9e9ac8', '#bcbddc', '#dadaeb', '#636363', '#969696', '#bdbdbd', '#d9d9d9'];
        this.legendColorPresets = [];
        this.selectTechniquesAcrossTactics = true;
        this.needsToConstructTechniqueVMs = false;
        this.legacyTechniques = [];
        this.initializeScoresTo = ""; //value to initialize scores to
        this.techIDtoUIDMap = {};
        this.techUIDtoIDMap = {};
        this.showTacticRowBackground = false;
        this.tacticRowBackground = "#dddddd";
        //  _____ ___ ___ _  _ _  _ ___ ___  _   _ ___     _   ___ ___
        // |_   _| __/ __| || | \| |_ _/ _ \| | | | __|   /_\ | _ \_ _|
        //   | | | _| (__| __ | .` || | (_) | |_| | _|   / _ \|  _/| |
        //   |_| |___\___|_||_|_|\_|___\__\_\\___/|___| /_/ \_\_| |___|
        this.techniqueVMs = new Map(); //configuration for each technique
        //  ___ ___ ___ _____ ___ _  _  ___     _   ___ ___
        // | __|   \_ _|_   _|_ _| \| |/ __|   /_\ | _ \_ _|
        // | _|| |) | |  | |  | || .` | (_ |  / _ \|  _/| |
        // |___|___/___| |_| |___|_|\_|\___| /_/ \_\_| |___|
        this.selectedTechniques = []; //technique_id array of selected techniques
        this.legendItems = [];
        this.domain = domain;
        // console.log("INITIALIZING VIEW MODEL FOR DOMAIN: " + this.domain);
        this.filters = new Filter(this.domain);
        this.name = name;
        this.version = _globals__WEBPACK_IMPORTED_MODULE_2__["layer_version"];
        this.uid = uid;
    }
    ViewModel.prototype.changeTechniqueIDSelectionLock = function () {
        this.selectTechniquesAcrossTactics = !this.selectTechniquesAcrossTactics;
    };
    ViewModel.prototype.getTechniqueIDFromUID = function (technique_tactic_union_id) {
        return this.techIDtoUIDMap[technique_tactic_union_id];
    };
    ViewModel.prototype.getTechniquesUIDFromID = function (technique_id) {
        return this.techIDtoUIDMap[technique_id];
    };
    ViewModel.prototype.setTechniqueMaps = function (techIDtoUIDMapt, techUIDtoIDMapt) {
        this.techIDtoUIDMap = Object.freeze(techIDtoUIDMapt);
        this.techUIDtoIDMap = Object.freeze(techUIDtoIDMapt);
    };
    // Getter
    ViewModel.prototype.getTechniqueVM = function (technique_tactic_union_id) {
        return this.techniqueVMs.get(technique_tactic_union_id);
    };
    // Setter
    ViewModel.prototype.setTechniqueVM = function (techniqueVM) {
        if (this.techniqueVMs.has(techniqueVM.technique_tactic_union_id))
            this.techniqueVMs.delete(techniqueVM.technique_tactic_union_id);
        this.techniqueVMs.set(techniqueVM.technique_tactic_union_id, techniqueVM);
    };
    //checker
    ViewModel.prototype.hasTechniqueVM = function (technique_tactic_union_id) {
        return this.techniqueVMs.has(technique_tactic_union_id);
    };
    /**
     * Add a technique to the current selection
     * @param {Technique} technique technique to add
     */
    ViewModel.prototype.addToTechniqueSelection = function (technique) {
        if (!this.selectTechniquesAcrossTactics) {
            if (!this.isTechniqueSelected(technique))
                this.selectedTechniques.push(technique.technique_tactic_union_id);
        }
        else {
            var map = Object.freeze(this.techIDtoUIDMap);
            var allTechniquesWithID = JSON.parse(JSON.stringify(map[technique.technique_id]));
            for (var i = 0; i < allTechniquesWithID.length; i++) {
                var item = JSON.parse(JSON.stringify(allTechniquesWithID[i]));
                if (!this.isTechniqueSelected_id(item))
                    this.selectedTechniques.push(item);
            }
        }
    };
    /**
     * Add a technique to the current selection
     * @param {string} technique_tactic_union_id techniqueID of technique to add
     */
    ViewModel.prototype.addToTechniqueSelection_id = function (technique_tactic_union_id) {
        if (!this.selectTechniquesAcrossTactics) {
            if (!this.isTechniqueSelected_id(technique_tactic_union_id))
                this.selectedTechniques.push(technique_tactic_union_id);
        }
        else {
            var map = Object.freeze(this.techIDtoUIDMap);
            //var map = Object.freeze(this.techUIDtoIDMap);
            var technique_id = this.techUIDtoIDMap[technique_tactic_union_id];
            var allTechniquesWithID = JSON.parse(JSON.stringify(map[technique_id]));
            for (var i = 0; i < allTechniquesWithID.length; i++) {
                var item = JSON.parse(JSON.stringify(allTechniquesWithID[i]));
                if (!this.isTechniqueSelected_id(item))
                    this.selectedTechniques.push(item);
            }
        }
    };
    ViewModel.prototype.addToTechniqueSelection_technique_id = function (technique_id) {
        var mapIDtoUID = Object.freeze(this.techIDtoUIDMap);
        var allTechniquesWithID = JSON.parse(JSON.stringify(mapIDtoUID[technique_id]));
        for (var i = 0; i < allTechniquesWithID.length; i++) {
            var item = JSON.parse(JSON.stringify(allTechniquesWithID[i]));
            if (!this.isTechniqueSelected_id(item))
                this.selectedTechniques.push(item);
        }
    };
    ViewModel.prototype.removeFromTechniqueSelection_technique_id = function (technique_id) {
        var map = Object.freeze(this.techIDtoUIDMap);
        var allTechniquesWithID = JSON.parse(JSON.stringify(map[technique_id]));
        for (var i = 0; i < allTechniquesWithID.length; i++) {
            this.removeFromTechniqueSelectionIndividual(allTechniquesWithID[i]);
        }
    };
    /**
     * Remove the technique from the current selection
     * @param {Technique} technique technique to remove
     */
    ViewModel.prototype.removeFromTechniqueSelection = function (technique) {
        if (!this.selectTechniquesAcrossTactics) {
            if (this.isTechniqueSelected(technique)) {
                var index = this.selectedTechniques.indexOf(technique.technique_tactic_union_id);
                this.selectedTechniques.splice(index, 1);
            }
        }
        else {
            var map = Object.freeze(this.techIDtoUIDMap);
            var allTechniquesWithID = JSON.parse(JSON.stringify(map[technique.technique_id]));
            for (var i = 0; i < allTechniquesWithID.length; i++) {
                this.removeFromTechniqueSelectionIndividual(allTechniquesWithID[i]);
            }
        }
    };
    ViewModel.prototype.removeFromTechniqueSelectionIndividual = function (technique_tactic_union_id) {
        if (this.isTechniqueSelected_id(technique_tactic_union_id)) {
            if (this.selectedTechniques.length > 1) {
                var index = this.selectedTechniques.indexOf(technique_tactic_union_id);
                this.selectedTechniques.splice(index, 1);
            }
            else {
                this.clearTechniqueSelection();
            }
        }
    };
    /**
     * Remove the technique from the current selection
     * @param {Technique} technique techniqueID of technique to remove
     */
    ViewModel.prototype.removeFromTechniqueSelection_id = function (technique_tactic_union_id) {
        if (!this.selectTechniquesAcrossTactics) {
            if (this.isTechniqueSelected_id(technique_tactic_union_id)) {
                var index = this.selectedTechniques.indexOf(technique_tactic_union_id);
                this.selectedTechniques.splice(index, 1);
            }
        }
        else {
            var map1 = Object.freeze(this.techUIDtoIDMap);
            var map = Object.freeze(this.techIDtoUIDMap);
            var technique_id = map1[technique_tactic_union_id];
            var allTechniquesWithID = JSON.parse(JSON.stringify(map[technique_id]));
            for (var i = 0; i < allTechniquesWithID.length; i++) {
                this.removeFromTechniqueSelectionIndividual(allTechniquesWithID[i]);
            }
        }
    };
    /**
     * Replace the current selection of techniques with the given technique
     * @param {Technique} technique technique to replace selection with
     */
    ViewModel.prototype.replaceTechniqueSelection = function (technique) {
        if (!this.selectTechniquesAcrossTactics) {
            this.selectedTechniques = [technique.technique_tactic_union_id];
        }
        else {
            this.selectedTechniques = JSON.parse(JSON.stringify(this.techIDtoUIDMap[technique.technique_id]));
        }
    };
    /**
     * Unselect all techniques
     */
    ViewModel.prototype.clearTechniqueSelection = function () {
        this.selectedTechniques = [];
    };
    /**
     * Select all techniques
     */
    ViewModel.prototype.selectAllTechniques = function () {
        this.clearTechniqueSelection();
        this.invertSelection();
        // console.log(self.selectedTechniques)
    };
    /**
     * Set all selected techniques to deselected, and select all techniques not currently selected
     */
    ViewModel.prototype.invertSelection = function () {
        var backup_selected = JSON.parse(JSON.stringify(this.selectedTechniques)); // deep copy
        var self = this;
        this.clearTechniqueSelection();
        this.techniqueVMs.forEach(function (tvm, key) {
            if (!backup_selected.includes(tvm.technique_tactic_union_id))
                self.selectedTechniques.push(tvm.technique_tactic_union_id);
        });
    };
    /**
     * are all techniques currently being edited?
     * @return [description]
     */
    ViewModel.prototype.isEditingAllTechniques = function () {
        var backup_selected = JSON.stringify(this.selectedTechniques); // deep copy
        this.selectAllTechniques();
        var all = JSON.stringify(this.selectedTechniques); // deep copy
        this.selectedTechniques = JSON.parse(backup_selected);
        return backup_selected == all;
    };
    /**
     * Return true if the given technique is selected, false otherwise
     * @param  {[type]}  technique the technique to check
     * @return {boolean}           true if selected, false otherwise
     */
    ViewModel.prototype.isTechniqueSelected = function (technique) {
        return this.selectedTechniques.includes(technique.technique_tactic_union_id);
    };
    /**
     * Return true if the given technique is selected, false otherwise
     * @param  {string}  technique_tactic_union_id the techniqueID to check
     * @return {boolean}           true if selected, false otherwise
     */
    ViewModel.prototype.isTechniqueSelected_id = function (technique_tactic_union_id) {
        return this.selectedTechniques.includes(technique_tactic_union_id);
    };
    /**
     * return the number of selected techniques
     * @return {number} the number of selected techniques
     */
    ViewModel.prototype.getSelectedTechniqueCount = function () {
        var result = 0;
        if (this.selectTechniquesAcrossTactics) {
            var techniqueIDs = [];
            for (var i = 0; i < this.selectedTechniques.length; i++) {
                var techniqueID = this.techUIDtoIDMap[this.selectedTechniques[i]];
                if (!techniqueIDs.includes(techniqueID)) {
                    techniqueIDs.push(techniqueID);
                }
            }
            result = techniqueIDs.length;
        }
        else {
            return this.selectedTechniques.length;
        }
        return result;
    };
    /**
     * Return true if currently editing any techniques, false otherwise
     * @return {boolean} true if currently editing any techniques, false otherwise
     */
    ViewModel.prototype.isCurrentlyEditing = function () {
        return this.getSelectedTechniqueCount() > 0;
    };
    /**
     * edit the selected techniques
     * @param {string} field the field to edit
     * @param {any}    value the value to place in the field
     */
    ViewModel.prototype.editSelectedTechniques = function (field, value) {
        for (var i = 0; i < this.selectedTechniques.length; i++) {
            var tvm = this.getTechniqueVM(this.selectedTechniques[i]);
            tvm[field] = value;
        }
    };
    /**
     * Reset the selected techniques' annotations to their default values
     */
    ViewModel.prototype.resetSelectedTechniques = function () {
        for (var i = 0; i < this.selectedTechniques.length; i++) {
            this.getTechniqueVM(this.selectedTechniques[i]).score = "";
            this.getTechniqueVM(this.selectedTechniques[i]).comment = "";
            this.getTechniqueVM(this.selectedTechniques[i]).color = "";
            this.getTechniqueVM(this.selectedTechniques[i]).enabled = true;
        }
    };
    /**
     * Get get a common value from the selected techniques
     * @param  field the field to get the common value from
     * @return       the value of the field if all selected techniques have the same value, otherwise ""
     */
    ViewModel.prototype.getEditingCommonValue = function (field) {
        if (!this.isCurrentlyEditing())
            return "";
        var commonValue = this.getTechniqueVM(this.selectedTechniques[0])[field];
        for (var i = 1; i < this.selectedTechniques.length; i++) {
            if (this.getTechniqueVM(this.selectedTechniques[i])[field] != commonValue)
                return "";
        }
        return commonValue;
    };
    /**
     * add a new blank metadata to the metadata list, for editing in UI
     */
    ViewModel.prototype.addMetadata = function () {
        var m = new Metadata();
        this.metadata.push(m);
    };
    /**
     * remove a metadata from the metadata list
     * @param index the index to remove from the list
     */
    ViewModel.prototype.removeMetadata = function (index) {
        this.metadata.splice(index, 1);
    };
    //  ___ ___ ___ ___   _   _    ___ ____  _ _____ ___ ___  _  _
    // / __| __| _ \_ _| /_\ | |  |_ _|_  / /_\_   _|_ _/ _ \| \| |
    // \__ \ _||   /| | / _ \| |__ | | / / / _ \| |  | | (_) | .` |
    // |___/___|_|_\___/_/ \_\____|___/___/_/ \_\_| |___\___/|_|\_|
    /**
     * stringify this vm
     * @return string representation
     */
    ViewModel.prototype.serialize = function () {
        var modifiedTechniqueVMs = [];
        var self = this;
        this.techniqueVMs.forEach(function (value, key) {
            if (value.modified())
                modifiedTechniqueVMs.push(JSON.parse(value.serialize())); //only save techniqueVMs which have been modified
        });
        var rep = {};
        rep.name = this.name;
        rep.version = String(this.version);
        rep.domain = this.domain;
        rep.description = this.description;
        rep.filters = JSON.parse(this.filters.serialize());
        rep.sorting = this.sorting;
        rep.viewMode = this.viewMode;
        rep.hideDisabled = this.hideDisabled;
        rep.techniques = modifiedTechniqueVMs;
        rep.gradient = JSON.parse(this.gradient.serialize());
        rep.legendItems = JSON.parse(JSON.stringify(this.legendItems));
        rep.metadata = this.metadata.filter(function (m) { return m.valid(); }).map(function (m) { return m.serialize(); });
        rep.showTacticRowBackground = this.showTacticRowBackground;
        rep.tacticRowBackground = this.tacticRowBackground;
        rep.selectTechniquesAcrossTactics = this.selectTechniquesAcrossTactics;
        return JSON.stringify(rep, null, "\t");
    };
    /**
     * restore this vm from a string
     * @param  rep string to restore from
     */
    ViewModel.prototype.deSerialize = function (rep) {
        var obj = (typeof (rep) == "string") ? JSON.parse(rep) : rep;
        this.name = obj.name;
        this.domain = obj.domain;
        if (obj.version !== _globals__WEBPACK_IMPORTED_MODULE_2__["layer_version"]) {
            alert("WARNING: Uploaded layer version (" + String(obj.version) + ") does not match Navigator's layer version ("
                + String(_globals__WEBPACK_IMPORTED_MODULE_2__["layer_version"]) + "). The layer configuration may not be fully restored.");
        }
        if ("description" in obj) {
            if (typeof (obj.description) === "string")
                this.description = obj.description;
            else
                console.error("TypeError: description field is not a string");
        }
        if ("filters" in obj) {
            this.filters.deSerialize(obj.filters);
        }
        if ("sorting" in obj) {
            if (typeof (obj.sorting) === "number")
                this.sorting = obj.sorting;
            else
                console.error("TypeError: sorting field is not a number");
        }
        if ("viewMode" in obj) {
            if (typeof (obj.viewMode) === "number")
                this.viewMode = obj.viewMode;
            else
                console.error("TypeError: viewMode field is not a number");
        }
        if ("hideDisabled" in obj) {
            if (typeof (obj.hideDisabled) === "boolean")
                this.hideDisabled = obj.hideDisabled;
            else
                console.error("TypeError: hideDisabled field is not a boolean");
        }
        if ("gradient" in obj) {
            this.gradient = new Gradient();
            this.gradient.deSerialize(JSON.stringify(obj.gradient));
        }
        if ("legendItems" in obj) {
            for (var i = 0; i < obj.legendItems.length; i++) {
                var legendItem = {
                    color: "#defa217",
                    label: "default label"
                };
                if (!("label" in obj.legendItems[i])) {
                    console.error("Error: LegendItem required field 'label' not present");
                    continue;
                }
                if (!("color" in obj.legendItems[i])) {
                    console.error("Error: LegendItem required field 'label' not present");
                    continue;
                }
                if (typeof (obj.legendItems[i].label) === "string") {
                    legendItem.label = obj.legendItems[i].label;
                }
                else {
                    console.error("TypeError: legendItem label field is not a string");
                    continue;
                }
                if (typeof (obj.legendItems[i].color) === "string" && tinycolor(obj.legendItems[i].color).isValid()) {
                    legendItem.color = obj.legendItems[i].color;
                }
                else {
                    console.error("TypeError: legendItem color field is not a color-string:", obj.legendItems[i].color, "(", typeof (obj.legendItems[i].color), ")");
                    continue;
                }
                this.legendItems.push(legendItem);
            }
        }
        if ("showTacticRowBackground" in obj) {
            if (typeof (obj.showTacticRowBackground) === "boolean")
                this.showTacticRowBackground = obj.showTacticRowBackground;
            else
                console.error("TypeError: showTacticRowBackground field is not a boolean");
        }
        if ("tacticRowBackground" in obj) {
            if (typeof (obj.tacticRowBackground) === "string" && tinycolor(obj.tacticRowBackground).isValid())
                this.tacticRowBackground = obj.tacticRowBackground;
            else
                console.error("TypeError: tacticRowBackground field is not a color-string:", obj.tacticRowBackground, "(", typeof (obj.tacticRowBackground), ")");
        }
        if ("selectTechniquesAcrossTactics" in obj) {
            if (typeof (obj.selectTechniquesAcrossTactics) === "boolean")
                this.selectTechniquesAcrossTactics = obj.selectTechniquesAcrossTactics;
            else
                console.error("TypeError: selectTechniquesAcrossTactics field is not a boolean");
        }
        if ("techniques" in obj) {
            if (obj.techniques.length > 0) {
                if ("tactic" in obj.techniques[0]) {
                    for (var i = 0; i < obj.techniques.length; i++) {
                        var technique = obj.techniques[i];
                        var tvm = new TechniqueVM("");
                        tvm.deSerialize(JSON.stringify(technique), technique.techniqueID, technique.tactic);
                        this.setTechniqueVM(tvm);
                    }
                }
                else {
                    this.needsToConstructTechniqueVMs = true;
                    this.legacyTechniques = obj.techniques;
                }
            }
        }
        if ("metadata" in obj) {
            for (var _i = 0, _a = obj.metadata; _i < _a.length; _i++) {
                var metadataObj = _a[_i];
                var m = new Metadata();
                m.deSerialize(metadataObj);
                if (m.valid())
                    this.metadata.push(m);
            }
        }
        this.updateGradient();
    };
    ViewModel.prototype.constructLegacyVMs = function () {
        if (this.needsToConstructTechniqueVMs) {
            for (var i = 0; i < this.legacyTechniques.length; i++) {
                var techniqueID = this.legacyTechniques[i].techniqueID;
                var techniqueTactics = this.techIDtoUIDMap[techniqueID];
                if (techniqueTactics) {
                    for (var t = 0; t < techniqueTactics.length; t++) {
                        var tactic = techniqueTactics[t].split("^")[1];
                        var tvm = new TechniqueVM("");
                        tvm.deSerialize(JSON.stringify(this.legacyTechniques[i]), techniqueID, tactic);
                        this.setTechniqueVM(tvm);
                    }
                }
            }
        }
        this.updateGradient();
    };
    /**
     * Add a color to the end of the gradient
     */
    ViewModel.prototype.addGradientColor = function () {
        this.gradient.addColor();
        this.updateGradient();
    };
    /**
     * Remove color at the given index
     * @param index index to remove color at
     */
    ViewModel.prototype.removeGradientColor = function (index) {
        this.gradient.removeColor(index);
        this.updateGradient();
    };
    /**
     * Update this vm's gradient
     */
    ViewModel.prototype.updateGradient = function () {
        console.log("updating gradient");
        this.gradient.updateGradient();
        var self = this;
        this.techniqueVMs.forEach(function (tvm, key) {
            tvm.scoreColor = self.gradient.getColor(tvm.score);
        });
        this.updateLegendColorPresets();
    };
    ViewModel.prototype.addLegendItem = function () {
        var newObj = {
            label: "NewItem",
            color: '#00ffff'
        };
        this.legendItems.push(newObj);
    };
    ViewModel.prototype.deleteLegendItem = function (index) {
        this.legendItems.splice(index, 1);
    };
    ViewModel.prototype.clearLegend = function () {
        this.legendItems = [];
    };
    ViewModel.prototype.updateLegendColorPresets = function () {
        this.legendColorPresets = [];
        for (var i = 0; i < this.backgroundPresets.length; i++) {
            this.legendColorPresets.push(this.backgroundPresets[i]);
        }
        for (var i = 0; i < this.gradient.colors.length; i++) {
            this.legendColorPresets.push(this.gradient.colors[i].color);
        }
    };
    /**
     * return an acronym version of the given string
     * @param  words the string of words to get the acrnoym of
     * @return       the acronym string
     */
    ViewModel.prototype.acronym = function (words) {
        var skipWords = ["on", "and", "the", "with", "a", "an", "of", "in", "for", "from"];
        var result = "";
        var wordSplit = words.split(" ");
        if (wordSplit.length > 1) {
            var wordIndex = 0;
            // console.log(wordSplit);
            while (result.length < 4 && wordIndex < wordSplit.length) {
                if (skipWords.includes(wordSplit[wordIndex].toLowerCase())) {
                    wordIndex++;
                    continue;
                }
                //find first legal char of word
                for (var charIndex = 0; charIndex < wordSplit[wordIndex].length; charIndex++) {
                    var code = wordSplit[wordIndex].charCodeAt(charIndex);
                    if (code < 48 || (code > 57 && code < 65) || (code > 90 && code < 97) || code > 122) { //illegal character
                        continue;
                    }
                    else {
                        result += wordSplit[wordIndex].charAt(charIndex).toUpperCase();
                        break;
                    }
                }
                wordIndex++;
            }
            return result;
        }
        else {
            return wordSplit[0].charAt(0).toUpperCase();
        }
    };
    return ViewModel;
}());

// the viewmodel for a specific technique
var TechniqueVM = /** @class */ (function () {
    function TechniqueVM(technique_tactic_union_id) {
        this.score = "";
        this.color = ""; //manually assigned color-class name
        this.enabled = true;
        this.comment = "";
        this.metadata = [];
        this.technique_tactic_union_id = technique_tactic_union_id;
        var idSplit = technique_tactic_union_id.split("^");
        this.techniqueID = idSplit[0];
        this.tactic = idSplit[1];
    }
    //print this object to the console
    TechniqueVM.prototype.print = function () {
        console.log(this.serialize());
        console.log(this);
    };
    /**
     * Has this TechniqueVM been modified from its initialized state?
     * @return true if it has been modified, false otherwise
     */
    TechniqueVM.prototype.modified = function () {
        return (this.score != "" || this.color != "" || !this.enabled || this.comment != "");
    };
    /**
     * Convert to string representation
     * @return string representation
     */
    TechniqueVM.prototype.serialize = function () {
        var rep = {};
        rep.techniqueID = this.techniqueID;
        rep.tactic = this.tactic;
        if (this.score !== "" && !(isNaN(Number(this.score))))
            rep.score = Number(this.score);
        rep.color = this.color;
        rep.comment = this.comment;
        rep.enabled = this.enabled;
        rep.metadata = this.metadata.filter(function (m) { return m.valid(); }).map(function (m) { return m.serialize(); });
        //rep.technique_tactic_union_id = this.technique_tactic_union_id;
        //console.log(rep);
        return JSON.stringify(rep, null, "\t");
    };
    /**
     * Restore this technique from serialized technique
     * @param rep serialized technique string
     */
    TechniqueVM.prototype.deSerialize = function (rep, techniqueID, tactic) {
        var obj = JSON.parse(rep);
        if (techniqueID !== undefined)
            this.techniqueID = techniqueID;
        else
            console.error("ERROR: TechniqueID field not present in technique");
        // if ("technique_tactic_union_id" in obj) this.technique_tactic_union_id = obj.technique_tactic_union_id;
        // else console.error("ERROR: technique_tactic_union_id field not present in technique")
        if ("tactic" !== undefined)
            this.tactic = tactic;
        else
            console.error("ERROR: tactic field not present in technique");
        if ("comment" in obj) {
            if (typeof (obj.comment) === "string")
                this.comment = obj.comment;
            else
                console.error("TypeError: technique comment field is not a number:", obj.comment, "(", typeof (obj.comment), ")");
        }
        if ("color" in obj && obj.color !== "") {
            if (typeof (obj.color) === "string" && tinycolor(obj.color).isValid())
                this.color = obj.color;
            else
                console.error("TypeError: technique color field is not a color-string:", obj.color, "(", typeof (obj.color), ")");
        }
        if ("score" in obj) {
            if (typeof (obj.score) === "number")
                this.score = String(obj.score);
            else
                console.error("TypeError: technique score field is not a number:", obj.score, "(", typeof (obj.score), ")");
        }
        if ("enabled" in obj) {
            if (typeof (obj.enabled) === "boolean")
                this.enabled = obj.enabled;
            else
                console.error("TypeError: technique enabled field is not a boolean:", obj.enabled, "(", typeof (obj.enabled), ")");
        }
        if (this.tactic !== undefined && this.techniqueID !== undefined) {
            this.technique_tactic_union_id = this.techniqueID + "^" + this.tactic;
        }
        else {
            console.log("ERROR: Tactic and TechniqueID field needed.");
        }
        if ("metadata" in obj) {
            for (var _i = 0, _a = obj.metadata; _i < _a.length; _i++) {
                var metadataObj = _a[_i];
                var m = new Metadata();
                m.deSerialize(metadataObj);
                if (m.valid())
                    this.metadata.push(m);
            }
        }
    };
    return TechniqueVM;
}());

// the data for a specific filter
var Filter = /** @class */ (function () {
    function Filter(domain) {
        this.stages = { options: ["prepare", "act"], selection: ["act"] };
        // this.stages.selection = ["act"];
        // this.stages.options = ["prepare", "act"];
        if (domain == "mitre-enterprise") {
            this.platforms = { selection: ["Windows", "Linux", "macOS"], options: ["Windows", "Linux", "macOS", "AWS", "GCP", "Azure", "Azure AD", "Office 365", "SaaS"] };
        }
        else if (domain == "mitre-mobile") {
            this.platforms = { selection: ["Android", "iOS"], options: ["Android", "iOS"] };
        }
        else {
            console.error("unknown domain", domain);
        }
    }
    Filter.prototype.toggleInFilter = function (filterName, value) {
        if (!this[filterName].options.includes(value)) {
            console.log("not a valid option to toggle", value, this[filterName]);
            return;
        }
        if (this[filterName].selection.includes(value)) {
            var index = this[filterName].selection.indexOf(value);
            this[filterName].selection.splice(index, 1);
        }
        else {
            this[filterName].selection.push(value);
        }
    };
    Filter.prototype.inFilter = function (filterName, value) {
        return this[filterName].selection.includes(value);
    };
    /**
     * Return the string representation of this filter
     * @return [description]
     */
    Filter.prototype.serialize = function () {
        return JSON.stringify({ "stages": this.stages.selection, "platforms": this.platforms.selection });
    };
    /**
     * Replace the properties of this object with those of the given serialized filter
     * @param rep filter object
     */
    Filter.prototype.deSerialize = function (rep) {
        // console.log(rep)
        var isStringArray = function (check) {
            for (var i = 0; i < check.length; i++) {
                if (typeof (check[i]) !== "string") {
                    console.error("TypeError:", check[i], "(", typeof (check[i]), ")", "is not a string");
                    return false;
                }
            }
            return true;
        };
        // let obj = JSON.parse(rep);
        if (rep.platforms) {
            if (isStringArray(rep.platforms)) {
                var backwards_compatibility_mappings_1 = {
                    "android": "Android",
                    "ios": "iOS",
                    "windows": "Windows",
                    "linux": "Linux",
                    "mac": "macOS"
                };
                this.platforms.selection = rep.platforms.map(function (platform) {
                    if (platform in backwards_compatibility_mappings_1) {
                        return backwards_compatibility_mappings_1[platform];
                    }
                    else {
                        return platform;
                    }
                });
            }
            else
                console.error("TypeError: filter platforms field is not a string[]");
        }
        if (rep.stages) {
            if (isStringArray(rep.stages))
                this.stages.selection = rep.stages;
            else
                console.error("TypeError: filter stages field is not a string[]");
        }
    };
    return Filter;
}());

// { name, value } with serialization
var Metadata = /** @class */ (function () {
    function Metadata() {
    }
    ;
    Metadata.prototype.serialize = function () { return { name: this.name, value: this.value }; };
    Metadata.prototype.deSerialize = function (rep) {
        if (rep.name) {
            if (typeof (rep.name) === "string")
                this.name = rep.name;
            else
                console.error("TypeError: Metadata field 'name' is not a string");
        }
        else
            console.error("Error: Metadata required field 'name' not present");
        if (rep.value) {
            if (typeof (rep.value) === "string")
                this.value = rep.value;
            else
                console.error("TypeError: Metadata field 'value' is not a string");
        }
        else
            console.error("Error: Metadata required field 'value' not present");
    };
    Metadata.prototype.valid = function () { return this.name.length > 0 && this.value.length > 0; };
    return Metadata;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
var environment = {
    production: false
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /mnt/c/Users/MichaelEssigke/Documents/Knowledge/QRadarApps/attack-navigator/nav-app/src/main.ts */"./src/main.ts");


/***/ }),

/***/ 1:
/*!**********************!*\
  !*** util (ignored) ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 2:
/*!**********************!*\
  !*** util (ignored) ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 3:
/*!************************!*\
  !*** buffer (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 4:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

},[[0,"runtime","vendor"]]]);